﻿namespace BaseMetronic.ViewModels.FileManagers
{
    public class FileManagerInfoVM
    {
        public long Length { get; set; }
        public int RecordTotal { get; set; }
    }
}

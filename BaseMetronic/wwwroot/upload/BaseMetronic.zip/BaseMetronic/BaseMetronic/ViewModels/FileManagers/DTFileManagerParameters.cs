﻿using BaseMetronic.Utilities.Datatables;

namespace BaseMetronic.ViewModels.FileManagers
{
    public class DTFileManagerParameters : DTParameters
    {
        public int? ParentId { get; set; }
    }
}

﻿namespace BaseMetronic.ViewModels.FileManagers
{
    public class RenameDirectoryItemDTO
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
    }
}

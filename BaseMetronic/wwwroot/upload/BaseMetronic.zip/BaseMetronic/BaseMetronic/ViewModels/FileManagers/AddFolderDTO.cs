﻿namespace BaseMetronic.ViewModels.FileManagers
{
    public class AddFolderDTO
    {
        public string Name { get; set; } = string.Empty;
        public int? ParentId  { get; set; }
}
}

﻿using BaseMetronic.Configurations.Common;
using BaseMetronic.Models.Entities;

namespace BaseMetronic.Configurations
{
    public class AccountConfiguration : BaseConfiguration<Account>
    {
    }
}

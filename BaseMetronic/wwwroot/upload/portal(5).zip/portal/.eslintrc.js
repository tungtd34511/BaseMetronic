/* eslint-disable */
// module.exports = {
//   parser: "@typescript-eslint/parser",

//   plugins: ["@typescript-eslint", "@typescript-eslint/eslint-plugin"],

//   extends: [
//     "next/core-web-vitals",
//     "plugin:@typescript-eslint/recommended",
//     "plugin:prettier/recommended",
//   ],
//   root: true,
//   env: {
//     node: true,
//     jest: true,
//     browser: true,
//   },
//   ignorePatterns: [".eslintrc.js"],
//   rules: {
//     "prefer-const": "error",
//     "@typescript-eslint/no-unused-vars": ["error", { varsIgnorePattern: "^_" }],
//     "prettier/prettier": 0,
//   },
// };

// "eslint-config-next": "12.1.6",
// "eslint-config-prettier": "^8.5.0",
// "eslint-plugin-prettier": "^4.2.1",



// module.exports = {
//   env: {
//     browser: true,
//     es2021: true,
//   },
//   extends: [
//     "eslint:recommended",
//     "plugin:react/recommended",
//     "plugin:@typescript-eslint/recommended",
//     "prettier",
//   ],
//   parser: "@typescript-eslint/parser",
//   parserOptions: {
//     ecmaFeatures: {
//       jsx: true,
//     },
//     ecmaVersion: 13,
//     sourceType: "module",
//   },
//   plugins: ["react", "@typescript-eslint"],
//   rules: {
//     "@next/next/no-img-element": "off",
//   },
// };

import React from "react";
import CustomBreadCrumb from "src/layout/CustomBreadCrumb";
import GameReport from "src/views/games/GameReport";

const GamesLogPage = () => {
  return (
    <>
        <CustomBreadCrumb
        items={[
          {
            title: "Nhật ký hoạt động game",
            href: "/games/log",
          },
        ]}
      ></CustomBreadCrumb>
      <GameReport />
    </>
  )
};

export default GamesLogPage;

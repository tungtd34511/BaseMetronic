import React from "react";
import CustomBreadCrumb from "src/layout/CustomBreadCrumb";
import GameConfigList from "src/views/games/GameConfigList";

const GamesConfigPage = () => {
  return (
    <>
          <CustomBreadCrumb
        items={[
          {
            title: "Cấu hình game",
            href: "/games/config",
          },
        ]}
      ></CustomBreadCrumb>
      <GameConfigList/>
    </>
  )
};

export default GamesConfigPage;

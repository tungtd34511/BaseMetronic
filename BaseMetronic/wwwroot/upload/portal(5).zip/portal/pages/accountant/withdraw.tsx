import type { NextPage } from "next";
import CustomBreadCrumb from "src/layout/CustomBreadCrumb";
import AccWithdrawCommission from "src/views/accountant/AccWithdrawCommission";

const CSPaymentPage: NextPage = () => {
  return (
    <>
      <CustomBreadCrumb
        items={[
          {
            title: "Yêu cầu thanh toán",
            href: "/accountant/payment",
          },
        ]}
      ></CustomBreadCrumb>
      <AccWithdrawCommission />
    </>
  );
};

export default CSPaymentPage;

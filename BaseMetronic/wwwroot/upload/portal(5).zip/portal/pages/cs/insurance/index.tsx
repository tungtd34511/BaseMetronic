import type { NextPage } from "next";
import CustomBreadCrumb from "src/layout/CustomBreadCrumb";
import CSSearchInsurance from "src/views/cs/CSSearchInsurance";

const CSInsurancePage: NextPage = () => {
  return (
    <>
      <CustomBreadCrumb
        items={[
          {
            title: "Cập nhật bảo hiểm",
            href: "/cs/insurance",
          },
        ]}
      ></CustomBreadCrumb>
      <CSSearchInsurance />
    </>
  );
};

export default CSInsurancePage;

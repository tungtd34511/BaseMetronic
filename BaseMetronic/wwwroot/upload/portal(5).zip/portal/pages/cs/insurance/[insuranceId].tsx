import type { NextPage } from "next";
import CustomBreadCrumb from "src/layout/CustomBreadCrumb";
import CSUpdateInsuranceForm from "src/views/cs/CSUpdateInsuranceForm";

const CSInsurancePage: NextPage = () => {
  return (
    <>
      <CustomBreadCrumb
        items={[
          {
            title: "Cập nhật bảo hiểm",
            href: "/cs/insurance",
          },
        ]}
      ></CustomBreadCrumb>
      <CSUpdateInsuranceForm />
    </>
  );
};

export default CSInsurancePage;

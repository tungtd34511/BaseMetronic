import { Tabs } from "antd";
import type { NextPage } from "next";
import CustomBreadCrumb from "src/layout/CustomBreadCrumb";
import CSCommissionReport from "src/views/cs/CSCommissionReport";
import CSReport from "src/views/cs/CSReport";

const CSReportPage: NextPage = () => {
  return (
    <>
      <CustomBreadCrumb
        items={[
          {
            title: "Báo cáo",
            href: "/cs/report",
          },
        ]}
      ></CustomBreadCrumb>
      <Tabs style={{ height: "100%" }} defaultActiveKey="1">
        <Tabs.TabPane tab="Tổng hợp" key="1">
          <CSReport />
        </Tabs.TabPane>
        <Tabs.TabPane tab="Hoa hồng/người dùng" key="2">
          <CSCommissionReport />
        </Tabs.TabPane>
      </Tabs>
    </>
  );
};

export default CSReportPage;

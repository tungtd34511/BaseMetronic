import type { NextPage } from "next";
import CustomBreadCrumb from "src/layout/CustomBreadCrumb";
import CSWithdrawCommission from "src/views/cs/CSWithdrawCommission";

const CSPaymentPage: NextPage = () => {
  return (
    <>
      <CustomBreadCrumb
        items={[
          {
            title: "Yêu cầu thanh toán",
            href: "/cs/payment",
          },
        ]}
      ></CustomBreadCrumb>
      <CSWithdrawCommission />
    </>
  );
};

export default CSPaymentPage;

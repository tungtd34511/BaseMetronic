import React from "react";

const TransactionPage = () => {
  return <div>Comming soon</div>;
};

export default TransactionPage;

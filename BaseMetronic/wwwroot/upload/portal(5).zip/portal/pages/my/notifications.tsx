import type { NextPage } from "next";

const NotificationPage: NextPage = () => {
  return <>Comming Soon</>;
};

export default NotificationPage;

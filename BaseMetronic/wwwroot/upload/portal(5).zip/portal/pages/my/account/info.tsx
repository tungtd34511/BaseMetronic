import type { NextPage } from "next";
import CustomBreadCrumb from "src/layout/CustomBreadCrumb";
import { RoutePath } from "src/layout/Sider";
import UpdateInfo from "src/views/account/UpdateInfo";

const AccountInfoPage: NextPage = () => {
  return (
    <>
      <CustomBreadCrumb
        items={[
          { title: "Cập nhật thông tin", href: RoutePath.ACCOUNT_SETTING_INFO },
        ]}
      ></CustomBreadCrumb>
      <UpdateInfo />
    </>
  );
};

export default AccountInfoPage;

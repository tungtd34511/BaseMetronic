import type { NextPage } from "next";
import CustomBreadCrumb from "src/layout/CustomBreadCrumb";
import { RoutePath } from "src/layout/Sider";
import UpdateInfo from "src/views/account/UpdateInfo";

const AccountPage: NextPage = () => {
  return (
    <>
      <CustomBreadCrumb
        items={[
          { title: "Cập nhật thông tin", href: RoutePath.ACCOUNT_SETTING },
        ]}
      ></CustomBreadCrumb>
      <UpdateInfo />
    </>
  );
};

export default AccountPage;

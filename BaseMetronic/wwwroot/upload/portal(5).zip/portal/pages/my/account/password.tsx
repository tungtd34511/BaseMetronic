import { Button, Form, Input, message } from "antd";
import type { NextPage } from "next";
import { FlexBox } from "src/common/FlexBox";
import useRole from "src/hooks/useRole";
import CustomBreadCrumb from "src/layout/CustomBreadCrumb";
import { RoutePath } from "src/layout/Sider";
import { useChangePasswordMutation } from "store/APIs/user";

const PasswordPage: NextPage = () => {
  const [form] = Form.useForm();
  const { userData } = useRole();
  const [changePassword, { isLoading }] = useChangePasswordMutation();

  const onFinish = () => {
    message.loading("Đang cập nhật");
    changePassword(form.getFieldsValue())
      .then(() => {
        message.destroy();
        message.success("Cập nhật thành công");
      })
      .catch(() => {
        message.destroy();
        message.error("Có lỗi xảy ra!");
      });
  };

  return (
    <>
      <CustomBreadCrumb
        items={[
          { title: "Đổi mật khẩu", href: RoutePath.ACCOUNT_SETTING_PASSWORD },
        ]}
      ></CustomBreadCrumb>
      <FlexBox
        style={{
          alignItems: "center",
          flexDirection: "column",
          marginTop: 100,
        }}
      >
        <Form
          form={form}
          name="basic"
          labelCol={{ span: 8 }}
          wrapperCol={{ span: 16 }}
          style={{ maxWidth: 600, width: "100%" }}
          initialValues={{ remember: true }}
          onFinish={onFinish}
          // onFinishFailed={onFinishFailed}

          autoComplete="off"
        >
          <Form.Item
            label="Tên đăng nhập (email)"
            name="email"
            rules={[{ required: true, message: "Không được để trống" }]}
          >
            <Input defaultValue={userData?.email || ""} />
          </Form.Item>

          <Form.Item
            label="Mật khẩu mới"
            name="newPassword"
            rules={[{ required: true, message: "Không được để trống" }]}
          >
            <Input.Password />
          </Form.Item>
          <Form.Item
            label="Nhập lại mật khẩu mới"
            name="confirmPassword"
            rules={[
              { required: true, message: "Không được để trống" },
              {
                validator: async function (_rule, value) {
                  if (value !== form.getFieldValue("newPassword")) {
                    return Promise.reject(new Error("Mật khẩu không khớp"));
                  }
                },
              },
            ]}
          >
            <Input.Password />
          </Form.Item>
          <Form.Item wrapperCol={{ offset: 8, span: 16 }}>
            <Button loading={isLoading} type="primary" htmlType="submit">
              Lưu
            </Button>
          </Form.Item>
        </Form>
      </FlexBox>
    </>
  );
};

export default PasswordPage;

import { Button, Col, Divider, Form, Modal, Row } from 'antd';
import React, { useState } from 'react';
import CustomDateRangePicker from 'src/common/CustomDateRangePicker';
import CustomSelect from 'src/common/CustomSelect';
import CustomBreadCrumb from 'src/layout/CustomBreadCrumb';
import { RoutePath } from 'src/layout/Sider';
import CustomTable from 'src/common/CustomTable';
import useIsMobile from 'src/common/useIsMobile';
import { DeleteOutlined, EditOutlined } from '@ant-design/icons';
import CustomModal from 'src/common/CustomModal';
import TypeInsurance from './TypeInsurance';
import { ARR_INSURANCE_FEATURE } from 'enums/insurance.enum';
import { TITLE_NOTIFICATION } from 'store/APIs/common';
import { DEFAULT_PARAMS_FILTER } from 'store/APIs/const';
import { useGetUserListQuery } from 'store/APIs/user';
import { DEFAULT_PAGE_SIZE } from 'src/constants';
import CustomInput from 'src/common/CustomInput';
const Contract = () => {
    const [paramsFilter, setParamsFilter] = useState(DEFAULT_PARAMS_FILTER)
    const [form] = Form.useForm();
    const [formInsert] = Form.useForm();
    const [isModalOpen, setIsModalOpen] = useState(false)
    const isMobile = useIsMobile()
    const [page, setPage] = useState(1);
    const [search, setSearch] = useState("");
    const [pageSize, setPageSize] = useState(DEFAULT_PAGE_SIZE);

    // const [data, setData] = useState([])
    const { data, isLoading } = useGetUserListQuery({
        page,
        limit: pageSize,
        search,
    });
    const columns = [
        {
            title: 'Mã BH',
            render: (text: string) => <div>HĐ 00001</div>
        },

        {
            title: 'Loại bảo hiểm',
            render: (text: string) => <div></div>
        },
        {
            title: 'Hoa hồng trực tiếp (%)',
            render: (text: string) => <div></div>
        },
        {
            title: 'Người giới thiệu (%)',
            render: (text: string) => <div></div>
        },
        {
            title: 'Ngày tạo',
            render: (text: string) => <div></div>
        },
        {
            title: 'Thao tác',
            render: (text: string) => <div>
                <EditOutlined className='cursor-pointer' style={{ fontSize: '20px' }} />
                <DeleteOutlined onClick={() => {
                    showConfirm()
                }} className='ml-12 cursor-pointer' style={{ fontSize: '20px' }} />
            </div>,
        },
    ];
    const showConfirm = () => {
        Modal.confirm({
            okButtonProps: {
                className: 'ant-btn ant-btn-danger'
            },
            title: TITLE_NOTIFICATION,
            content: 'Xác nhận xóa loại bảo hiểm này?',
            onOk() {
                console.log('Xác nhận');
            },
            onCancel() {
                console.log('Hủy bỏ');
            },
            cancelText: 'Hủy',
            okText: 'Xác nhận',
            closable: true
        });
    };

    const arrFilter = [
        {
            id: 'insuranceType',
            label: 'Loại bảo hiểm',
            options: ARR_INSURANCE_FEATURE
        },
    ]
    const handleSubmit = (values: any) => {
        console.log(values)
    }
    const fakeData = [
        {
            id: 1,

        }
    ]
    return (
        <div>
            <Form
                onFinish={handleSubmit}
                form={formInsert}
            >
                <CustomModal
                    title='Tạo mới loại bảo hiểm'
                    handleCancel={() => {
                        setIsModalOpen(false)
                    }}
                    handleOk={formInsert.submit}
                    isModalOpen={isModalOpen}
                    setIsModalOpen={setIsModalOpen}
                >
                    <Row gutter={[12, 12]}>
                        <TypeInsurance />
                    </Row>

                </CustomModal>
            </Form>
            <CustomBreadCrumb
                items={[
                    {
                        title: "Loại bảo hiểm",
                        href: RoutePath.TYPE_INSURANCE,
                    },
                ]}
            />
            <Form
                layout={'vertical'}
                form={form}
            >
                <Row gutter={[12, 12]}>
                    {
                        arrFilter.map((itemMap, key) => <Col key={itemMap.id + key} xs={24} lg={4} xl={4}>
                            <Form.Item label={itemMap.label}>
                                <CustomSelect
                                    formInsert={formInsert}
                                    id={itemMap.id}
                                    value={paramsFilter[itemMap.id as 'customerName']}
                                    onChange={(e) => {
                                        setParamsFilter({
                                            ...paramsFilter,
                                            [itemMap.id]: e
                                        })
                                    }}
                                    options={itemMap.options}
                                />
                            </Form.Item>
                        </Col>)
                    }
                    <Col xs={24} lg={6} xl={6}>
                        <Form.Item label={'Ngày tạo'}>
                            <CustomDateRangePicker
                                startDate={paramsFilter.from}
                                endDate={paramsFilter.to}
                                onChange={(from, to) => {
                                    setParamsFilter({
                                        ...paramsFilter,
                                        from,
                                        to
                                    })
                                }}
                            />
                        </Form.Item>
                    </Col>
                    <Col xs={24} lg={4} xl={4}>
                        <Form.Item label=" ">
                            <Button onClick={() => {
                            }} type="primary">Tìm kiếm</Button>
                        </Form.Item>
                    </Col>
                </Row>
            </Form>
            <div className='pd-24' style={{ background: 'white', }}>
                <div className={`d-flex  ${isMobile ? 'flex-column' : 'align-item-center flex-row'}`}>
                    <h3 className='flex-1'>Loại bảo hiểm</h3>
                    <Button className={`${!isMobile ? 'ml-12' : 'mgbt-12'} `} type="primary" danger>Xóa</Button>
                    <Button
                        onClick={() => {
                            formInsert.resetFields()
                            setIsModalOpen(true)
                        }}
                        className={`${!isMobile ? 'ml-12' : 'mgbt-12'}`}
                        type="primary">
                        Tạo mới
                    </Button>
                </div>
                <Divider />
                <CustomTable
                    columns={columns}
                    totalDocs={data?.totalDocs || 0}
                    data={fakeData}
                    isLoading={false}
                    onChange={(page, pageSize) => {
                    }}
                    pageSize={15}
                    pageCurrent={0}
                />
            </div>

        </div>
    );
};

export default Contract;
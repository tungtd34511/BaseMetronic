import { Col, Form } from 'antd';
import React from 'react';
import CustomInput from 'src/common/CustomInput';
import { validateCommistion, validateMaxLength } from 'src/common/Validate';
import { NOT_EMPTY, PRESS, TYPE_ARR_INPUT } from 'store/APIs/const';
const TypeInsurance = () => {
    const ruleCommision = [
        {
            required: true,
            message: `Phần trăm ${NOT_EMPTY}`
        },
        {
            pattern: validateCommistion(2).regexPattern,
            message: validateCommistion(2).message
        },
        {
            pattern: validateMaxLength(4).regexPattern,
            message: validateMaxLength(4).message
        },
    ]
    
    const ARR_INPUT_TYPE_INSURNCE = [
        {
            id: 'typeInsurance',
            label: 'Loại bảo hiểm',
            type: TYPE_ARR_INPUT.INPUT,
            placeholder: `${PRESS} loại bảo hiểm`,
            rules: [
                {
                    required: true,
                    message: `Loại bảo hiểm ${NOT_EMPTY}`
                },
                {
                    pattern: validateMaxLength(50).regexPattern,
                    message: validateMaxLength(50).message
                },
               
            ]
        },
        {
            id: 'commission',
            label: '% Hoa hồng trực tiếp',
            type: TYPE_ARR_INPUT.INPUT,
            placeholder: `${PRESS} loại bảo hiểm`,
            rules: ruleCommision
        },
        {
            id: 'presenter',
            label: '% Người giới thiệu',
            type: TYPE_ARR_INPUT.INPUT,
            placeholder: `${PRESS} người giới thiệu`,
            rules: ruleCommision
        },
    
    ]
    return <>
        {
            ARR_INPUT_TYPE_INSURNCE.map((itemMap, key) => <Col key={itemMap.id + key} xs={12} xl={8}>
                {
                    <Form.Item
                        name={itemMap.id}
                        rules={itemMap.rules || []}
                        label={<span>{itemMap.label}</span>}>
                        <CustomInput
                            placeholder={itemMap.placeholder}
                            id={itemMap.id}
                        />
                    </Form.Item>
                }
            </Col>)
        }
    </>
};

export default TypeInsurance;
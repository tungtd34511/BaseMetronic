import { Button } from "antd";
import type { NextPage } from "next";
import { useRouter } from "next/router";
import { useEffect } from "react";
import { FlexBox } from "src/common/FlexBox";
import CustomBreadCrumb from "src/layout/CustomBreadCrumb";
import { RoutePath } from "src/layout/Sider";
import { randomColor } from "src/utils/color";
import ListVoucher from "src/views/voucher/ListVoucher";
import { useCreateVoucherMutation } from "store/APIs/referrer";
import { useGetMyUserInfoQuery } from "store/APIs/user";

const VoucherPage: NextPage = () => {
  const router = useRouter();
  const { data: user } = useGetMyUserInfoQuery();
  const [createVoucherMutation, { isLoading, data: voucherResponse }] =
    useCreateVoucherMutation();

  useEffect(() => {
    if (voucherResponse) {
      router.push(`${RoutePath.VOUCHER}/${voucherResponse.id}`);
    }
  }, [voucherResponse, router]);

  return (
    <>
      <CustomBreadCrumb
        items={[
          {
            title: "Voucher",
            href: "/voucher",
          },
        ]}
      ></CustomBreadCrumb>

      <FlexBox style={{ justifyContent: "flex-end", marginBottom: 16 }}>
        <Button
          type="primary"
          loading={isLoading || !user}
          onClick={() => {
            if (user)
              createVoucherMutation({
                agencyId: user?.id,
                agencyName: user?.name,

                planName: "Sự kiện giảm giá X",
                description: "Sự kiện giảm giá X",
                value: 100000,
                code: `${randomColor()}${randomColor()}`.toUpperCase(),
                qty: 10,
                remainingQty: 10,
                startDate: new Date(),
                endDate: new Date(),
              });
          }}
        >
          Tạo Voucher
        </Button>
      </FlexBox>
      <ListVoucher />
    </>
  );
};

export default VoucherPage;

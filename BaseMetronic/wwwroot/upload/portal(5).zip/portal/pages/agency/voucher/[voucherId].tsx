import type { NextPage } from "next";
import CustomBreadCrumb from "src/layout/CustomBreadCrumb";
import EditVoucher from "src/views/voucher/EditVoucher";

const EditVoucherPage: NextPage = () => {
  return (
    <>
      <CustomBreadCrumb
        items={[
          {
            title: "Voucher",
            href: "/admin/voucher",
          },
          {
            title: "Chỉnh sửa",
          },
        ]}
      ></CustomBreadCrumb>

      <EditVoucher />
    </>
  );
};

export default EditVoucherPage;

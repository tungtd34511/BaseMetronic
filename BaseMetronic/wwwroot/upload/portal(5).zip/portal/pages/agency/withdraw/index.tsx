import { CheckOutlined } from "@ant-design/icons";
import { Button, Spin, Typography, message } from "antd";
import { IUserDetails } from "interfaces/user.interfaces";
import type { NextPage } from "next";
import { useRouter } from "next/router";
import { useEffect } from "react";
import { FlexBox } from "src/common/FlexBox";
import { ACCESS_TOKEN_KEY } from "src/constants";
import CustomBreadCrumb from "src/layout/CustomBreadCrumb";
import { RoutePath } from "src/layout/Sider";
import WithdrawCommission from "src/views/agency/WithdrawCommission";
import { useGetUserDetailsQuery } from "store/APIs/user";
import { useUpdateDetailsMutation } from "store/APIs/user";

const AdminPaymentPage: NextPage = () => {
  const router = useRouter();
  const { data, isLoading } = useGetUserDetailsQuery();
  const [
    updateDetailsMutation,
    { isLoading: _isUpdateLoading, isError, isSuccess },
  ] = useUpdateDetailsMutation();

  const updateUser = (record: IUserDetails) => {
    const payload: IUserDetails = {
      fullName: record.fullName,
      birthday: record.birthday,
      gender: record.gender,
      phone: record.phone,
      address: record.address,
      IDCardNum: record.IDCardNum,
      dateOfIssue: record.dateOfIssue,
      issuedBy: record.issuedBy,
      dueDate: record.dueDate,
      bankAccNum: record.bankAccNum,
      bankAccName: record.bankAccName,
      bankName: record.bankName,
      taxCode: record.taxCode,
      IDCardImages: record.IDCardImages,
      cardImages: record.cardImages,
      signImage: record.signImage,
      // contractSented : record.contractSented,
      isVertified: record.isVertified,
      contractSented: true,
    };
    updateDetailsMutation(payload);
  };

  const handleGeneratePdf = async (user: IUserDetails) => {
    try {
      const accessToken =
        typeof window !== "undefined"
          ? window.localStorage.getItem(ACCESS_TOKEN_KEY)
          : "";
      const response = await fetch(`${process.env.API_HOST}/api/my/user/agency-contract`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'authorization': `Bearer ${accessToken}`,
        },
        body: JSON.stringify(user),
      });
      if (response.ok) {
        const pdfBlob = await response.blob();
        const pdfUrl = URL.createObjectURL(pdfBlob);
        window.open(pdfUrl, '_blank');
      } else {
        console.error('Error generating PDF:', response.statusText);
      }
    } catch (error) {
      console.error('An error occurred:', error);
    }
  };

  useEffect(() => {
    if (isError) {
      message.error("Có lỗi xảy ra");
    }
    if (isSuccess) {
      message.success("Cập nhật thành công");
    }
  }, [isError, isSuccess]);
  return (
    <>
      <CustomBreadCrumb
        items={[
          {
            title: "Yêu cầu thanh toán",
            href: "/customer",
          },
        ]}
      ></CustomBreadCrumb>
      {isLoading && <Spin></Spin>}

      {!isLoading && data?.isVertified && (
        <WithdrawCommission />
      )}
      {!isLoading && !data?.isVertified && (
        <FlexBox className="withdraw-form-container">
          <Typography className="withdraw-form-header">
            Mời bạn vui lòng các bước sau đây để được thanh toán
          </Typography>
          <FlexBox className="withdraw-form-row">
            <Typography style={{ color: "black" }}>
              Bước 1 : Cập nhật thông tin cá nhân của tài khoản của bạn
            </Typography>
            {!data?.fullName ? (
              <FlexBox
                style={{
                  justifyContent: "start",
                }}
              >
                <Button
                  type="primary"
                  style={{ marginTop: 12, marginLeft: 12 }}
                  onClick={() => {
                    router.push(RoutePath.ACCOUNT_SETTING_INFO);
                  }}
                >
                  Cập nhật thông tin
                </Button>
              </FlexBox>
            ) : (
              <span className="sub-italic">
                Thông tin đã được cập nhật <CheckOutlined />
              </span>
            )}
          </FlexBox>
          <FlexBox className="withdraw-form-row">
            <Typography style={{ color: "black" }}>
              Bước 2 : Tải mẫu hợp đồng cộng tác viên của chúng tôi tại đây
            </Typography>
            <FlexBox
              style={{
                justifyContent: "start",
              }}
            >
              {!data ? "Hãy hoàn thành bước 1"
                :
                <Button
                  type="primary"
                  style={{ marginTop: 12, marginLeft: 12 }}
                  onClick={() => {
                    handleGeneratePdf(data)
                  }}
                >
                  Tải hơp đồng
                </Button>
              }
            </FlexBox>
          </FlexBox>
          <FlexBox className="withdraw-form-row">
            <Typography style={{ color: "black" }}>
              Bước 3 : Ký hợp đồng và gửi lại cho chúng tôi tại đỉa chỉ sau đây
            </Typography>
            <span className="company-address">
              27D Dreamland Ngõ 125 Đường Xuân La , Tây Hồ , Hà Nội
            </span>
          </FlexBox>
          <span className="notes">Chú ý trong trường hợp bạn thay đổi thông tin cá nhân và đã nộp hồ sơ bạn hãy bỏ qua bước này</span>
          <FlexBox
            style={{
              justifyContent: "center",
            }}
          >
            <Button
              className="withdraw-fomr-submit"
              type="primary"
              style={{ marginTop: 12, marginLeft: 12 }}
              disabled={!data}
              onClick={() => {
                if (data)
                  updateUser(data);
              }}
            >
              Tôi đã hoàn thành tất cả các bước trên
            </Button>
          </FlexBox>
        </FlexBox>
      )}
    </>
  );
};

export default AdminPaymentPage;

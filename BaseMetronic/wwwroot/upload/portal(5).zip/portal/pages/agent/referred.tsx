import type { NextPage } from "next";
import { useState } from "react";
import CustomDateRangePicker from "src/common/CustomDateRangePicker";
import CustomBreadCrumb from "src/layout/CustomBreadCrumb";
import AgentReferralList from "src/views/agent/AgentReferralList";

import moment from "moment";

const ReferredPage: NextPage = () => {
  const [dateRange, setdateRange] = useState({
    from: moment().subtract(30, "days").valueOf(),
    to: moment().valueOf(),
  });
  return (
    <>
      <CustomBreadCrumb
        items={[{ title: "Lịch sử giới thiệu", href: "/referrer" }]}
      ></CustomBreadCrumb>
      <CustomDateRangePicker
        startDate={dateRange.from}
        endDate={dateRange.to}
        onChange={(from, to) => setdateRange({ from, to })}
      />
      <AgentReferralList dateRange={dateRange} showReferrer />
    </>
  );
};

export default ReferredPage;

import type { NextPage } from "next";
import CustomBreadCrumb from "src/layout/CustomBreadCrumb";
import ListAgent from "src/views/agent/ListAgent";

const ManageAgencyPage: NextPage = () => {
  return (
    <>
      <CustomBreadCrumb
        items={[{ title: "Quản lý thành viên", href: "/manage-agency" }]}
      ></CustomBreadCrumb>
      <ListAgent />
    </>
  );
};

export default ManageAgencyPage;

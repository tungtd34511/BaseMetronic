import { Checkbox, Col, DatePicker, Form, Input, InputNumber } from 'antd';
import { ARR_INSURANCE_FEATURE, EInsuranceFeature, EInsuranceSource } from 'enums/insurance.enum';
import React from 'react';
import CustomInput from 'src/common/CustomInput';
import CustomSelect from 'src/common/CustomSelect';
import useRole, { EUserRole } from 'src/hooks/useRole';
import { IMotoInsurance } from '../InsuranceMotor';
import { useGetAgencyListQuery } from 'store/APIs/user';
import { NOT_EMPTY } from 'store/APIs/const';
export interface IDataInsert {
    companyName: null | string;
    isOverrideReferrer: boolean;
    referrerId: null | string;
    feature: null | string;
    exchangeTime: null | string;
    isCalcCommission: boolean;
    buyerName: null | string;
    buyerPhone: null | string;
    beneficiaryName: null | string;
    beneficiaryPhone: null | string;
    beneficiaryAddress: null | string;
    beneficiaryEmail: null | string;
    beneficiaryIdCard: null | string;
    licensePlates: null | string;
    occupantInsurance: null | string;
    chassisNumber: null | string;
    engineNumber: null | string;
    capacity: null | string;
    manufacturingYear: null | string;
    expiry: null | string;
    startDate: null | string;
    source: null | string;
    fee: null | string;
    discountCode: null | string;
    contractFile: null | string;
}

export interface IGeneralInfomation {
    dataInsert: IDataInsert
    setDataInsert: React.Dispatch<React.SetStateAction<IDataInsert>>
}
const GeneralInfomation = ({ formInsert }: IMotoInsurance) => {
    const { userData } = useRole()

    const isAdmin = userData?.roles?.includes(EUserRole.ADMIN)//
    const type = Form.useWatch('feature', formInsert);
    const isOverrideReferrer = Form.useWatch('isOverrideReferrer', formInsert);
    const isMotor = type === EInsuranceFeature.MOTOR_01
    const isAuto = type === EInsuranceFeature.AUTO_01
    const isHome = type === EInsuranceFeature.HOME_01
    const isHeal = type === EInsuranceFeature.HEALTH_01
    const isFire = type === EInsuranceFeature.FIRE_01

    const { data, isLoading } = useGetAgencyListQuery({
        page: 0,
        limit: 100000,
        search: '',
        admin: true
    }, {
        skip: !isAdmin
    });
    const converDataAgency = data?.docs ? data?.docs?.map((itemMap) => {
        return {
            ...itemMap,
            value: itemMap.id,
            label: `${itemMap?.phone ? itemMap.phone + '-' : ''}${itemMap?.name}`
        }
    }) : []
    const arrGeneral = [
        {
            id: 'referrerId',
            label: 'Người giới thiệu',
            options: converDataAgency,
            placeholder: 'Chọn/ điền người giới thiệu',
            rules:isOverrideReferrer? [{ required: true, message: 'Người giới thiệu không được để trống' }]:[],
            showItem: isAdmin
        },

        {
            id: 'feature',
            label: 'Loại hợp đồng',
            options: ARR_INSURANCE_FEATURE,
            rules: [{ required: true, message: 'Loại hợp đồng không được để trống' }],
            showItem: true
        },
    ].filter((itemFilter) => itemFilter.showItem)
    return <>

        {
            isAdmin && <Col xs={12} xl={8}>
                <Form.Item
                    // required
                    label="Phần trăm hoa hồng "
                    name="isCalcCommission"
                    valuePropName="checked"
                >
                    <Checkbox >
                        Phần trăm hoa hồng
                    </Checkbox>
                </Form.Item>
            </Col>
        }
        {
            isAdmin && <Col xs={12} xl={8}>
                <Form.Item
                    // required
                    label="Ghi đè người giới thiệu"
                    name="isOverrideReferrer"
                    valuePropName="checked"
                >
                    <Checkbox >
                        Ghi đè người giới thiệu
                    </Checkbox>
                </Form.Item>
            </Col>
        }
        {
            arrGeneral.map((itemMap, key) => <Col key={itemMap.id + key} xs={12} xl={8}>
                <Form.Item
                    name={itemMap.id}
                    rules={itemMap.rules || []}
                    label={<span>{itemMap.label}</span>}>
                    <CustomSelect
                        formInsert={formInsert}
                        placeholder={itemMap.placeholder}
                        id={itemMap.id}
                        onChange={(e) => {
                            if (itemMap.id === 'feature') {
                                formInsert.resetFields()
                                formInsert.setFieldsValue({
                                    source:(isHome||isFire) ?EInsuranceSource.PVI : EInsuranceSource.MIC,
                                })
                                formInsert.setFieldsValue({
                                    feature: e,
                                })
                            }
                        }}
                        options={itemMap.options}
                    />
                </Form.Item>
            </Col>)
        }
        <Col xs={12} xl={8}>
            <Form.Item
                getValueProps={(i) => ({ value: (i?.trimStart()) })}
                rules={[
                    {
                        required: true,
                        message: `Đơn vị sở hữu ${NOT_EMPTY}`,
                    },
                ]}
                name={'companyName'}
                label={<span>Đơn vị sở hữu</span>}>
                <CustomInput
                    placeholder={'Nhập tên đơn vị '}
                    id={'companyName'}
                />

            </Form.Item>
        </Col>
        <Col xs={12} xl={8}>
            <Form.Item
                name={'exchangeTime'}
                label={<span>Ngày giao dịch</span>}
                rules={[{ required: true, message: 'Ngày giao dịch không được để trống' }]}
            >
                <DatePicker
                    placeholder='Chọn ngày giao dịch'
                    className='w-100'
                    onChange={(date) => {
                    }} />
            </Form.Item>
        </Col>

    </>
};

export default GeneralInfomation;
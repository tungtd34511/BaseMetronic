import { Button, Col, Divider, Form, Modal, Row, notification } from "antd";
import React, { useEffect, useState } from "react";
import CustomDateRangePicker from "src/common/CustomDateRangePicker";
import CustomSelect from "src/common/CustomSelect";
import CustomBreadCrumb from "src/layout/CustomBreadCrumb";
import { RoutePath } from "src/layout/Sider";
import CustomTable from "src/common/CustomTable";
import {
  IContractOffline,
  useLazyGetContractOfflineQuery,
  usePostDataContractImportOfflineMutation,
  usePostDataContractOfflineMutation,
} from "store/APIs/contract";
import useIsMobile from "src/common/useIsMobile";
import CustomModal from "src/common/CustomModal";
import GeneralInfomation from "./component/GeneralInfomation";
import moment from "moment";
import CusomSpiner from "src/common/CusomSpiner";
import useRole, { EUserRole } from "src/hooks/useRole";
import CustomInput from "src/common/CustomInput";
import {
  ARR_INSURANCE_FEATURE,
  ARR_INSURANCE_SOURCE,
  EInsuranceFeature,
  EInsuranceSource,
} from "enums/insurance.enum";
import MotoAndAutoInsurance from "./InsuranceMotor";
import HomeInsurance from "./InsuranceHome";
import { useGetAgencyListQuery } from "store/APIs/user";
import HealInsurance from "./InsuranceHealth";
import FireInsurance from "./InsuranceFire";
import InsuranceRecipient from "./InsuranceRecipient";
import InsuranceBenifit from "./InsuranceBenifit";
import InsuranceHomeBenifit from "./InsuranceHomeBenifit";
import InsuranceFireBenifit from "./InsuranceFireBenifit";
import { DEFAULT_PAGE_START, DEFAULT_PARAMS_FILTER } from "store/APIs/const";
import {
  ConvertNameFeature,
  FORMAT_DATE,
  TIME_CLOSE_NOTIFICATION,
  TITLE_NOTIFICATION,
  removeNullValues,
} from "store/APIs/common";
import CustomSpiner from "src/common/CusomSpiner";
import UploadFiles from "src/common/Gallery/UploadFile";
import { ImportOutlined, UploadOutlined } from "@ant-design/icons";

const Contract = () => {
  const [paramsFilterDate, setParamsFilterDate] = useState({
    from: DEFAULT_PARAMS_FILTER.from,
    to: DEFAULT_PARAMS_FILTER.to,
  });
  const [formInsert] = Form.useForm();
  const [formFilter] = Form.useForm();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [showloading, setShowLoading] = useState(false);
  const [LazyGetContractOffline, { data, isLoading, isFetching, isSuccess }] =
    useLazyGetContractOfflineQuery();
  const [postDataContractImportOffline, dataContractImportOffline] =
    usePostDataContractImportOfflineMutation();
  const [postDataContractOffline] = usePostDataContractOfflineMutation();
  const isMobile = useIsMobile();
  const { userData } = useRole();
  const isAdmin = userData?.roles?.includes(EUserRole.ADMIN); //
  const type = Form.useWatch("feature", formInsert);
  const insuranceId =
    Form.useWatch("insuranceId", formFilter) ||
    formFilter.getFieldValue("insuranceId");
  const feature =
    Form.useWatch("feature", formFilter) || formFilter.getFieldValue("feature");
  const customerName =
    Form.useWatch("customerName", formFilter) ||
    formFilter.getFieldValue("customerName");
  const companyName =
    Form.useWatch("companyName", formFilter) ||
    formFilter.getFieldValue("companyName");
  const source =
    Form.useWatch("source", formFilter) || formFilter.getFieldValue("source");
  const page =
    Form.useWatch("page", formFilter) || formFilter.getFieldValue("page");
  const limit =
    Form.useWatch("limit", formFilter) || formFilter.getFieldValue("limit");

  const featureInsert = Form.useWatch("feature", formInsert);
  const companyNameInseart = Form.useWatch("companyName", formInsert);
  const exchangeTimeInsert = Form.useWatch("exchangeTime", formInsert);
  const referrerIdInsert = Form.useWatch("referrerId", formInsert);
  const isCalcCommissionInsert = Form.useWatch("isCalcCommission", formInsert);
  const fileUrlInsert = Form.useWatch("fileUrl", formInsert);

  const paramsFilter = {
    insuranceId,
    feature,
    customerName,
    companyName,
    source,
    limit,
    page,
    from: paramsFilterDate.from,
    to: paramsFilterDate.to,
  };

  const isMotor = type === EInsuranceFeature.MOTOR_01;
  const isAuto = type === EInsuranceFeature.AUTO_01;
  const isHome = type === EInsuranceFeature.HOME_01;
  const isHeal = type === EInsuranceFeature.HEALTH_01;
  const isFire = type === EInsuranceFeature.FIRE_01;

  const dataAgency = useGetAgencyListQuery(
    {
      page: 0,
      limit: 100000,
      search: "",
      admin: isAdmin,
    },
    {
      skip: !isAdmin,
    }
  );
  const converDataAgency = dataAgency?.data?.docs
    ? dataAgency?.data?.docs?.map((itemMap) => {
        return {
          ...itemMap,
          value: itemMap.id,
          label: itemMap.name,
        };
      })
    : [];

  const columns = [
    {
      title: "Mã HĐ",
      render: (data: IContractOffline) => <div>{data?.id}</div>,
    },
    {
      title: "Loại bảo hiểm",
      render: (data: IContractOffline) => <div>{data?.source}</div>,
    },
    // {
    //     title: 'Đơn vị sở hữu',
    //     render: (data: IContractOffline) => <div>{data?.source}</div>
    // },
    {
      title: "Người giới thiệu",
      render: (data: IContractOffline) => <div>{data?.referrer?.name}</div>,
    },
    {
      title: "Người mua",
      render: (data: IContractOffline) => <div>{data?.buyer?.name}</div>,
    },
    {
      title: "Loại hợp đồng",
      render: (data: IContractOffline) => (
        <div>{ConvertNameFeature(data?.feature)}</div>
      ),
    },
    {
      title: "Ngày giao dịch",
      render: (data: IContractOffline) => (
        <div>{moment(data?.createdAt).format(FORMAT_DATE)}</div>
      ),
    },
    // {
    //     title: 'Thao tác',
    //     render: (data: IContractOffline) => <div>
    //         <EditOutlined className='cursor-pointer' style={{ fontSize: '20px' }} />
    //         <DeleteOutlined onClick={() => {
    //             showConfirm()
    //         }} className='ml-12 cursor-pointer' style={{ fontSize: '20px' }} />
    //     </div>,
    // },
  ];

  const showConfirm = () => {
    Modal.confirm({
      okButtonProps: {
        className: "ant-btn ant-btn-danger",
      },
      title: TITLE_NOTIFICATION,
      content: "Xác nhận xóa hợp đồng này?",
      onOk() {
        console.log("Xác nhận");
      },
      onCancel() {
        console.log("Hủy bỏ");
      },
      cancelText: "Hủy",
      okText: "Xác nhận",
      closable: true,
    });
  };

  const arrFilter = [
    {
      id: "referrerId",
      label: "Người giới thiệu",
      options: converDataAgency,
      showItem: true,
      placeholder: "Chọn người giới thiệu",
    },
    {
      id: "source",
      label: "Loại bảo hiểm",
      options: ARR_INSURANCE_SOURCE,
      showItem: true,
      placeholder: "Chọn Loại bảo hiểm",
    },
    {
      id: "feature",
      label: "Loại hợp đồng",
      options: ARR_INSURANCE_FEATURE,
      showItem: true,
      placeholder: "Chọn loại hợp đồng",
    },
  ].filter((item) => item.showItem);
  const openNotification = () => {
    notification.open({
      message: TITLE_NOTIFICATION,
      description: "Thêm mới thành công",
      duration: TIME_CLOSE_NOTIFICATION,
    });
  };
  const openNotificationFail = () => {
    notification.open({
      message: TITLE_NOTIFICATION,
      description: "Có lỗi xảy ra",
      duration: TIME_CLOSE_NOTIFICATION,
    });
  };
  const handleSubmit = async (values: any) => {
    const {
      vehicleOwnerName,
      buyerPhone,
      beneficiaryName,
      beneficiaryPhone,
      beneficiaryAddress,
      beneficiaryEmail,
      beneficiaryIdCard,
      licensePlates,
      chassisNumber,
      engineNumber,
      capacity,
      manufacturingYear,
      expiry,
      startDate,
      source,
      fee,
      discountCode,
      companyName,
      referrerId,
      exchangeTime,
      feature,
      contractFile,
      //   ô tô
      userIntent,
      type,
      automaker,
      seats,
      label,
      vehicleLoad,
      // Nhà tư nhân
      packageTmp,
      homeProvince,
      homeDistrict,
      homeWard,
      homeLocation,
      homeAddress,
      homeRisk,
      homeUses,
      homeYearBuilt,
      isOverrideReferrer,
      isCalcCommission,
      //heal
      buyerAddress,
      buyerEmail,
      buyerIdCard,
      buyerGender,
      buyerBirthday,
      occupantInsurance,
      recipientPhone,
      recipientEmail,
      idCard,
      address,
      name,
      gender,
      birthday,
      homeOwnerName,
      attachedInsured,
      otherMedicalHistory,
    } = values;
    const cPrams = {
      vehicleOwnerName,
      buyerPhone,
      beneficiaryName,
      beneficiaryPhone,
      beneficiaryAddress,
      beneficiaryEmail,
      beneficiaryIdCard,
      licensePlates,
      occupantInsurance,
      chassisNumber,
      engineNumber,
      capacity,
      manufacturingYear:
        isMotor || isAuto ? moment(manufacturingYear).format("YYYY") : null,
      expiry,
      startDate,
      source,
      fee,
      discountCode,
      userIntent,
      type,
      automaker,
      seats,
      label,
      vehicleLoad: isAuto ? vehicleLoad || 0 : null,
      //nha tu nhan
      package: packageTmp,
      homeProvince,
      homeDistrict,
      homeWard,
      homeLocation: homeWard,
      homeAddress,
      homeRisk,
      homeUses,
      homeYearBuilt:
        isFire || isHome ? moment(homeYearBuilt).format("YYYY") : null,
      //y te
      buyerAddress,
      buyerEmail,
      buyerIdCard,
      buyerGender,
      buyerBirthday,
      recipientPhone,
      recipientEmail,
      idCard,
      address,
      name,
      gender,
      birthday,
      homeOwnerName,
      attachedInsured,
      otherMedicalHistory,
    };
    setShowLoading(true);
    console.log(values);
    const renderKey = () => {
      if (isAuto) return "auto";
      else if (isMotor) return "motor";
      else if (isHeal) return "health";
      else if (isFire) return "fire";
      else return "home";
    };
    const res: any = await postDataContractOffline({
      companyName,
      isOverrideReferrer: isAdmin ? isOverrideReferrer || false : null,
      isCalcCommission: isAdmin ? isCalcCommission || false : null,
      referrerId,
      feature,
      exchangeTime: moment(exchangeTime).toISOString(),
      [renderKey()]: isHeal
        ? {
            ...removeNullValues(cPrams),
            attachedInsured,
          }
        : removeNullValues(cPrams),
      contractFile,
    });
    if (res?.data === null) {
      setTimeout(() => {
        setShowLoading(false);
        openNotification();
        formInsert.resetFields();
        setIsModalOpen(false);
        LazyGetContractOffline(removeNullValues(DEFAULT_PARAMS_FILTER), false);
      }, 3000);
    } else {
      openNotificationFail();
      setShowLoading(false);
    }
  };
  useEffect(() => {
    LazyGetContractOffline(removeNullValues(DEFAULT_PARAMS_FILTER));
  }, []);
  const onDataChange = () => {
    const formData = formInsert.getFieldsValue();
    if (formData.fileUrl) {
      formInsert.setFieldsValue({
        fileUrl: formData?.fileUrl?.file?.response,
      });
    }
  };
  return (
    <div>
      {/* {(isFetching || showloading) && <CustomSpiner />} */}
      <Form
        initialValues={{
          // additionalBenefits: [false, true, false]
          items: [
            { nestedSwitches: [false, false] },
            { nestedSwitches: [false, false] },
          ],
        }}
        onFinish={handleSubmit}
        form={formInsert}
      >
        <CustomModal
          title="Tạo mới hợp đồng"
          handleCancel={() => {
            setIsModalOpen(false);
          }}
          handleOk={formInsert.submit}
          isModalOpen={isModalOpen}
          setIsModalOpen={setIsModalOpen}
        >
          {/* <Button
                onClick={async() => {
                    
    // const featureInsert = Form.useWatch('feature', formInsert)
    // const companyNameInseart = Form.useWatch('companyName', formInsert)
    // const exchangeTimeInsert = Form.useWatch('exchangeTime', formInsert)
    // const referrerIdInsert = Form.useWatch('referrerId', formInsert)
    // const isCalcCommissionInsert = Form.useWatch('isCalcCommission', formInsert)
    // const fileUrlInsert = Form.useWatch('fileUrl', formInsert)
                 await postDataContractImportOffline({
                    "feature": featureInsert,
                    "fileUrl": fileUrlInsert,
                    "companyName": companyNameInseart,
                    "exchangeTime": exchangeTimeInsert,
                    "referrerId": referrerIdInsert,
                    "isCalcCommission": isCalcCommissionInsert||false                  
                   })
                }}
                type="primary">
                Tạo mới
            </Button> */}
          <Row gutter={[12, 12]}>
            <Col xl={24} xs={24}>
              <h3>Thông tin chung</h3>
            </Col>
            <GeneralInfomation formInsert={formInsert} />
          </Row>
          <Row gutter={[12, 12]}>
            <Col xl={20} xs={12}>
              <h3>Thông tin hợp đồng</h3>
            </Col>
            {/* <Col xl={4} xs={12}>
                            <Form.Item
                                className='text-align-right'
                                name="fileUrl"
                                rules={[
                                    { required: true, message: "Không được để trống" },
                                ]}
                            >

                                <UploadFiles
                                    className='text-align-right'
                                    onChange={onDataChange}
                                    multiple={false}
                                    maxCount={1}
                                    accept={"Excel file |.xls, .xlsx"}
                                >
                                    <div>
                                        <Button icon={<UploadOutlined />}>Chọn tệp</Button>
                                    </div>
                                </UploadFiles>
                            </Form.Item>
                        </Col> */}
            {(isAuto || isMotor) && (
              <MotoAndAutoInsurance formInsert={formInsert} />
            )}
            {isHome && <HomeInsurance formInsert={formInsert} />}

            {isFire && (
              <>
                <FireInsurance formInsert={formInsert} />
              </>
            )}
            {isHeal && (
              <>
                <HealInsurance formInsert={formInsert} />
              </>
            )}
          </Row>
          {isAuto || isMotor || isFire || isHome || isHeal ? (
            <Row gutter={[12, 12]}>
              <Col xl={24} xs={24}>
                <h3>Thông tin người nhận hợp đồng</h3>
              </Col>
              {<InsuranceRecipient formInsert={formInsert} />}
            </Row>
          ) : (
            <></>
          )}
          {isFire ? (
            <Row gutter={[12, 12]}>
              <Col xl={24} xs={24}>
                <h3>Thông tin người thụ hưởng</h3>
              </Col>
              {<InsuranceBenifit formInsert={formInsert} />}
            </Row>
          ) : (
            <></>
          )}
          {isHome ? (
            <Row gutter={[12, 12]}>
              <Col xl={24} xs={24}>
                <h3>Thông tin nhà</h3>
              </Col>
              {<InsuranceHomeBenifit formInsert={formInsert} />}
            </Row>
          ) : (
            <></>
          )}
          {isFire ? (
            <Row gutter={[12, 12]}>
              <Col xl={24} xs={24}>
                <h3>Thông tin nhà</h3>
              </Col>
              {<InsuranceFireBenifit formInsert={formInsert} />}
            </Row>
          ) : (
            <></>
          )}
        </CustomModal>
      </Form>
      <CustomBreadCrumb
        items={[
          {
            title: "Hợp đồng",
            href: RoutePath.CONTRACT,
          },
        ]}
      />
      <Form
        initialValues={DEFAULT_PARAMS_FILTER}
        layout={"vertical"}
        form={formFilter}
      >
        <Row gutter={[12, 12]}>
          {/* insuranceId */}
          {/* <Col xs={24} lg={4} xl={4}>
                        <Form.Item
                            getValueProps={(i) => ({ value: (i?.trimStart()) })}
                            name={'insuranceId'}
                            label="Id hợp đồng">
                            <CustomInput
                                placeholder="Nhập tên Id hợp đồng" />
                        </Form.Item>
                    </Col> */}
          <Col xs={24} lg={4} xl={4}>
            <Form.Item
              getValueProps={(i) => ({ value: i?.trimStart() })}
              name={"customerName"}
              label="Người mua"
            >
              <CustomInput placeholder="Nhập tên người mua" />
            </Form.Item>
          </Col>
          <Col xs={24} lg={4} xl={4}>
            <Form.Item
              getValueProps={(i) => ({ value: i?.trimStart() })}
              name={"companyName"}
              label="Đơn vị sở hũu"
            >
              <CustomInput placeholder="Nhập tên đơn vị" />
            </Form.Item>
          </Col>
          {arrFilter.map((itemMap, key) => (
            <Col key={itemMap.id + key} xs={24} lg={4} xl={4}>
              <Form.Item
                getValueProps={(i) => ({ value: i?.trimStart() })}
                name={itemMap.id}
                label={itemMap.label}
              >
                <CustomSelect
                  {...itemMap}
                  formInsert={formFilter}
                  id={itemMap.id}
                  options={itemMap.options}
                />
              </Form.Item>
            </Col>
          ))}
          <Col xs={24} lg={4} xl={4}>
            <Form.Item label={"Ngày giao dịch"}>
              <CustomDateRangePicker
                startDate={paramsFilterDate.from}
                endDate={paramsFilterDate.to}
                onChange={(from, to) => {
                  setParamsFilterDate({
                    ...paramsFilter,
                    from: moment(from).toISOString(true),
                    to: moment(to).toISOString(true),
                  });
                }}
              />
            </Form.Item>
          </Col>
          <Col xs={24} lg={4} xl={4}>
            <Form.Item label=" ">
              <Button
                onClick={() => {
                  formFilter.setFieldsValue({
                    page: DEFAULT_PAGE_START,
                  });
                  LazyGetContractOffline(removeNullValues(paramsFilter));
                }}
                type="primary"
              >
                Tìm kiếm
              </Button>
              <Button
                className="ml-12"
                onClick={() => {
                  formFilter.resetFields();
                  setParamsFilterDate({
                    from: DEFAULT_PARAMS_FILTER.from,
                    to: DEFAULT_PARAMS_FILTER.to,
                  });
                  LazyGetContractOffline(
                    removeNullValues(DEFAULT_PARAMS_FILTER)
                  );
                }}
              >
                Đặt lại
              </Button>
            </Form.Item>
          </Col>
        </Row>
      </Form>
      <div className="pd-24" style={{ background: "white" }}>
        <div
          className={`d-flex  ${
            isMobile ? "flex-column" : "align-item-center flex-row"
          }`}
        >
          <h3 className="flex-1">Danh sách hợp đồng offline</h3>
          <Button
            className={`${!isMobile ? "ml-12" : "mgbt-12"} `}
            type="primary"
            danger
          >
            Xóa
          </Button>
          <Button
            type="primary"
            style={{
              background: "transparent",
              borderColor: "#18a0fb",
              color: "#18a0fb",
            }}
            icon={<ImportOutlined />}
            className={`${!isMobile ? "ml-12" : "mgbt-12"}`}
          >
            Import hợp đồng
          </Button>
          <Button
            onClick={() => {
              formInsert.resetFields();
              formInsert.setFieldsValue({
                feature: EInsuranceFeature.MOTOR_01,
              });
              formInsert.setFieldsValue({
                source: EInsuranceSource.MIC,
              });
              setIsModalOpen(true);
            }}
            className={`${!isMobile ? "ml-12" : "mgbt-12"}`}
            type="primary"
          >
            Tạo mới
          </Button>
        </div>
        <Divider />
        <CustomTable
          columns={columns}
          totalDocs={data?.totalDocs || 0}
          data={
            data?.docs?.map((itemMap, key) => {
              return {
                ...itemMap,
                key: key + itemMap.id,
              };
            }) || []
          }
          isLoading={false}
          onChange={(page, limit) => {
            if (paramsFilter.limit === limit) {
              formFilter.setFieldsValue({
                page,
              });
            } else {
              formFilter.setFieldsValue({
                page: DEFAULT_PAGE_START,
              });
            }
            const params = {
              ...paramsFilter,
              limit,
              page,
            };
            formFilter.setFieldsValue({
              limit,
            });

            LazyGetContractOffline(removeNullValues(params));
            window.scrollTo(0, 0);
          }}
          pageSize={limit}
          pageCurrent={page}
        />
      </div>
    </div>
  );
};
export default Contract;

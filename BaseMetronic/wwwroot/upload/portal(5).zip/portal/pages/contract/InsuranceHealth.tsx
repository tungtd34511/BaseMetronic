import { Button, Col, DatePicker, Form, FormInstance, Input, Switch } from 'antd';
import React, { useEffect, useState } from 'react';
import CustomInput from 'src/common/CustomInput';
import CustomSelect, { OptionType } from 'src/common/CustomSelect';
import { validateEmail, validateIdCard, validateMaxLength, validateNumberWithDots, validateOnlyNumber, validatePhoneNumber } from 'src/common/Validate';
import { ARR_INSURANCE_SOURCE, ARR_INSURANCE_SOURCE_HEALTH, EInsuranceFeature, EInsuranceSource } from 'enums/insurance.enum';
import { UploadOutlined } from '@ant-design/icons';
import UploadFiles from 'src/common/Gallery/UploadFile';
import CustomInputNumber from 'src/common/CustomInputPrice';
import { ARR_TYPE_MIC, HEALTH_CONDITION_BENIFIT_MIC, HEALTH_CONDITION_BIC, HEALTH_CONDITION_MIC, HEALTH_CONDITION_VBI, NOT_EMPTY, PRESS, TYPE_ARR_INPUT } from 'store/APIs/const';
import { ARR_GENDER, CAddress, CDiscountCode, CExpiry, CFeeInsurance, CGender, CIdCard, CStartDate, ECategory } from 'store/APIs/common';
import { useLazyGetUserIntentByPartnerIdQuery } from 'store/APIs/contract';
export interface IMotoInsurance {
    formInsert: FormInstance<any>
}
const HealInsurance = ({ formInsert }: IMotoInsurance) => {
    const [form] = Form.useForm();
    const [fields, setFields] = useState([]);

    const type = Form.useWatch('feature', formInsert);
    let attachedInsured = Form.useWatch('attachedInsured', formInsert);
    const joinNumber = Form.useWatch('joinNumber', formInsert);
    const typeInsurance = Form.useWatch('type', formInsert);
    const source = Form.useWatch('source', formInsert);
    const isMic = source === EInsuranceSource.MIC
    const isBic = source === EInsuranceSource.BIC
    const isVbi = source === EInsuranceSource.VBI
    const renderHealCondition = isVbi ? HEALTH_CONDITION_VBI : isBic ? HEALTH_CONDITION_BIC : HEALTH_CONDITION_MIC
    const renderHealConditionMic = HEALTH_CONDITION_BENIFIT_MIC
    let joinNumberTmp = joinNumber === undefined ? [1] : Array(Number(joinNumber)).fill(1)
    const fillArr = Array(renderHealCondition.length).fill(false)
    const fillArrBenifit = Array(HEALTH_CONDITION_BENIFIT_MIC.length).fill(false)
    const isHeal = type === EInsuranceFeature.HEALTH_01
    const [LazyGetHomePackageIdQuery, { data }] = useLazyGetUserIntentByPartnerIdQuery();
    const convertDataHealPackage = data ? data?.map((itemMap) => {
        return {
            ...itemMap,
            value: itemMap.Value,
            label: itemMap.Text
        }
    }).filter((itemFilter) => {
        return itemFilter?.Type === typeInsurance
    }) : []
    const ARR_INPUT_HEALTH = [
        {
            id: 'source',
            label: 'Nguồn BH',
            type: TYPE_ARR_INPUT.SELECT,
            options: ARR_INSURANCE_SOURCE_HEALTH,
            placeholder: `${PRESS} nguồn BH`,
            rules: [
                { required: true, message: `Nguồn BH ${NOT_EMPTY}` },
                {
                    pattern: validateMaxLength(30).regexPattern,
                    message: validateMaxLength(30).message
                },
            ],
            showItem: true,
        },
        {
            id: 'joinNumber',
            label: 'Số người tham gia',
            type: TYPE_ARR_INPUT.INPUT,
            placeholder: `${PRESS} Số người tham gia`,
            rules: isBic ? [
                {
                    required: true,
                    message: `Số người tham gia ${NOT_EMPTY}`
                },
                {
                    pattern: validateOnlyNumber().regexPattern,
                    message: validateOnlyNumber().message
                },
            ] : [],
            showItem: isBic,
        },
        {
            id: 'name',
            label: 'Tên người mua',
            type: TYPE_ARR_INPUT.INPUT,
            placeholder: `${PRESS} tên người mua`,
            rules: [
                {
                    required: true,
                    message: `Tên người mua ${NOT_EMPTY}`
                },
                {
                    pattern: validateMaxLength(50).regexPattern,
                    message: validateMaxLength(50).message
                },
            ],
            showItem: true,
        },
        CAddress('address', true),
        CIdCard('idCard', true),
        CGender('gender', true),
        {
            id: 'birthday',
            label: 'Ngày sinh',
            type: TYPE_ARR_INPUT.DATE_PICKER,
            placeholder: `${PRESS} ngày sinh`,
            rules: [{ required: true, message: `Ngày sinh ${NOT_EMPTY}` }],
            showItem: true,
        },
        CExpiry(['1']),

        {
            id: 'type',
            label: 'Loại bảo hiểm',
            type: TYPE_ARR_INPUT.SELECT,
            placeholder: `${PRESS} Loại bảo hiểm`,
            options: ARR_TYPE_MIC,
            rules: isMic ? [
                { required: true, message: `Loại bảo hiểm ${NOT_EMPTY}` },
            ] : [],
            showItem: isMic,
        },
        {
            id: 'packageTmp',
            label: 'Gói bảo hiểm',
            type: TYPE_ARR_INPUT.SELECT,
            placeholder: `${PRESS} Gói bảo hiểm`,
            options: convertDataHealPackage,
            rules: [
                { required: true, message: `Gói bảo hiểm ${NOT_EMPTY}` },
            ],
            showItem: true,
        },

        CFeeInsurance('fee', true),
        CStartDate(),
        CDiscountCode('discountCode', true),
    ]

    const ARR_INPUT_HEALTH_ATTCH = [
        {
            id: 'name',
            label: 'Tên',
            type: TYPE_ARR_INPUT.INPUT,
            placeholder: `${PRESS} tên`,
            rules: [
                {
                    required: true,
                    message: `Tên ${NOT_EMPTY}`
                },
                {
                    pattern: validateMaxLength(50).regexPattern,
                    message: validateMaxLength(50).message
                },
            ],
            showItem: true,
        },
        {
            id: 'gender',
            label: 'Giới tính',
            type: TYPE_ARR_INPUT.SELECT,
            options: ARR_GENDER,
            placeholder: `${PRESS} Giới tính`,
            rules: [
                { required: true, message: `Giới tính ${NOT_EMPTY}` },
                {
                    pattern: validateMaxLength(30).regexPattern,
                    message: validateMaxLength(30).message
                },
            ],
            showItem: true,
        },
        {
            id: 'birthday',
            label: 'Ngày sinh',
            type: TYPE_ARR_INPUT.DATE_PICKER,
            placeholder: `${PRESS} ngày sinh`,
            rules: [{ required: true, message: `Ngày sinh ${NOT_EMPTY}` }],
            showItem: true,
        },
        {
            id: 'address',
            label: 'Địa chỉ',
            type: TYPE_ARR_INPUT.INPUT,
            placeholder: `${PRESS} Địa chỉ`,
            rules: [
                {
                    required: true,
                    message: `Địa chỉ ${NOT_EMPTY}`
                },
                {
                    pattern: validateMaxLength(100).regexPattern,
                    message: validateMaxLength(100).message
                },
            ],
            showItem: true,
        },
        CIdCard('idCard', true),
        {
            id: 'phone',
            label: 'Số điện thoại',
            type: TYPE_ARR_INPUT.INPUT,
            placeholder: `${PRESS} số điện thoại`,
            rules: [
                { required: true, message: `Số điện thoại ${NOT_EMPTY}` },
                {
                    pattern: validatePhoneNumber().regexPattern,
                    message: validatePhoneNumber().message
                },

            ],
            showItem: true,
        },
        {
            id: 'otherMedicalHistory',
            label: 'Tiểu sử bệnh khác',
            type: TYPE_ARR_INPUT.INPUT,
            placeholder: `${PRESS} Tiểu sử bệnh khác`,
            rules: [
                { required: true, message: `Tiểu sử bệnh khác ${NOT_EMPTY}` },

            ],
            showItem: true,
        },
        {
            id: 'additionalBenefits',
            label: `Quyền lợi bổ xung`,
            type: TYPE_ARR_INPUT.SWITCH,
            placeholder: `${PRESS} Quyền lợi bổ xung`,
            showItem: (isMic || isVbi),
            optionSwitch: renderHealConditionMic
        },
        {
            id: 'medicalHistory',
            label: `Tình trạng sức khỏe`,
            type: TYPE_ARR_INPUT.SWITCH,
            placeholder: `${PRESS} Tình trạng sức khỏe`,
            showItem: (isMic || isBic),
            optionSwitch: renderHealCondition
        },

    ].filter((itemFilter) => itemFilter.showItem)
    const onDataChange = () => {
        const formData = formInsert.getFieldsValue();
        if (formData.contractFile) {
            formInsert.setFieldsValue({
                contractFile: formData?.contractFile?.file?.response,
            })
        }
    };
    useEffect(() => {
        if (isHeal) {
            LazyGetHomePackageIdQuery({
                name: ECategory.HEALTH_PACKAGES,
                source: source || EInsuranceSource.MIC
            })
        }
    }, [isHeal, source])
    useEffect(() => {
        if (attachedInsured === undefined) {
            if (isVbi) {
                formInsert.setFieldsValue({
                    attachedInsured: [
                        {
                            additionalBenefits: fillArr,
                            medicalHistory: []
                        }
                    ],
                })

            } else if (isBic) {
                formInsert.setFieldsValue({
                    attachedInsured: [
                        {
                            additionalBenefits: [],
                            medicalHistory: fillArr
                        }
                    ],
                })
            }
            else if (isMic) {
                formInsert.setFieldsValue({
                    attachedInsured: [
                        {
                            additionalBenefits: fillArrBenifit,
                            medicalHistory: fillArr
                        }
                    ],
                })
            }
        } else {
            if (isVbi) {
                formInsert.setFieldsValue({
                    attachedInsured: [
                        {
                            additionalBenefits: fillArr,
                            medicalHistory: []
                        }
                    ],
                })
            } else if (isBic) {
                const attachedInsured = joinNumberTmp.map((itemMap) => {
                    return {
                        additionalBenefits: [],
                        medicalHistory: fillArr
                    }
                })

                formInsert.setFieldsValue({
                    attachedInsured,
                })
            }
            else if (isMic) {
                formInsert.setFieldsValue({
                    attachedInsured: [
                        {
                            additionalBenefits: fillArrBenifit,
                            medicalHistory: fillArr
                        }
                    ],
                })
            }
        }
    }, [isBic, isMic, isVbi, joinNumber])
    const handleAddField = () => {
        const newFields = [...fields, { value: `value${fields.length}`, name: `newField${fields.length}`, rules: [{ required: true, message: 'Field is required' }] }];
        setFields(newFields as []);
    };

    const handleRemoveField = (index: number) => {
        const newFields = [...fields];
        newFields.splice(index, 1);
        setFields(newFields);
    };
    const onFinish = (values: any) => {
        console.log('Received values of form: ', values);
    };
    console.log(attachedInsured);
    return <>


        {
            ARR_INPUT_HEALTH.map((itemMap, key) => <Col
                style={{
                    display: itemMap.showItem ? "block" : "none"
                }}
                key={itemMap.id + key} xs={12} xl={8}>
                {
                    itemMap.type === TYPE_ARR_INPUT.INPUT && <Form.Item
                        getValueProps={(i) => ({ value: (i?.trimStart()) })}
                        name={itemMap.id}
                        rules={itemMap.rules || []}
                        label={<span>{itemMap.label}</span>}>
                        <CustomInput

                            placeholder={itemMap.placeholder}
                            id={itemMap.id}
                        />
                    </Form.Item>
                }
                {
                    itemMap.type === TYPE_ARR_INPUT.INPUT_PRICE && <CustomInputNumber
                        itemMap={itemMap}
                    />
                }
                {
                    itemMap.type === TYPE_ARR_INPUT.DATE_PICKER && <Form.Item
                        name={itemMap.id}
                        rules={itemMap.rules || []}
                        label={<span>{itemMap.label}</span>}>
                        <DatePicker
                            className='w-100'
                            placeholder={itemMap.placeholder}
                            id={itemMap.id}
                        />
                    </Form.Item>
                }
                {
                    itemMap.type === TYPE_ARR_INPUT.SELECT && <Form.Item
                        name={itemMap.id}
                        rules={itemMap.rules || []}
                        label={<span>{itemMap.label}</span>}>
                        <CustomSelect
                            formInsert={formInsert}
                            onChange={() => {
                                if (itemMap.id === 'type') {
                                    formInsert.setFieldsValue({
                                        packageTmp: '',
                                    })
                                }
                                if (itemMap.id === 'source') {
                                    formInsert.setFieldsValue({
                                        joinNumber: undefined,


                                    })
                                }
                            }}
                            id={itemMap.id}
                            options={(itemMap.options || []) as OptionType[]}
                        />
                    </Form.Item>
                }

            </Col>)
        }
        <Col xs={12} xl={8}>
            <Form.Item
                required
                label="Upload hợp đồng "
                name="contractFile"
                rules={[
                    { required: true, message: "Không được để trống" },
                ]}
            >
                <UploadFiles
                    onChange={onDataChange}
                    multiple={false}
                    maxCount={1}
                    accept={"Excel file |.xls, .xlsx"}
                >
                    <div>
                        <Button icon={<UploadOutlined />}>Chọn tệp</Button>
                    </div>
                </UploadFiles>
            </Form.Item>
        </Col>
        <Form.List name="attachedInsured">
            {(fields, { add, remove }) => {
                return (
                    <>
                        {
                            joinNumberTmp.map((itemMapTmp, keyParent) => {
                                return <>
                                    <Col xl={24} xs={24}>
                                        <h3>Thông tin người được bảo hiểm {keyParent + 1}</h3>
                                    </Col>
                                    {
                                        ARR_INPUT_HEALTH_ATTCH.map((itemMap: any, key) => {
                                            return <Col key={itemMap.id + key} xs={12} xl={8}>
                                                {
                                                    itemMap.type === TYPE_ARR_INPUT.INPUT && <Form.Item
                                                        getValueProps={(i) => ({ value: (i?.trimStart()) })}
                                                        // name={itemMap.id+`${keyParent}`}
                                                        name={[keyParent, itemMap.id]}
                                                        rules={itemMap.rules || []}
                                                        label={<span>{itemMap.label}</span>}>
                                                        <CustomInput

                                                            placeholder={itemMap.placeholder}
                                                            id={itemMap.id}
                                                        />
                                                    </Form.Item>
                                                }

                                                {
                                                    itemMap.type === TYPE_ARR_INPUT.DATE_PICKER && <Form.Item
                                                        name={[keyParent, itemMap.id]}
                                                        rules={itemMap.rules || []}
                                                        label={<span>{itemMap.label}</span>}>
                                                        <DatePicker
                                                            className='w-100'
                                                            placeholder={itemMap.placeholder}
                                                            id={itemMap.id}
                                                        />
                                                    </Form.Item>
                                                }
                                                {
                                                    itemMap.type === TYPE_ARR_INPUT.SELECT && <Form.Item
                                                        name={[keyParent, itemMap.id]}
                                                        rules={itemMap.rules || []}
                                                        label={<span>{itemMap.label}</span>}>
                                                        <CustomSelect
                                                            formInsert={formInsert}

                                                            id={itemMap.id}
                                                            options={(itemMap.options || []) as OptionType[]}
                                                        />
                                                    </Form.Item>
                                                }
                                                {
                                                    itemMap.type === TYPE_ARR_INPUT.SWITCH && <>
                                                        <Form.Item
                                                            label={<span>{itemMap.label}</span>}>

                                                            <div>
                                                                {
                                                                    itemMap.optionSwitch.map((itemMapSwitch: any, keyParent1: number) => {

                                                                        return <>
                                                                            <div style={{ marginBottom: '12px' }}>

                                                                                {
                                                                                    <>
                                                                                        <div style={{ marginBottom: '12px' }}>
                                                                                            <div className='d-flex'>
                                                                                                <div className='flex-1'>{itemMapSwitch.label}</div>
                                                                                                <Switch
                                                                                                    onChange={(e) => {
                                                                                                        if (isVbi) {
                                                                                                            attachedInsured?.[keyParent]?.additionalBenefits?.splice(keyParent1, 1, e);
                                                                                                        }
                                                                                                        else if (isBic) {
                                                                                                            attachedInsured?.[keyParent]?.medicalHistory?.splice(keyParent1, 1, e);
                                                                                                        }
                                                                                                        else if (isMic) {
                                                                                                            console.log('calll');
                                                                                                            if (itemMap.id === 'medicalHistory') {
                                                                                                                console.log(attachedInsured);
                                                                                                                attachedInsured?.[keyParent]?.medicalHistory?.splice(keyParent1, 1, e);
                                                                                                            }
                                                                                                            else if (itemMap.id === 'additionalBenefits') {
                                                                                                                attachedInsured?.[keyParent]?.additionalBenefits?.splice(keyParent1, 1, e);
                                                                                                            }
                                                                                                            console.log(attachedInsured);
                                                                                                        }
                                                                                                        formInsert.setFieldsValue({
                                                                                                            attachedInsured,
                                                                                                        })
                                                                                                    }}
                                                                                                />

                                                                                            </div>
                                                                                        </div>
                                                                                    </>
                                                                                }

                                                                            </div >
                                                                        </>
                                                                    })
                                                                }
                                                            </div>
                                                        </Form.Item>
                                                    </>
                                                }
                                            </Col>
                                        })
                                    }
                                </>
                            })
                        }
                    </>
                );
            }}
        </Form.List >
    </>
};

export default HealInsurance;
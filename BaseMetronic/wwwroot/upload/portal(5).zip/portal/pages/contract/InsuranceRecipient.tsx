import { Col, Form } from 'antd';
import React from 'react';
import CustomInput from 'src/common/CustomInput';
import { IMotoInsurance } from './InsuranceFire';
import { CEmail, CPhoneNumber } from 'store/APIs/common';
const InsuranceRecipient = ({ formInsert }: IMotoInsurance) => {
    const type = Form.useWatch('feature', formInsert);
    const ARR_INPUT_BENIFIT = [
        CEmail('recipientEmail', true),
        CPhoneNumber('recipientPhone', true)
    ]
    return <>
        {
            ARR_INPUT_BENIFIT.map((itemMap, key) => <Col key={itemMap.id + key} xs={12} xl={8}>
                {
                    <Form.Item
                        getValueProps={(i) => ({ value: (i?.trimStart()) })}
                        name={itemMap.id}
                        rules={itemMap.rules || []}
                        label={<span>{itemMap.label}</span>}>
                        <CustomInput
                            placeholder={itemMap.placeholder}
                            id={itemMap.id}
                        />
                    </Form.Item>
                }

            </Col>)
        }
    </>
};

export default InsuranceRecipient;
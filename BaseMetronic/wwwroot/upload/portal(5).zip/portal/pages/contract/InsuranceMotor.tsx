import { Button, Col, DatePicker, Form, FormInstance } from 'antd';
import React, { useEffect } from 'react';
import CustomInput from 'src/common/CustomInput';
import CustomSelect, { OptionType } from 'src/common/CustomSelect';
import { validateChasisNumberAndEngineNumber, validateMaxLength, validateOnlyNumber } from 'src/common/Validate';
import { ARR_INSURANCE_SOURCE_MOTOR_AND_AUTO, EAutoUserIntentValue, EInsuranceFeature, EInsuranceSource } from 'enums/insurance.enum';
import { useLazyGetUserIntentByPartnerIdQuery } from 'store/APIs/contract';
import { UploadOutlined } from '@ant-design/icons';
import UploadFiles from 'src/common/Gallery/UploadFile';
import CustomInputNumber from 'src/common/CustomInputPrice';
import { NOT_EMPTY, PRESS, TYPE_ARR_INPUT } from 'store/APIs/const';
import { CAddress, CDiscountCode, CExpiry, CFeeInsurance, CIdCard, CStartDate, ECategory, UNIT_MILLION } from 'store/APIs/common';
export interface IMotoInsurance {
    formInsert: FormInstance<any>
}


const MotoAndAutoInsurance = ({ formInsert }: IMotoInsurance) => {
    const type = Form.useWatch('feature', formInsert);
    const source = Form.useWatch('source', formInsert);
    const userIntent = Form.useWatch('userIntent', formInsert);
    const isMotor = type === EInsuranceFeature.MOTOR_01
    const isAuto = type === EInsuranceFeature.AUTO_01
    const [LazyGetUserIntentByPartnerIdQuery, { data }] = useLazyGetUserIntentByPartnerIdQuery();
    // const [LazyGetTypeInsuranceCategoryCodeQuery, dataAutoType] = useLazyGetAutoInsuranceCategoryCodeQuery();
    const [LazyGetLabelInsuranceCategoryQuery, dataAutoLabel] = useLazyGetUserIntentByPartnerIdQuery();
    const [LazyGetAutoMarkerInsuranceCategoryCodeQuery, dataAutoMarker] = useLazyGetUserIntentByPartnerIdQuery();
    const [LazyGetTypeMotoerQuery, dataTypeMotor] = useLazyGetUserIntentByPartnerIdQuery();
    const [LazyGetTypeAutoQuery, dataTypeAuto] = useLazyGetUserIntentByPartnerIdQuery();
    const convertDataAutoType = dataTypeAuto?.data ? dataTypeAuto?.data?.map((itemMap) => {
        return {
            ...itemMap,
            value: itemMap.Value,
            label: itemMap.Text
        }
    }) : []
    const convertDataMotorType = dataTypeMotor?.data ? dataTypeMotor?.data?.map((itemMap) => {
        return {
            ...itemMap,
            value: itemMap.Value,
            label: itemMap.Text
        }
    }) : []
    const convertDataAutoLabel = dataAutoLabel?.data ? dataAutoLabel?.data?.map((itemMap) => {
        return {
            ...itemMap,
            value: itemMap.Value,
            label: itemMap.Text
        }
    }) : []
    const convertDataAutoMarker = dataAutoMarker?.data ? dataAutoMarker?.data?.map((itemMap) => {
        return {
            ...itemMap,
            value: itemMap.Value,
            label: itemMap.Text
        }
    }) : []

    const convertDataUseIntent = data ? data?.map((itemMap) => {
        return {
            ...itemMap,
            value: itemMap.Value,
            label: itemMap.Text
        }
    }) : []
    //useLazyGetUserIntentByPartnerIdQuery
    const needVehicleLoad = [
        EAutoUserIntentValue.H_K,
        EAutoUserIntentValue.H,
        EAutoUserIntentValue.KD,
        EAutoUserIntentValue.KKD
    ].includes(userIntent as any);


    const ARR_INPUT_MOTOR = [
        {
            id: 'vehicleOwnerName',
            label: 'Tên chủ xe',
            type: TYPE_ARR_INPUT.INPUT,
            placeholder: `${PRESS} tên chủ xe`,
            rules: [
                {
                    required: true,
                    message: `Tên chủ xe ${NOT_EMPTY}`
                },
                {
                    pattern: validateMaxLength(50).regexPattern,
                    message: validateMaxLength(50).message
                },
            ],
            showItem: (isMotor || isAuto),
        },
        CIdCard('idCard', true),
        CAddress('address', true),
        {
            id: 'source',
            label: 'Nguồn BH',
            type: TYPE_ARR_INPUT.SELECT,
            options: ARR_INSURANCE_SOURCE_MOTOR_AND_AUTO,
            placeholder: `${PRESS} nguồn BH`,
            rules: [
                { required: true, message: `Nguồn BH ${NOT_EMPTY}` },
                {
                    pattern: validateMaxLength(30).regexPattern,
                    message: validateMaxLength(30).message
                },
            ],
            showItem: (isMotor || isAuto),
        },
        {
            id: 'userIntent',
            label: 'Mục đích sử dụng',
            type: TYPE_ARR_INPUT.SELECT,
            placeholder: `${PRESS} Mục đích sử dụng`,
            options: convertDataUseIntent,
            rules: [
                { required: true, message: `Mục đích sử dụng ${NOT_EMPTY}` },
            ],
            showItem: (isAuto),
        },
        {
            id: 'type',
            label: 'Loại xe',
            type: TYPE_ARR_INPUT.SELECT,
            placeholder: `${PRESS} Loại xe`,
            options: convertDataAutoType,
            rules: [
                { required: true, message: `Loại xe ${NOT_EMPTY}` },
            ],
            showItem: (isAuto),
        },
        {
            id: 'automaker',
            label: 'Hãng xe',
            type: TYPE_ARR_INPUT.SELECT,
            placeholder: `${PRESS} Hãng xe`,
            options: convertDataAutoMarker,
            rules: [
                { required: true, message: `Hãng xe ${NOT_EMPTY}` },
            ],
            showItem: (isAuto),
        },
        {
            id: 'label',
            label: 'Dòng xe',
            type: TYPE_ARR_INPUT.SELECT,
            placeholder: `${PRESS} Dòng xe`,
            options: convertDataAutoLabel,
            rules: [
                { required: true, message: `Dòng xe ${NOT_EMPTY}` },
            ],
            showItem: (isAuto),
        },
        {
            id: 'seats',
            label: 'Số chỗ ngồi',
            type: TYPE_ARR_INPUT.INPUT,
            placeholder: `${PRESS} Số chỗ ngồi`,
            rules: [
                { required: true, message: `Số chỗ ngồi ${NOT_EMPTY}` },
                {
                    pattern: validateMaxLength(2).regexPattern,
                    message: validateMaxLength(2).message
                },
                {
                    pattern: validateOnlyNumber().regexPattern,
                    message: validateOnlyNumber().message
                },

            ],
            showItem: (isAuto),
        },
        {
            id: 'vehicleLoad',
            label: 'Trọng tải',
            type: TYPE_ARR_INPUT.INPUT,
            placeholder: `${PRESS} Trọng tải`,
            rules: [
                { required: true, message: `Trọng tải ${NOT_EMPTY}` },
                {
                    pattern: validateMaxLength(10).regexPattern,
                    message: validateMaxLength(10).message
                },
            ],
            showItem: (isAuto && needVehicleLoad),
        },
        {
            id: 'licensePlates',
            label: 'Biển số xe',
            type: TYPE_ARR_INPUT.INPUT,
            placeholder: `${PRESS} biển số xe`,
            rules: [
                { required: true, message: `Biển số xe ${NOT_EMPTY}` },
                {
                    pattern: validateMaxLength(10).regexPattern,
                    message: validateMaxLength(10).message
                },
            ],
            showItem: (isMotor || isAuto),
        },
        {
            id: 'chassisNumber',
            label: 'Số khung',
            type: TYPE_ARR_INPUT.INPUT,
            placeholder: `${PRESS} Số khung`,
            rules: [
                { required: true, message: `Số khung ${NOT_EMPTY}` },
                {
                    pattern: validateChasisNumberAndEngineNumber(isMotor ? 5 : 8).regexPattern,
                    message: `Số khung phải có tối thiểu ${isMotor ? 5 : 8} và tối đa 30 ký tự `
                },
            ],
            showItem: (isMotor || isAuto),
        },
        {
            id: 'engineNumber',
            label: 'Số máy',
            type: TYPE_ARR_INPUT.INPUT,
            placeholder: `${PRESS} Số máy`,
            rules: [
                { required: true, message: `Số máy ${NOT_EMPTY}` },
                {
                    pattern: validateChasisNumberAndEngineNumber(isMotor ? 5 : 8).regexPattern,
                    message: `Số máy phải có tối thiểu ${isMotor ? 5 : 8} và tối đa 30 ký tự `
                },
            ],
            showItem: (isMotor || isAuto),
        },
        {
            id: 'capacity',
            label: 'Dung tích',
            type: TYPE_ARR_INPUT.SELECT,
            placeholder: `${PRESS} Dung tích`,
            options: convertDataMotorType,
            rules: [{ required: true, message: `Dung tích ${NOT_EMPTY}` },],
            showItem: (isMotor),
        },
        {
            id: 'occupantInsurance',
            label: 'Mức bảo hiểm',
            type: TYPE_ARR_INPUT.SELECT,
            placeholder: `${PRESS} Mức bảo hiểm`,
            options: isMotor ? [
                {
                    value: 10 * UNIT_MILLION,
                    label: '10.000.000 đ / người / vụ'
                },
                {
                    value: 15 * UNIT_MILLION,
                    label: '15.000.000 đ / người / vụ'
                },
                {
                    value: 20 * UNIT_MILLION,
                    label: '20.000.000 đ / người / vụ'
                },
                {
                    value: 25 * UNIT_MILLION,
                    label: '25.000.000 đ / người / vụ'
                },
                {
                    value: 30 * UNIT_MILLION,
                    label: '30.000.000 đ / người / vụ'
                }
            ] : [
                {
                    value: 10 * UNIT_MILLION,
                    label: '10.000.000 đ / người / vụ'
                },
                {
                    value: 20 * UNIT_MILLION,
                    label: '20.000.000 đ / người / vụ'
                },
                {
                    value: 30 * UNIT_MILLION,
                    label: '30.000.000 đ / người / vụ'
                },
                {
                    value: 40 * UNIT_MILLION,
                    label: '40.000.000 đ / người / vụ'
                },
                {
                    value: 50 * UNIT_MILLION,
                    label: '50.000.000 đ / người / vụ'
                },
                {
                    value: 100 * UNIT_MILLION,
                    label: '100.000.000 đ / người / vụ'
                },
            ],
            showItem: (isMotor || isAuto),
        },
        {
            id: 'manufacturingYear',
            label: 'Năm sản xuất',
            type: TYPE_ARR_INPUT.DATE_PICKER,
            placeholder: `${PRESS} năm sản xuất`,
            rules: [{ required: true, message: `Năm sản xuất ${NOT_EMPTY}` }],
            showItem: (isMotor || isAuto),
        },
        CExpiry(isMotor ? ["1", '2', '3'] : ['1'], 'năm', (isMotor || isAuto)),
        CStartDate(),
        CFeeInsurance('fee', true),
        CDiscountCode('discountCode', true),
    ].filter((itemFilter) => itemFilter.showItem)
    const onDataChange = () => {
        const formData = formInsert.getFieldsValue();
        if (formData.contractFile) {
            formInsert.setFieldsValue({
                contractFile: formData?.contractFile?.file?.response,
            })
        }
    };
    useEffect(() => {
        if (isAuto) {
            LazyGetUserIntentByPartnerIdQuery({
                name: source === EInsuranceSource.VBI ? ECategory.MDSD_VBI_AUTO : ECategory.MDSD_AUTO,
                source: source || EInsuranceSource.MIC
            })
            LazyGetAutoMarkerInsuranceCategoryCodeQuery({
                name: ECategory.HIEUXEAUTO,
                source: source || EInsuranceSource.MIC
            })
            LazyGetTypeAutoQuery({
                name: ECategory.AUTO_TYPE,
            })
        }
        if (isMotor) {
            LazyGetTypeMotoerQuery({
                name: ECategory.LOAIXEMOTOR,
            })
        }
    }, [isAuto, isMotor, source])
    return <>
        {
            ARR_INPUT_MOTOR.map((itemMap, key) => <Col key={itemMap.id + key} xs={12} xl={8}>
                {
                    itemMap.type === TYPE_ARR_INPUT.INPUT && <Form.Item
                        getValueProps={(i) => ({ value: (i?.trimStart()) })}
                        name={itemMap.id}
                        rules={itemMap.rules || []}
                        label={<span>{itemMap.label}</span>}>
                        <CustomInput
                            placeholder={itemMap.placeholder}
                        />
                    </Form.Item>
                }
                {
                    itemMap.type === TYPE_ARR_INPUT.INPUT_PRICE && <CustomInputNumber
                        itemMap={itemMap}
                    />
                }

                {
                    itemMap.type === TYPE_ARR_INPUT.DATE_PICKER && <Form.Item
                        name={itemMap.id}
                        rules={itemMap.rules || []}
                        label={<span>{itemMap.label}</span>}>
                        <DatePicker
                            picker='year'
                            className='w-100'
                            placeholder={itemMap.placeholder}
                        />
                    </Form.Item>
                }
                {
                    itemMap.type === TYPE_ARR_INPUT.SELECT && <Form.Item
                        name={itemMap.id}
                        rules={itemMap.rules || []}
                        label={<span>{itemMap.label}</span>}>
                        <CustomSelect
                            formInsert={formInsert}
                            onChange={async (e) => {
                                if (itemMap.id === 'source') {
                                    if (isAuto) {
                                        LazyGetUserIntentByPartnerIdQuery({
                                            name: e === EInsuranceSource.VBI ? ECategory.MDSD_VBI_AUTO : ECategory.MDSD_AUTO,
                                            source: e
                                        })
                                    }
                                }
                                if (itemMap.id === 'userIntent') {
                                    LazyGetTypeMotoerQuery({
                                        userIntent: e
                                    })
                                    formInsert.setFieldsValue({
                                        type: null,
                                    })
                                }
                                if (itemMap.id === 'automaker') {
                                    LazyGetLabelInsuranceCategoryQuery({
                                        name: ECategory.DONGXE,
                                        source,
                                        selectedValue: e
                                    })
                                    formInsert.setFieldsValue({
                                        label: null,
                                    })
                                }
                            }}
                            id={itemMap.id}
                            options={(itemMap?.options || []) as OptionType[]}
                        />
                    </Form.Item>
                }
            </Col>)
        }
        <Col xs={12} xl={8}>
            <Form.Item
                required
                label="Upload hợp đồng "
                name="contractFile"
                rules={[
                    { required: true, message: "Không được để trống" },
                ]}
            >
                <UploadFiles
                    onChange={onDataChange}
                    multiple={false}
                    maxCount={1}
                    accept={"Excel file |.xls, .xlsx"}
                >
                    <div>
                        <Button icon={<UploadOutlined />}>Chọn tệp</Button>
                    </div>
                </UploadFiles>
            </Form.Item>
        </Col>
    </>
};

export default MotoAndAutoInsurance;
import { Col, Form } from 'antd';
import React from 'react';
import CustomInput from 'src/common/CustomInput';
import { IMotoInsurance } from './InsuranceFire';
import { PRESS, TYPE_ARR_INPUT } from 'store/APIs/const';
import { CAddress } from 'store/APIs/common';
const InsuranceBenifit = ({ formInsert }: IMotoInsurance) => {
    const type = Form.useWatch('feature', formInsert);
    const ARR_INPUT_MOTOR_BENIFIT = [
        {
            id: 'beneficiaryName',
            label: 'Tên',
            type: TYPE_ARR_INPUT.INPUT,
            placeholder: `${PRESS} Tên `,
        },
        CAddress('beneficiaryAddress', true),
    ]
    return <>
        {
            ARR_INPUT_MOTOR_BENIFIT.map((itemMap, key) => <Col key={itemMap.id + key} xs={12} xl={8}>
                {
                    <Form.Item
                        getValueProps={(i) => ({ value: (i?.trimStart()) })}
                        name={itemMap.id}
                        // rules={itemMap.rules || []}
                        label={<span>{itemMap.label}</span>}>
                        <CustomInput
                            placeholder={itemMap.placeholder}
                            id={itemMap.id}
                        />
                    </Form.Item>
                }

            </Col>)
        }
    </>
};

export default InsuranceBenifit;
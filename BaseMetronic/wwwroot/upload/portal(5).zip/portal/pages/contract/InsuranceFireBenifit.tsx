import { Col, Form,DatePicker } from 'antd';
import React, { useEffect, useState } from 'react';
import CustomInput from 'src/common/CustomInput';
import { IMotoInsurance } from './InsuranceFire';
import { validateMaxLength } from 'src/common/Validate';
import { useLazyGetUserIntentByPartnerIdQuery } from 'store/APIs/contract';
import { EInsuranceFeature, EInsuranceSource } from 'enums/insurance.enum';
import CustomSelect, { OptionType } from 'src/common/CustomSelect';
import { NOT_EMPTY, PRESS, TYPE_ARR_INPUT } from 'store/APIs/const';
import { ECategory } from 'store/APIs/common';
const InsuranceFireBenifit = ({ formInsert }: IMotoInsurance) => {
    const type = Form.useWatch('feature', formInsert);
    const isFire = type === EInsuranceFeature.FIRE_01

    const [LazyGetDataProvinceIdQuery, dataProvince] = useLazyGetUserIntentByPartnerIdQuery();
    const [dataDistrict, setDataDistrict] = useState([])
    const [dataWard, setDataWard] = useState([])
    const convertDataProvince = dataProvince?.data ? dataProvince?.data?.map((itemMap: any) => {
        return {
            ...itemMap,
            value: itemMap.code,
            label: itemMap.name
        }
    }) : []
    const ARR_INPUT_HOME = [

      
        {
            id: 'homeProvince',
            label: 'Tỉnh/Thành phố',
            type: TYPE_ARR_INPUT.SELECT,
            placeholder: `${PRESS} Tỉnh/Thành phố`,
            options: convertDataProvince,
            rules: [
                { required: true, message: `Tỉnh/Thành phố ${NOT_EMPTY}` },
            ],
            showItem: true,
        },
        {
            id: 'homeDistrict',
            label: 'Quận/Huyện',
            type: TYPE_ARR_INPUT.SELECT,
            placeholder: `${PRESS} Quận/Huyện`,
            options: dataDistrict,
            rules: [
                { required: true, message: `Quận/Huyện ${NOT_EMPTY}` },
            ],
            showItem: true,
        },
        {
            id: 'homeWard',
            label: 'Phường/Xã/Thị trấn',
            type: TYPE_ARR_INPUT.SELECT,
            placeholder: `${PRESS} Phường/Xã/Thị trấn`,
            options: dataWard,
            rules: [
                { required: true, message: `Phường/Xã/Thị trấn ${NOT_EMPTY}` },
            ],
            showItem: true,
        },
        {
            id: 'homeAddress',
            label: 'Số nhà',
            type: TYPE_ARR_INPUT.INPUT,
            placeholder: `${PRESS} Số nhà`,
            rules: [
                { required: true, message: `Số nhà ${NOT_EMPTY}` },
            ],
            showItem: true,
        },
        
        {
            id: 'homeYearBuilt',
            label: 'Năm xây dựng',
            type: TYPE_ARR_INPUT.DATE_PICKER,
            placeholder: `${PRESS} năm xây dựng`,
            rules: [{ required: true, message: `Năm xây dựng ${NOT_EMPTY}` }],
            showItem: true,
        },
    ]
    useEffect(() => {
        if (isFire) {
         
            LazyGetDataProvinceIdQuery({
                name: ECategory.PROVINCE,
            })
        }
    }, [isFire])
    return <>
        {
            ARR_INPUT_HOME.map((itemMap, key) => <Col key={itemMap.id + key} xs={12} xl={8}>
                {
                    itemMap.type === TYPE_ARR_INPUT.INPUT && <Form.Item
                    getValueProps={(i) => ({ value: (i?.trimStart()) })}
                        name={itemMap.id}
                        rules={itemMap.rules || []}
                        label={<span>{itemMap.label}</span>}>
                        <CustomInput
                            placeholder={itemMap.placeholder}
                            id={itemMap.id}
                        />
                    </Form.Item>
                }
                {
                    itemMap.type === TYPE_ARR_INPUT.SELECT && itemMap.type === TYPE_ARR_INPUT.SELECT && <Form.Item
                        name={itemMap.id}
                        rules={itemMap.rules || []}
                        label={<span>{itemMap.label}</span>}>
                        <CustomSelect
                            formInsert={formInsert}
                            onChange={async (e) => {
                                if (itemMap.id === 'homeProvince') {
                                    setDataDistrict([])
                                    setDataWard([])
                                    formInsert.setFieldsValue({
                                        homeDistrict: null,
                                    })
                                    formInsert.setFieldsValue({
                                        homeWard: null,
                                    })
                                    const getDistrictByCode = [...convertDataProvince].filter((itemFilter) => itemFilter.code === e)
                                    if (getDistrictByCode.length > 0) {
                                        const convertDataDistrict = getDistrictByCode?.[0]?.districts ? getDistrictByCode?.[0]?.districts?.map((itemMap: any) => {
                                            return {
                                                ...itemMap,
                                                value: itemMap.code,
                                                label: itemMap.name
                                            }
                                        }) : []
                                        setDataDistrict(convertDataDistrict)
                                    }
                                }
                                if (itemMap.id === 'homeDistrict') {
                                    setDataWard([])
                                    formInsert.setFieldsValue({
                                        homeWard: null,
                                    })
                                    const getWardByCode: any = [...dataDistrict].filter((itemFilter: any) => itemFilter.code === e)
                                    if (getWardByCode.length > 0) {
                                        const convertDataDistrict = getWardByCode?.[0]?.wards ? getWardByCode?.[0]?.wards?.map((itemMap: any) => {
                                            return {
                                                ...itemMap,
                                                value: itemMap.code,
                                                label: itemMap.name
                                            }
                                        }) : []
                                        setDataWard(convertDataDistrict)
                                    }
                                }
                            }}
                            id={itemMap.id}
                            options={(itemMap.options || []) as OptionType[]}
                        />
                    </Form.Item>
                }
                     {
                    itemMap.type === TYPE_ARR_INPUT.DATE_PICKER && <Form.Item
                        name={itemMap.id}
                        rules={itemMap.rules || []}
                        label={<span>{itemMap.label}</span>}>
                        <DatePicker
                            className='w-100'
                            placeholder={itemMap.placeholder}
                            id={itemMap.id}
                        />
                    </Form.Item>
                }
            </Col>)
        }
    </>
};

export default InsuranceFireBenifit;

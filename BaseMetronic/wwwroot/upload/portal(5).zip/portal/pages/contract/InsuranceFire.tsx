import { Button, Col, DatePicker, Form, FormInstance } from 'antd';
import React, { useEffect, useState } from 'react';
import CustomInput from 'src/common/CustomInput';
import CustomSelect, { OptionType } from 'src/common/CustomSelect';
import { validateMaxLength } from 'src/common/Validate';
import { ARR_INSURANCE_SOURCE, EInsuranceFeature, EInsuranceSource } from 'enums/insurance.enum';
import { useLazyGetUserIntentByPartnerIdQuery } from 'store/APIs/contract';
import { UploadOutlined } from '@ant-design/icons';
import UploadFiles from 'src/common/Gallery/UploadFile';
import CustomInputNumber from 'src/common/CustomInputPrice';
import { NOT_EMPTY, PRESS, TYPE_ARR_INPUT } from 'store/APIs/const';
import { ARR_GENDER, CAddress, CDiscountCode, CExpiry, CFeeInsurance, CGender, CIdCard, CStartDate, ECategory } from 'store/APIs/common';
export interface IMotoInsurance {
    formInsert: FormInstance<any>
}


const FireInsurance = ({ formInsert }: IMotoInsurance) => {
    const type = Form.useWatch('feature', formInsert);
    const source = Form.useWatch('source', formInsert);
    const isFire = type === EInsuranceFeature.FIRE_01
    console.log(source);
    const [LazyGetHomePackageIdQuery, { data }] = useLazyGetUserIntentByPartnerIdQuery();
    const [LazyGetDataUseIdQuery, dataUse] = useLazyGetUserIntentByPartnerIdQuery();
    const [LazyGetDataRiskIdQuery, dataRisk] = useLazyGetUserIntentByPartnerIdQuery();
    const [LazyGetDataProvinceIdQuery, dataProvince] = useLazyGetUserIntentByPartnerIdQuery();
    const [LazyGetDataTypeIdQuery, dataType] = useLazyGetUserIntentByPartnerIdQuery();
    const [dataDistrict, setDataDistrict] = useState([])
    const [dataWard, setDataWard] = useState([])
    const convertDataHomePackage = data ? data?.map((itemMap) => {
        return {
            ...itemMap,
            value: itemMap.Value,
            label: itemMap.Text
        }
    }) : []
    const convertDataType = dataType?.data ? dataType?.data?.map((itemMap) => {
        return {
            ...itemMap,
            value: itemMap.Value,
            label: itemMap.Text
        }
    }) : []
    const convertDataUse = dataUse?.data ? dataUse?.data?.map((itemMap) => {
        return {
            ...itemMap,
            value: itemMap.Value,
            label: itemMap.Text
        }
    }) : []
    const convertDataProvince = dataProvince?.data ? dataProvince?.data?.map((itemMap: any) => {
        return {
            ...itemMap,
            value: itemMap.code,
            label: itemMap.name
        }
    }) : []
    const convertDataRisk = dataRisk?.data ? dataRisk?.data?.map((itemMap) => {
        return {
            ...itemMap,
            value: itemMap.Value,
            label: itemMap.Text
        }
    }) : []
    const ARR_INPUT_HOME = [
        {
            id: 'name',
            label: 'Tên người mua',
            type: TYPE_ARR_INPUT.INPUT,
            placeholder: `${PRESS} tên người mua`,
            rules: [
                {
                    required: true,
                    message: `Tên người mua ${NOT_EMPTY}`
                },
                {
                    pattern: validateMaxLength(50).regexPattern,
                    message: validateMaxLength(50).message
                },
            ],
            showItem: true,
        },
        CAddress('address', true),
        CIdCard('idCard', true),
        CGender('gender', true),
        {
            id: 'birthday',
            label: 'Ngày sinh',
            type: TYPE_ARR_INPUT.DATE_PICKER,
            placeholder: `${PRESS} ngày sinh`,
            rules: [{ required: true, message: `Ngày sinh ${NOT_EMPTY}` }],
            showItem: true,
        },
        {
            id: 'source',
            label: 'Nguồn BH',
            type: TYPE_ARR_INPUT.SELECT,
            options: ARR_INSURANCE_SOURCE,
            placeholder: `${PRESS} nguồn BH`,
            rules: [
                { required: true, message: `Nguồn BH ${NOT_EMPTY}` },
                {
                    pattern: validateMaxLength(30).regexPattern,
                    message: validateMaxLength(30).message
                },
            ],
            showItem: true,
        },
        {
            id: 'packageTmp',
            label: 'Gói bảo hiểm',
            type: TYPE_ARR_INPUT.SELECT,
            placeholder: `${PRESS} Gói bảo hiểm`,
            options: convertDataHomePackage,
            rules: [
                { required: true, message: `Gói bảo hiểm ${NOT_EMPTY}` },
            ],
            showItem: true,
        },
        {
            id: 'type',
            label: 'Loại hình kinh doanh',
            type: TYPE_ARR_INPUT.SELECT,
            placeholder: `${PRESS} Loại hình kinh doanh`,
            options: convertDataType,
            rules: [
                { required: true, message: `Loại hình kinh doanh ${NOT_EMPTY}` },
            ],
            showItem: true,
        },
        CExpiry(['1']),
        CFeeInsurance('fee', true),
        CStartDate(),
        CDiscountCode('discountCode', true),
    ].filter((itemFilter) => itemFilter.showItem)
    const onDataChange = () => {
        const formData = formInsert.getFieldsValue();
        if (formData.contractFile) {
            formInsert.setFieldsValue({
                contractFile: formData?.contractFile?.file?.response,
            })
        }
    };
    useEffect(() => {
        LazyGetHomePackageIdQuery({
            name: ECategory.FIRE_PACKAGES,
            source: source||EInsuranceSource.PVI
        })
        LazyGetDataUseIdQuery({
            name: ECategory.MUCDICH_SD,
            source: source||EInsuranceSource.PVI
        })
        LazyGetDataRiskIdQuery({
            name: ECategory.MAHIEU_RUIRO,
            source: source||EInsuranceSource.PVI
        })
        LazyGetDataProvinceIdQuery({
            name: ECategory.PROVINCE,
        })
        LazyGetDataTypeIdQuery({
            name: ECategory.BIZ_TYPES,
            source: source||EInsuranceSource.PVI
        })
    }, [source])
    return <>
        {
            ARR_INPUT_HOME.map((itemMap, key) => <Col key={itemMap.id + key} xs={12} xl={8}>
                {
                    itemMap.type === TYPE_ARR_INPUT.INPUT && <Form.Item
                        getValueProps={(i) => ({ value: (i?.trimStart()) })}
                        name={itemMap.id}
                        rules={itemMap.rules || []}
                        label={<span>{itemMap.label}</span>}>
                        <CustomInput

                            placeholder={itemMap.placeholder}
                            id={itemMap.id}
                        />
                    </Form.Item>
                }
                {
                    itemMap.type === TYPE_ARR_INPUT.INPUT_PRICE && <CustomInputNumber
                        itemMap={itemMap}
                    />
                }

                {
                    itemMap.type === TYPE_ARR_INPUT.DATE_PICKER && <Form.Item
                        name={itemMap.id}
                        rules={itemMap.rules || []}
                        label={<span>{itemMap.label}</span>}>
                        <DatePicker
                            className='w-100'
                            placeholder={itemMap.placeholder}
                            id={itemMap.id}
                        />
                    </Form.Item>
                }
                {
                    itemMap.type === TYPE_ARR_INPUT.SELECT && <Form.Item
                        name={itemMap.id}
                        rules={itemMap.rules || []}
                        label={<span>{itemMap.label}</span>}>
                        <CustomSelect
                            formInsert={formInsert}
                            onChange={async (e) => {
                                if (itemMap.id === 'homeProvince') {
                                    setDataDistrict([])
                                    setDataWard([])
                                    formInsert.setFieldsValue({
                                        homeDistrict: null,
                                    })
                                    formInsert.setFieldsValue({
                                        homeWard: null,
                                    })
                                    const getDistrictByCode = [...convertDataProvince].filter((itemFilter) => itemFilter.code === e)
                                    if (getDistrictByCode.length > 0) {
                                        const convertDataDistrict = getDistrictByCode?.[0]?.districts ? getDistrictByCode?.[0]?.districts?.map((itemMap: any) => {
                                            return {
                                                ...itemMap,
                                                value: itemMap.code,
                                                label: itemMap.name
                                            }
                                        }) : []
                                        setDataDistrict(convertDataDistrict)
                                    }
                                }
                                if (itemMap.id === 'homeDistrict') {
                                    setDataWard([])
                                    formInsert.setFieldsValue({
                                        homeWard: null,
                                    })
                                    const getWardByCode: any = [...dataDistrict].filter((itemFilter: any) => itemFilter.code === e)
                                    if (getWardByCode.length > 0) {
                                        const convertDataDistrict = getWardByCode?.[0]?.wards ? getWardByCode?.[0]?.wards?.map((itemMap: any) => {
                                            return {
                                                ...itemMap,
                                                value: itemMap.code,
                                                label: itemMap.name
                                            }
                                        }) : []
                                        setDataWard(convertDataDistrict)
                                    }
                                }
                            }}
                            id={itemMap.id}
                            options={(itemMap.options || []) as OptionType[]}
                        />
                    </Form.Item>
                }
            </Col>)
        }
        <Col xs={12} xl={8}>
            <Form.Item
                required
                label="Upload hợp đồng "
                name="contractFile"
                rules={[
                    { required: true, message: "Không được để trống" },
                ]}
            >
                <UploadFiles
                    onChange={onDataChange}
                    multiple={false}
                    maxCount={1}
                    accept={"Excel file |.xls, .xlsx"}
                >
                    <div>
                        <Button icon={<UploadOutlined />}>Chọn tệp</Button>
                    </div>
                </UploadFiles>
            </Form.Item>
        </Col>
    </>
};

export default FireInsurance;
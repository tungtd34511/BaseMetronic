import { Button, Col, DatePicker, Form, FormInstance } from 'antd';
import React, { useEffect } from 'react';
import CustomInput from 'src/common/CustomInput';
import CustomSelect, { OptionType } from 'src/common/CustomSelect';
import { validateIdCard, validateMaxLength } from 'src/common/Validate';
import { ARR_INSURANCE_SOURCE, ARR_INSURANCE_SOURCE_HOME, EInsuranceFeature, EInsuranceSource } from 'enums/insurance.enum';
import { useLazyGetUserIntentByPartnerIdQuery } from 'store/APIs/contract';
import { UploadOutlined } from '@ant-design/icons';
import UploadFiles from 'src/common/Gallery/UploadFile';
import CustomInputNumber from 'src/common/CustomInputPrice';
import { NOT_EMPTY, PRESS, TYPE_ARR_INPUT } from 'store/APIs/const';
import { CAddress, CDiscountCode, CExpiry, CFeeInsurance, CIdCard, CStartDate, ECategory } from 'store/APIs/common';
export interface IMotoInsurance {
    formInsert: FormInstance<any>
}
const HomeInsurance = ({ formInsert }: IMotoInsurance) => {
    const type = Form.useWatch('feature', formInsert);
    const isHome = type === EInsuranceFeature.HOME_01
    const [LazyGetHomePackageIdQuery, { data }] = useLazyGetUserIntentByPartnerIdQuery();
    const convertDataHomePackage = data ? data?.map((itemMap) => {
        return {
            ...itemMap,
            value: itemMap.Value,
            label: itemMap.Text
        }
    }) : []
    const ARR_INPUT_HOME = [
        {
            id: 'homeOwnerName',
            label: 'Tên chủ nhà',
            type: TYPE_ARR_INPUT.INPUT,
            placeholder: `${PRESS} Tên chủ nhà`,
            rules: [
                {
                    required: true,
                    message: `Tên chủ nhà ${NOT_EMPTY}`
                },
                {
                    pattern: validateMaxLength(50).regexPattern,
                    message: validateMaxLength(50).message
                },
            ],
            showItem: true,
        },
        CIdCard('idCard', true),
        CAddress('address', true),
        {
            id: 'source',
            label: 'Nguồn BH',
            type: TYPE_ARR_INPUT.SELECT,
            options: ARR_INSURANCE_SOURCE_HOME,
            placeholder: `${PRESS} nguồn BH`,
            rules: [
                { required: true, message: `Nguồn BH ${NOT_EMPTY}` },
            ],
            showItem: true,
        },
        {
            id: 'packageTmp',
            label: 'Gói bảo hiểm',
            type: TYPE_ARR_INPUT.SELECT,
            placeholder: `${PRESS} Gói bảo hiểm`,
            options: convertDataHomePackage,
            rules: [
                { required: true, message: `Gói bảo hiểm ${NOT_EMPTY}` },
            ],
            showItem: true,
        },
        CExpiry(["6", '12'], 'tháng'),
        CFeeInsurance('fee', true),
        CStartDate(),
        CDiscountCode('discountCode', true),
    ].filter((itemFilter) => itemFilter.showItem)
    const onDataChange = () => {
        const formData = formInsert.getFieldsValue();
        if (formData.contractFile) {
            formInsert.setFieldsValue({
                contractFile: formData?.contractFile?.file?.response,
            })
        }
    };
    useEffect(() => {
        if (isHome) {
            LazyGetHomePackageIdQuery({
                name: ECategory.HOME_PACKAGES,
                source: EInsuranceSource.PVI
            })
        }
    }, [isHome])
    return <>
        {
            ARR_INPUT_HOME.map((itemMap, key) => <Col key={itemMap.id + key} xs={12} xl={8}>
                {
                    itemMap.type === TYPE_ARR_INPUT.INPUT && <Form.Item
                        getValueProps={(i) => ({ value: (i?.trimStart()) })}
                        name={itemMap.id}
                        rules={itemMap.rules || []}
                        label={<span>{itemMap.label}</span>}>
                        <CustomInput

                            placeholder={itemMap.placeholder}
                            id={itemMap.id}
                        />
                    </Form.Item>
                }
                {
                    itemMap.type === TYPE_ARR_INPUT.INPUT_PRICE && <CustomInputNumber
                        itemMap={itemMap}
                    />
                }
                {
                    itemMap.type === TYPE_ARR_INPUT.DATE_PICKER && <Form.Item
                        name={itemMap.id}
                        rules={itemMap.rules || []}
                        label={<span>{itemMap.label}</span>}>
                        <DatePicker
                            className='w-100'
                            placeholder={itemMap.placeholder}
                            id={itemMap.id}
                        />
                    </Form.Item>
                }
                {
                    itemMap.type === TYPE_ARR_INPUT.SELECT && <Form.Item
                        name={itemMap.id}
                        rules={itemMap.rules || []}
                        label={<span>{itemMap.label}</span>}>
                        <CustomSelect
                            formInsert={formInsert}
                            id={itemMap.id}
                            options={(itemMap.options || []) as OptionType[]}
                        />
                    </Form.Item>
                }
            </Col>)
        }
        <Col xs={12} xl={8}>
            <Form.Item
                required
                label="Upload hợp đồng "
                name="contractFile"
                rules={[
                    { required: true, message: "Không được để trống" },
                ]}
            >
                <UploadFiles
                    onChange={onDataChange}
                    multiple={false}
                    maxCount={1}
                    accept={"Excel file |.xls, .xlsx"}
                >
                    <div>
                        <Button icon={<UploadOutlined />}>Chọn tệp</Button>
                    </div>
                </UploadFiles>
            </Form.Item>
        </Col>
    </>
};

export default HomeInsurance;
import { Col, Form, FormInstance } from 'antd';
import React from 'react';
import CustomInput from 'src/common/CustomInput';
import CustomSelect from 'src/common/CustomSelect';
import { validateCommistion, validateMaxLength } from 'src/common/Validate';
import { NOT_EMPTY, PRESS, TYPE_ARR_INPUT } from 'store/APIs/const';
export interface IRole {
    formInsert: FormInstance<any>
}
const Role = ({ formInsert }: IRole) => {
    const ruleCommision = [
        {
            required: true,
            message: `Tên vai trò ${NOT_EMPTY}`
        },
    ]
    const ARR_INPUT = [
        {
            id: 'commission',
            label: 'Tên vai trò',
            type: TYPE_ARR_INPUT.INPUT,
            placeholder: `${PRESS} tên vai trò`,
            rules: ruleCommision
        },
    ]
    const ARR_SELECT = [
        {
            id: 'insuranceType',
            label: 'Phân quyền vai trò',
            options: [],
            rules: [{ required: true, message: 'Phân quyền không được để trống' }],
        },
    ]
    return <>
        {
            ARR_INPUT.map((itemMap, key) => <Col key={itemMap.id + key} xs={12} xl={8}>
                {
                    <Form.Item
                        name={itemMap.id}
                        rules={itemMap.rules || []}
                        label={<span>{itemMap.label}</span>}>
                        <CustomInput
                            placeholder={itemMap.placeholder}
                            id={itemMap.id}
                        />
                    </Form.Item>
                }
            </Col>)
        }
        {
            ARR_SELECT.map((itemMap, key) => {
                console.log(itemMap.rules)
                return <Col key={itemMap.id + key} xs={12} xl={8}>
                    <Form.Item
                        name={itemMap.id}
                        rules={itemMap.rules}
                        label={itemMap.label}
                    >
                        <CustomSelect
                            formInsert={formInsert}
                            id={itemMap.id}
                            onChange={(e) => {
                            }}
                            options={itemMap.options}
                        />
                    </Form.Item>
                </Col>
            })
        }
    </>
};

export default Role;
import { Spin } from "antd";
import type { NextPage } from "next";
import { FlexBox } from "src/common/FlexBox";

const HomePage: NextPage = () => {
  return (
    <FlexBox
      style={{
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      <Spin size="large" />
    </FlexBox>
  );
};

export default HomePage;

HomePage.defaultProps = {
  layout: (props: Record<string, unknown>) => (
    <FlexBox
      style={{
        width: "100vw",
        height: "100vh",
        overflow: "auto",
      }}
      {...props}
    />
  ),
};

import { Col, Form, FormInstance } from 'antd';
import React from 'react';
import CustomInput from 'src/common/CustomInput';
import CustomSelect from 'src/common/CustomSelect';
import { validateCommistion, validateMaxLength } from 'src/common/Validate';
import { NOT_EMPTY, PRESS, TYPE_ARR_INPUT } from 'store/APIs/const';
export interface IRole {
    formInsert: FormInstance<any>
}
const Role = ({ formInsert }: IRole) => {
    const ruleCommision = [
        {
            required: true,
            message: `Tên đối tác ${NOT_EMPTY}`
        },
    ]
    const ARR_INPUT = [
        {
            id: 'commission',
            label: 'Tên đối tác',
            type: TYPE_ARR_INPUT.INPUT,
            placeholder: `${PRESS} tên đối tác`,
            rules: ruleCommision
        },
        {
            id: 'commission',
            label: 'Email',
            type: TYPE_ARR_INPUT.INPUT,
            placeholder: `${PRESS} Email`,
            rules: [
                {
                    required: true,
                    message: `Email ${NOT_EMPTY}`
                },
            ]
        },
        {
            id: 'commission',
            label: 'Số điện thoại',
            type: TYPE_ARR_INPUT.INPUT,
            placeholder: `${PRESS} Số điện thoại`,
            rules: [
                {
                    required: true,
                    message: `Số điện thoại ${NOT_EMPTY}`
                },
            ]
        },
    ]

    const ARR_INPUT1 = [
        {
            id: 'commission',
            label: 'Link tổ chức',
            type: TYPE_ARR_INPUT.INPUT,
            placeholder: `${PRESS} Link tổ chức`,
            rules: ruleCommision
        },
    ]

    return <>
        <Col xl={24} xxl={24} xs={24}>
            <h3>Thông tin đối tác</h3>
        </Col>
        {
            ARR_INPUT.map((itemMap, key) => <Col key={itemMap.id + key} xs={12} xl={8}>
                {
                    <Form.Item
                        name={itemMap.id}
                        rules={itemMap.rules || []}
                        label={<span>{itemMap.label}</span>}>
                        <CustomInput
                            placeholder={itemMap.placeholder}
                            id={itemMap.id}
                        />
                    </Form.Item>
                }
            </Col>)
        }
        <Col xl={24} xxl={24} xs={24}>
            <h3>Mời thành viên vào tổ chức</h3>
        </Col>
        {
            ARR_INPUT1.map((itemMap, key) => <Col key={itemMap.id + key} xs={12} xl={8}>
                {
                    <Form.Item
                        name={itemMap.id}
                        rules={itemMap.rules || []}
                        label={<span>{itemMap.label}</span>}>
                        <CustomInput
                            placeholder={itemMap.placeholder}
                            id={itemMap.id}
                        />
                    </Form.Item>
                }
            </Col>)
        }
    </>
};

export default Role;
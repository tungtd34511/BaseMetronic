import { Button, Collapse, Empty, Spin, Typography } from "antd";
import type { NextPage } from "next";
import { FlexBox } from "src/common/FlexBox";
import NextLink from "src/common/NextLink";
import { useGetAppConfigQuery } from "store/APIs/app";

const { Panel } = Collapse;
const PublicDocsPage: NextPage = () => {
  const { data: config, isLoading } = useGetAppConfigQuery();

  if (isLoading || !config) return <Spin />;
  return (
    <div
      style={{
        background: "white",

        borderRadius: "40px",
      }}
    >
      {config.instructionManualGroups.map(({ title, items }) => {
        return (
          <div
            style={{
              padding: "5% 0",
              paddingLeft: 12,
              boxShadow: "0px -10px 16px rgba(0,0,0,0.05)",
              borderRadius: "40px",
            }}
            key={title}
          >
            <Typography.Title style={{ textAlign: "center" }}>
              {title}
            </Typography.Title>
            <Collapse defaultActiveKey={[]} ghost>
              {items.map((item) => (
                <Panel header={item.title} key={item.value}>
                  {(config.instructionManuals.filter(
                    (i) => i.group === item.value
                  )?.length &&
                    config.instructionManuals
                      .filter((i) => i.group === item.value)
                      .map((item) => (
                        <FlexBox
                          style={{
                            paddingLeft: 24,
                            paddingTop: 16,
                            borderBottom: "1px solid rgba(0,0,0,0.05)",
                            justifyContent: "space-between",
                            alignItems: "center",
                          }}
                          key={item.url + item.group}
                        >
                          <div>
                            <Typography.Title level={5}>
                              {item.title}
                            </Typography.Title>
                            <Typography.Paragraph style={{ opacity: 0.7 }}>
                              {item.keywords.join(" - ")}
                            </Typography.Paragraph>
                          </div>
                          <NextLink href={item.url} target="_blank">
                            <Button type="primary">Xem tài liệu</Button>
                          </NextLink>
                        </FlexBox>
                      ))) || <Empty />}
                </Panel>
              ))}
            </Collapse>
          </div>
        );
      })}
    </div>
  );
};

export default PublicDocsPage;

import type { NextPage } from "next";
import dynamic from "next/dynamic";
import CustomDateRangePicker from "src/common/CustomDateRangePicker";
import { FlexBox } from "src/common/FlexBox";
import CustomBreadCrumb from "src/layout/CustomBreadCrumb";
import moment from "moment";
import { useState } from "react";
import {
  useGetReferrerAccessLogReportQuery,
  useGetMyCommissionLogReportQuery,
} from "store/APIs/referrer";
import Metric from "src/views/analytic/Metric";
import useFormatter from "src/hooks/useFormatter";
import {
  AccountBookFilled,
  AlignCenterOutlined,
  HighlightFilled,
  ProfileFilled,
} from "@ant-design/icons";
import { Col, Row } from "antd";
import useRole from "src/hooks/useRole";
import { BLACK_LIST_USER } from "store/APIs/common";
const AccessLogReport = dynamic(
  () => import("src/views/analytic/AccessLogReport"),
  {
    ssr: false,
  }
);

const CommissionLogReport = dynamic(
  () => import("src/views/analytic/CommissionLogReport"),
  {
    ssr: false,
  }
);

const ReportPage: NextPage = () => {
  const [dateRange, setdateRange] = useState({
    from: moment().subtract(30, "days").valueOf(),
    to: moment().valueOf(),
  });
  const { formatter, numberFormatter } = useFormatter();

  const { data: accessLogReportData, isLoading: isLoadingAccessLogReport } =
    useGetReferrerAccessLogReportQuery({
      ...dateRange,
      page: 1,
      limit: 10000,
    });

  const {
    data: commissionLogReportData,
    isLoading: isLoadingCommissionLogReport,
  } = useGetMyCommissionLogReportQuery({
    ...dateRange,
    page: 1,
    limit: 1000,
  });
  const { userData } = useRole();
  const hiddenItem = BLACK_LIST_USER.includes(userData?.id as string)
  return (
    <>
      <CustomBreadCrumb
        items={[{ title: "Báo cáo tổng quan", href: "/report" }]}
      ></CustomBreadCrumb>
      <FlexBox style={{ justifyContent: "flex-end", paddingRight: "3%" }}>
        <CustomDateRangePicker
          startDate={dateRange.from}
          endDate={dateRange.to}
          onChange={(from, to) => setdateRange({ from, to })}
        />
      </FlexBox>

      <Row
        style={{
          marginTop: 30,
        }}
      >
        <Col span={24} xl={12}>
          <Metric
            items={[
              {
                title: "Lượt truy cập",
                value: numberFormatter.format(
                  accessLogReportData?.accumulate?.accessCount || 0
                ),
                icon: <AlignCenterOutlined />,
              },

              {
                title: "Lượt mua thành công",
                value: numberFormatter.format(
                  accessLogReportData?.accumulate?.successCount || 0
                ),
                icon: <HighlightFilled />,
              },
              {
                title: "Doanh thu",
                value: formatter.format(
                  commissionLogReportData?.accumulate?.revenueCalcCommission ||
                  0
                ),
                icon: <ProfileFilled />,
              },

              {
                title: "Doanh thu đại lý cấp dưới",
                value: formatter.format(
                  commissionLogReportData?.accumulate?.revenueCalcFromAgent || 0
                ),
                icon: <ProfileFilled />,
                hiddenItem
              },

              {
                title: "Hoa hồng từ đại lý cấp dưới",
                value: formatter.format(
                  commissionLogReportData?.accumulate?.commissionFromAgent || 0
                ),
                icon: <AccountBookFilled />,
                hiddenItem
              },

              {
                title: "Hoa hồng tự giới thiệu",
                value: formatter.format(
                  commissionLogReportData?.accumulate?.originalAmount || 0
                ),
                icon: <AccountBookFilled />,
                hiddenItem
              },
            ].filter((item) => !item.hiddenItem)}
          />
          <AccessLogReport
            data={accessLogReportData}
            isLoading={isLoadingAccessLogReport}
          />
        </Col>
        <Col span={24} xl={12} style={{ paddingLeft: 20 }}>
          <CommissionLogReport
            data={commissionLogReportData}
            isLoading={isLoadingCommissionLogReport}
          />
        </Col>
      </Row>
    </>
  );
};

export default ReportPage;

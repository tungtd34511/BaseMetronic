import { Button, Form, Input, message, Spin, Tabs, Typography } from "antd";
import { EQrCodeType, EWsEvent } from "enums";
import { QRCodeCanvas } from "qrcode.react";
import React, { useEffect } from "react";
import { FlexBox } from "src/common/FlexBox";
import { ACCESS_TOKEN_KEY } from "src/constants";
import useSocket from "src/hooks/useSocket";
import { useLoginMutation } from "store/APIs/user";

function LoginPage() {
  const [loginMutation, { isLoading, isSuccess, data, isError }] =
    useLoginMutation();

  const { clientId, cọnnected } = useSocket({
    namespace: "/portal",
    handleMessage: (message) => {
      if (message.event === EWsEvent.APP_LOGIN_PORTAL) {
        window.localStorage.setItem(
          ACCESS_TOKEN_KEY,
          message.data.jwtAccessToken
        );
        window.open("/analytic/report", "_self");
      }
    },
  });

  const [form] = Form.useForm();
  const onFinish = () => {
    loginMutation(form.getFieldsValue());
  };

  useEffect(() => {
    if (isSuccess && data) {
      window.localStorage.setItem(ACCESS_TOKEN_KEY, data.jwtAccessToken);
      message.success("Đăng nhập thành công");
      window.open("/analytic/report", "_self");
    }
    if (isError) {
      message.error("Thông tin đăng nhập không đúng");
    }
  }, [isSuccess, data, isError]);

  const loginDeeplink = `${process.env.ZALO_DEEPLINK}/login/portal?state=${btoa(
    JSON.stringify({
      data: {
        body: { clientId },
        pathname: "/my/user/login-portal",
      },
      type: EQrCodeType.LOGIN_PORTAL,
      disableCallback: true,
    })
  )}&${process.env.ZALO_DEEPLINK_VERSION}`;

  if (!cọnnected) {
    return (
      <FlexBox
        style={{
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <Spin size="large" />
      </FlexBox>
    );
  }

  return (
    <FlexBox
      className="login-page"
      style={{
        alignItems: "center",
        justifyContent: "center",
        flexDirection: "column",
        width: "100%",
        height: "100%",
        maxWidth: 1000,
        paddingTop: 56,
      }}
    >
      <Tabs centered style={{ height: "100%", width: 400 }}>
        <Tabs.TabPane tab="Đăng nhập bằng ứng dụng" key="2">
          <FlexBox
            style={{
              alignItems: "center",
              flexDirection: "column",
              marginTop: 100,
            }}
          >
            <QRCodeCanvas
              size={1000}
              style={{ height: "auto", maxWidth: 300, width: "100%" }}
              value={loginDeeplink}
            />
            <Typography style={{ paddingTop: 20 }}>
              Quét QR code để đăng nhập
            </Typography>
          </FlexBox>
        </Tabs.TabPane>
        <Tabs.TabPane tab="Đăng nhập bằng tài khoản" key="1">
          <FlexBox
            style={{
              alignItems: "center",
              flexDirection: "column",
              marginTop: 100,
            }}
          >
            <Form
              form={form}
              name="basic"
              labelCol={{ span: 24 }}
              wrapperCol={{ span: 24 }}
              style={{ maxWidth: 600, width: "100%" }}
              initialValues={{ remember: true }}
              onFinish={onFinish}
              // onFinishFailed={onFinishFailed}
              autoComplete="off"
            >
              <Form.Item
                label="Tên đăng nhập (email)"
                name="email"
                rules={[{ required: true, message: "Không được để trống" }]}
              >
                <Input />
              </Form.Item>

              <Form.Item
                label="Mật khẩu"
                name="password"
                rules={[{ required: true, message: "Không được để trống" }]}
              >
                <Input.Password />
              </Form.Item>

              <Form.Item wrapperCol={{ offset: 8, span: 16 }}>
                <Button loading={isLoading} type="primary" htmlType="submit">
                  Đăng nhập
                </Button>
              </Form.Item>
            </Form>
          </FlexBox>
        </Tabs.TabPane>
      </Tabs>
    </FlexBox>
  );
}

export default LoginPage;

LoginPage.defaultProps = {
  layout: (props: Record<string, unknown>) => (
    <FlexBox
      style={{
        width: "100vw",
        height: "100vh",
        overflow: "auto",
        justifyContent: "center",
      }}
      {...props}
    />
  ),
  disableAuth: true,
};

import { Tabs } from "antd";
import type { NextPage } from "next";
import CustomBreadCrumb from "src/layout/CustomBreadCrumb";
import VoucherListV2 from "src/views/admin/VoucherList.tsxV2";

const AdminVoucherPage: NextPage = () => {
    return (
        <>
            <CustomBreadCrumb
                items={[
                    {
                        title: "Voucher",
                        href: "/admin/voucherv2",
                    },
                ]}
            ></CustomBreadCrumb>
            <VoucherListV2 />
        </>
    );
};

export default AdminVoucherPage;

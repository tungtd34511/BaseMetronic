import { Tabs } from "antd";
import type { NextPage } from "next";
import CustomBreadCrumb from "src/layout/CustomBreadCrumb";
import VoucherList from "src/views/admin/VoucherList";
import VoucherRequest from "src/views/admin/VoucherRequest";
import styled from "styled-components";

const AdminVoucherPage: NextPage = () => {
  return (
    <>
      <CustomBreadCrumb
        items={[
          {
            title: "Voucher",
            href: "/admin/voucher",
          },
        ]}
      ></CustomBreadCrumb>

      <StyledTabs>
        <Tabs.TabPane tab="Voucher đã duyệt" key="1">
          <VoucherList />
        </Tabs.TabPane>
        <Tabs.TabPane tab="Voucher chờ duyệt" key="2">
          <VoucherRequest />
        </Tabs.TabPane>
      </StyledTabs>
    </>
  );
};

export default AdminVoucherPage;

const StyledTabs = styled(Tabs)`
  width: 100%;

  .ant-tabs-nav::before {
    border: unset;
  }
  .ant-tabs-tab.ant-tabs-tab-active .ant-tabs-tab-btn {
    color: black;
    font-weight: 300;
  }
`;

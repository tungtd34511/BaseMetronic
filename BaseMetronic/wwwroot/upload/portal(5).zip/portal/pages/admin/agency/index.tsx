import { Tabs } from "antd";
import type { NextPage } from "next";
import CustomBreadCrumb from "src/layout/CustomBreadCrumb";
import styled from "styled-components";
import ListAgency from "../../../src/views/admin/ListAgency";
import AgencyReferralList from "../../../src/views/admin/AgencyReferralList";
import {useState} from "react";
import moment from "moment/moment";
import CustomDateRangePicker from "../../../src/common/CustomDateRangePicker";

const AdminAgencyPage: NextPage = () => {
  const [dateRange, setdateRange] = useState({
    from: moment().subtract(30, "days").valueOf(),
    to: moment().valueOf(),
  });
  return (
    <>
      <CustomBreadCrumb
        items={[{ title: "Quản lý đại lý", href: "/agency" }]}
      ></CustomBreadCrumb>
      <StyledTabs>
        <Tabs.TabPane tab="Danh sách đại lý" key="1">
          <ListAgency />
        </Tabs.TabPane>
        <Tabs.TabPane tab="Lịch sử giới thiệu" key="2">
          <CustomDateRangePicker
              startDate={dateRange.from}
              endDate={dateRange.to}
              onChange={(from, to) => setdateRange({ from, to })}
          />
          <AgencyReferralList dateRange={dateRange}/>
        </Tabs.TabPane>
      </StyledTabs>
    </>
  );
};

export default AdminAgencyPage;

const StyledTabs = styled(Tabs)`
  width: 100%;

  .ant-tabs-nav::before {
    border: unset;
  }
  .ant-tabs-tab.ant-tabs-tab-active .ant-tabs-tab-btn {
    color: black;
    font-weight: 300;
  }
`;

import type { NextPage } from "next";
import CustomBreadCrumb from "src/layout/CustomBreadCrumb";
import ReferrerSetting from "src/views/admin/ReferrerSetting";

const AdminCommissionSettingPage: NextPage = () => {
  return (
    <>
      <CustomBreadCrumb
        items={[
          {
            title: "Cài đặt hoa hồng",
            href: "/commission",
          },
        ]}
      ></CustomBreadCrumb>
      <ReferrerSetting />
    </>
  );
};

export default AdminCommissionSettingPage;

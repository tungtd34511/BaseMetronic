import { DownloadOutlined, UploadOutlined } from "@ant-design/icons";
import { Button, Checkbox, Col, DatePicker, Form, Input, Radio, Row, message } from "antd";
import { EInsuranceFeature } from "enums/insurance.enum";
import moment from "moment";
import type { NextPage } from "next";
import { useEffect, useState } from "react";
import UploadFiles from "src/common/Gallery/UploadFile";
import CustomBreadCrumb from "src/layout/CustomBreadCrumb";
import { RoutePath } from "src/layout/Sider";
import { useOfflineImportInsuranceMutation } from "store/APIs/insurance";
import styled from "styled-components";

const AdminImportContractPage: NextPage = () => {
  const [templateLink, setTemplateLink] = useState('https://df5tnwfq42mjn.cloudfront.net/upload/files/Motor.xlsx');
  const [form] = Form.useForm();
  let data = {
    ExcelFile: '',
    GcnFiles: [],
    insuranceType: EInsuranceFeature.MOTOR_01,
    companyName: '',
    isCalcCommission: false,
    startDate: moment().toISOString(),
    overwriteReferrer: false,
    overwriteReferrerId: '',
  }
  const onDataChange = () => {
    const formData = form.getFieldsValue();
    if (formData.ExcelFile) {
      data.ExcelFile = formData.ExcelFile.file?.response
    }
    if (formData.GcnFiles) {
      formData.GcnFiles.fileList?.map((c: any) => {
        if (c && c.response && c.response !== '' && data.GcnFiles.filter(x => x == c.response)?.length <= 0) {
          // @ts-ignore
          return data.GcnFiles.push(c.response);
        }
      });
    }
    if (formData.insuranceType) {
      data.insuranceType = formData.insuranceType;
      if (data.insuranceType == EInsuranceFeature.MOTOR_01) {
        setTemplateLink('https://df5tnwfq42mjn.cloudfront.net/docs/Motor.xlsx');
      } else if (data.insuranceType == EInsuranceFeature.AUTO_01) {
        setTemplateLink('https://df5tnwfq42mjn.cloudfront.net/docs/Auto.xlsx');
      } else if (data.insuranceType == EInsuranceFeature.HEALTH_01) {
        setTemplateLink('https://df5tnwfq42mjn.cloudfront.net/docs/Health_01.xlsx');
      } else if (data.insuranceType == EInsuranceFeature.FIRE_01) {
        setTemplateLink('https://df5tnwfq42mjn.cloudfront.net/docs/FIRE_01.xlsx');
      } else if (data.insuranceType == EInsuranceFeature.HOME_01) {
        setTemplateLink('https://df5tnwfq42mjn.cloudfront.net/docs/HOME_01.xlsx');
      } else if (data.insuranceType == EInsuranceFeature.OTHER_01) {
        setTemplateLink('https://df5tnwfq42mjn.cloudfront.net/docs/Other_01.xlsx');
      }
      else {
        setTemplateLink('#');
      }
    }
    if (formData.companyName) {
      data.companyName = formData.companyName;
    }
    if (formData.isCalcCommission) {
      data.isCalcCommission = formData.isCalcCommission;
    }
    if (formData.startDate) {
      data.startDate = formData.startDate;
    }
    if (formData.overwriteReferrer) {
      data.overwriteReferrer = formData.overwriteReferrer;
    }
    if (formData.overwriteReferrerId) {
      data.overwriteReferrerId = formData.overwriteReferrerId;
    }
    // console.log(formData)
    console.log(JSON.stringify(data));
  };

  const [
    offlineImportInsuranceMutation,
    {
      isLoading: isSubmitLoading,
      isSuccess: isSubmitSuccess,
      isError: isSubmitError,
    },
  ] = useOfflineImportInsuranceMutation();

  useEffect(() => {
    if (isSubmitSuccess) {
      message.success("Gửi thông tin thành công");
      form.resetFields();
    }
  }, [isSubmitSuccess]);

  useEffect(() => {
    if (isSubmitError) {
      message.error("Kiểm tra lại thông tin");
    }
  }, [isSubmitError]);

  return (
    <>
      <CustomBreadCrumb
        items={[
          {
            title: "Nhập hợp đồng offline",
            href: "/admin/import-contract",
          },
        ]}
      ></CustomBreadCrumb>
      <Form
        form={form}
        name="basic"
        labelCol={{ span: 24 }}
        wrapperCol={{ span: 24 }}
        style={{ width: "100%" }}
        initialValues={{ remember: true }}
        className="withdraw-form-container"
      >
        <Row gutter={24} style={{ padding: 12, flexDirection: "column", }}>
          <Col span={24}>
            <Form.Item
              required
              label="Loại BH: "
              name="insuranceType"
              rules={[
                { required: true, message: "Không được để trống" },
              ]}
            >
              <Radio.Group onChange={onDataChange} defaultValue={EInsuranceFeature.MOTOR_01}>
                <Radio value={EInsuranceFeature.MOTOR_01} defaultChecked>Xe máy</Radio>
                <Radio value={EInsuranceFeature.AUTO_01}>Ô tô</Radio>
                <Radio value={EInsuranceFeature.HEALTH_01}>Sức khỏe</Radio>
                <Radio value={EInsuranceFeature.HOME_01}>Nhà ở</Radio>
                <Radio value={EInsuranceFeature.FIRE_01}>Cháy nổ</Radio>
                <Radio value={EInsuranceFeature.OTHER_01}>Sk Bắc Giang</Radio>
              </Radio.Group>
            </Form.Item>
          </Col>
          <Col span={24} md={12}>
            <DownloadOutlined />
            <a style={{ marginLeft: 10 }} href={templateLink} >Tải xuống mẫu nhập hợp đồng</a>
          </Col>
        </Row>
        <Row gutter={24} style={{ padding: 12, flexDirection: "column", }}>
          <Col span={24} md={12}>
            <Form.Item
              required
              label="Tải lên danh sách đăng ký: "
              name="ExcelFile"
              rules={[
                { required: true, message: "Không được để trống" },
              ]}
            >
              <UploadFiles
                onChange={onDataChange}
                multiple={false}
                maxCount={1}
                accept={"Excel file |.xls, .xlsx"}
              >
                <div>
                  <Button icon={<UploadOutlined />}>Chọn tệp</Button>
                </div>
              </UploadFiles>
            </Form.Item>
          </Col>
          <Col span={24} md={12}>
            <Form.Item
              required
              label="Tải lên giấy chứng nhận: "
              name="GcnFiles"
              rules={[
                { required: true, message: "Không được để trống" },
              ]}
            >
              <UploadFiles
                onChange={onDataChange}
                multiple={true}
                maxCount={100}
                accept={"File |.pdf"}
              >
                <div>
                  <Button icon={<UploadOutlined />}>Chọn tệp</Button>
                </div>
              </UploadFiles>
            </Form.Item>
          </Col>
        </Row>
        <Row gutter={24} style={{ padding: 12, flexDirection: "column", }}>
          <Col span={24} md={12}>
            <Form.Item
              required
              label="Tên đơn vị, công ty sở hữu: "
              name="companyName"
            >
              <StyledInput
                placeholder="Tên"
                onChange={onDataChange}
              />
            </Form.Item>            
          </Col>  
          <Col span={24} md={12}>
          <Form.Item
              style={{
                width: "100%",
              }}
              label="Ngày giao dịch"
              name="startDate"
              rules={[{ required: true, message: "Không được để trống" }]}
            >
              <DatePicker
                defaultValue={moment()}
                style={{ width: "100%" }}
                onChange={onDataChange}
                disabledDate={(date) => {
                  return date.valueOf() > Date.now();
                }}
              />
          </Form.Item>        
          </Col>      
        </Row>       
        <Row gutter={24} style={{ padding: 12, flexDirection: "row", }}>
          <Col span={24} md={12}>
            <Form.Item
              required
              label="Ghi đè người giới thiệu "
              name="overwriteReferrer"
              valuePropName="checked"
            >
              <Checkbox onChange={onDataChange}>
              Ghi đè người giới thiệu
              </Checkbox>
            </Form.Item>
          </Col>
          <Col span={24} md={12}>
            <Form.Item
              required
              label="Mã người giới thiệu ghi đè: "
              name="overwriteReferrerId"
            >
              <StyledInput
                placeholder="Mã GUID người giới thiệu"
                onChange={onDataChange}
              />
            </Form.Item>
          </Col>
        </Row>
        <Row gutter={24} style={{ padding: 12, flexDirection: "column", }}>
          <Col span={24} md={12}>
            <Form.Item
              required
              label="Tính hoa hồng: "
              name="isCalcCommission"
              valuePropName="checked"
            >
              <Checkbox defaultChecked={false} onChange={onDataChange}>
                Yêu cầu tính hoa hồng giao dịch
              </Checkbox>
            </Form.Item>
          </Col>
        </Row>
        <div style={{fontStyle: "italic", fontSize: 12}}>
            Chú ý:
            <br />- Với trường hợp là bảo hiểm Ô tô, xe máy thì tên file phải trùng với biển số xe đăng ký trong file Excel
            <br />- Với trường hợp là bảo hiểm Sức khỏe thì tên file phải trùng với căn cước công dân của người được thụ hưởng
            <br />- Với trường hợp là sự kiện khác thì tên file phải trùng với số điện thoại của người mua
          </div>
        <Row gutter={24} style={{ padding: 12, justifyContent: "center", }}>
          <Button
            loading={isSubmitLoading}
            className="withdraw-fomr-submit"
            type="primary"
            style={{ marginTop: 12, marginLeft: 12, }}
            onClick={(e) => offlineImportInsuranceMutation(data)}
          >
            Upload hợp đồng
          </Button>
        </Row>
      </Form>
    </>
  );
};
const StyledInput = styled(Input)`
  border: unset;
  border-bottom: 1px solid lightgray;
  margin-bottom: 16px;
  display: block;
`;
export default AdminImportContractPage;
import type { NextPage } from "next";
import CustomBreadCrumb from "src/layout/CustomBreadCrumb";
import TransactionHistory from "src/views/admin/TransactionHistory";

const AdminCustomerPage: NextPage = () => {
  return (
    <>
      <CustomBreadCrumb
        items={[
          {
            title: "Khách hàng",
            href: "/admin/customer",
          },
          {
            title: "Lịch sử giao dịch",
          },
        ]}
      ></CustomBreadCrumb>
      <TransactionHistory />
    </>
  );
};

export default AdminCustomerPage;

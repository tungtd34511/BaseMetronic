import type { NextPage } from "next";
import CustomBreadCrumb from "src/layout/CustomBreadCrumb";
import ListCustomer from "src/views/admin/ListCustomer";

const AdminCustomerPage: NextPage = () => {
  return (
    <>
      <CustomBreadCrumb
        items={[
          {
            title: "Khách hàng",
            href: "/admin/customer",
          },
        ]}
      ></CustomBreadCrumb>
      <ListCustomer />
    </>
  );
};

export default AdminCustomerPage;

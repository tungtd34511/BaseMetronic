import type { NextPage } from "next";
import { useState } from "react";
import CustomDateRangePicker from "src/common/CustomDateRangePicker";
import CustomBreadCrumb from "src/layout/CustomBreadCrumb";

import moment from "moment";
import AdminReferralList from "src/views/admin/AdminReferralList";

const ReferredPage: NextPage = () => {
  const [dateRange, setdateRange] = useState({
    from: moment().subtract(30, "days").valueOf(),
    to: moment().valueOf(),
  });
  return (
    <>
      <CustomBreadCrumb
        items={[{ title: "Lịch sử giới thiệu" }]}
      ></CustomBreadCrumb>
      <CustomDateRangePicker
        startDate={dateRange.from}
        endDate={dateRange.to}
        onChange={(from, to) => setdateRange({ from, to })}
      />
      <AdminReferralList dateRange={dateRange} />
    </>
  );
};

export default ReferredPage;

import { Tabs } from "antd";
import type { NextPage } from "next";
import CustomBreadCrumb from "src/layout/CustomBreadCrumb";
import UserVertiyList from "src/views/admin/UserVertifyList";
import styled from "styled-components";

const AdminCustomerPage: NextPage = () => {
  return (
    <>
      <CustomBreadCrumb
        items={[
          {
            title: "Thông tin hồ sơ",
            href: "/admin/vertified",
          },
        ]}
      ></CustomBreadCrumb>

      <StyledTabs>
        <Tabs.TabPane tab="Hồ sơ đã duyệt" key="1">
          <UserVertiyList isVertified={true} />
        </Tabs.TabPane>
        <Tabs.TabPane tab="Hồ sơ chờ duyệt" key="2">
          <UserVertiyList isVertified={false} />
        </Tabs.TabPane>
      </StyledTabs>
    </>
  );
};

export default AdminCustomerPage;
const StyledTabs = styled(Tabs)`
  width: 100%;

  .ant-tabs-nav::before {
    border: unset;
  }
  .ant-tabs-tab.ant-tabs-tab-active .ant-tabs-tab-btn {
    color: black;
    font-weight: 300;
  }
`;

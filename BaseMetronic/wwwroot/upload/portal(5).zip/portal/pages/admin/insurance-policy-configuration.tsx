import type { NextPage } from "next";
import CustomBreadCrumb from "src/layout/CustomBreadCrumb";
import InsurancePolicyConfigurationList from "src/views/admin/InsurancePolicyConfigurationList";

const AdminVoucherPage: NextPage = () => {
    return (
        <>
            <CustomBreadCrumb
                items={[
                    {
                        title: "Cài đặt hoa hồng",
                        href: "/admin/insurance-policy-configuration",
                    },
                ]}
            ></CustomBreadCrumb>
            <InsurancePolicyConfigurationList />
        </>
    );
};

export default AdminVoucherPage;

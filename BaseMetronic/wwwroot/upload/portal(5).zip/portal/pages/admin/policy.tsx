import { Tabs } from "antd";
import type { NextPage } from "next";
import CustomBreadCrumb from "src/layout/CustomBreadCrumb";
import styled from "styled-components";
import PolicyList from "../../src/views/admin/PolicyListOnline";

const AdminPolicyPage: NextPage = () => {
  return (
      <>
        <CustomBreadCrumb
            items={[
              {
                title: "Hợp đồng bảo hiểm",
                href: "/admin/policy",
              },
            ]}
        ></CustomBreadCrumb>
        <StyledTabs>
          <Tabs.TabPane tab="Danh sách hợp đồng online" key="1">
            <PolicyList/>
          </Tabs.TabPane>
          <Tabs.TabPane tab="Danh sách hợp đồng offline" key="2">
            {/* <div>hihi</div> */}
          </Tabs.TabPane>
        </StyledTabs>
      </>
  );
};

export default AdminPolicyPage;

const StyledTabs = styled(Tabs)`
  width: 100%;

  .ant-tabs-nav::before {
    border: unset;
  }
  .ant-tabs-tab.ant-tabs-tab-active .ant-tabs-tab-btn {
    color: black;
    font-weight: 300;
  }
`;

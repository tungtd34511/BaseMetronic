import { Col, Row } from "antd";
import type { NextPage } from "next";
import dynamic from "next/dynamic";

import CustomDateRangePicker from "src/common/CustomDateRangePicker";
import { FlexBox } from "src/common/FlexBox";
import CustomBreadCrumb from "src/layout/CustomBreadCrumb";
import moment from "moment";
import { useState } from "react";
import { useGetInsuranceReportQuery } from "store/APIs/referrer";
import Metric from "src/views/analytic/Metric";
import {
  AccountBookFilled,
  HighlightFilled,
  ProfileFilled,
} from "@ant-design/icons";
import useFormatter from "src/hooks/useFormatter";

const InsuranceOverviewReport = dynamic(
  () => import("src/views/admin/InsuranceOverviewReport"),
  {
    ssr: false,
  }
);

const ReportPage: NextPage = () => {
  const [dateRange, setdateRange] = useState({
    from: moment().subtract(30, "days").valueOf(),
    to: moment().valueOf(),
  });
  const { numberFormatter, formatter } = useFormatter();

  const { data: insuranceReportData, isLoading: isLoadingInsuranceReport } =
    useGetInsuranceReportQuery({
      ...dateRange,
      page: 1,
      limit: 1000,
    });

  return (
    <>
      <CustomBreadCrumb
        items={[{ title: "Báo cáo tổng quan", href: "/report" }]}
      ></CustomBreadCrumb>
      <FlexBox style={{ justifyContent: "flex-end", paddingRight: "3%" }}>
        <CustomDateRangePicker
          startDate={dateRange.from}
          endDate={dateRange.to}
          onChange={(from, to) => {
            setdateRange({ from, to });
          }}
        />
      </FlexBox>

      <Row
        style={{
          marginTop: 30,
        }}
      >
        <Col span={24} xl={24}>
          <Metric
            items={[
              {
                title: "Lượt tạo bảo hiểm",
                value: numberFormatter.format(
                  insuranceReportData?.accumulate?.createdCount || 0
                ),
                icon: <HighlightFilled />,
              },
              {
                title: "Lượt thanh toán BH",
                value: numberFormatter.format(
                  insuranceReportData?.accumulate?.paidCount || 0
                ),
                icon: <ProfileFilled />,
              },

              {
                title: "Số bảo hiểm phát hành",
                value: numberFormatter.format(
                  insuranceReportData?.accumulate?.finishedCount || 0
                ),
                icon: <ProfileFilled />,
              },

              {
                title: "Lượt tạo bảo hiểm qua người giới thiệu",
                value: numberFormatter.format(
                  insuranceReportData?.accumulate?.hasReferrerCount || 0
                ),
                icon: <AccountBookFilled />,
              },

              {
                title: "Giá trị voucher đã dùng",
                value: formatter.format(
                  insuranceReportData?.accumulate?.discount || 0
                ),
                icon: <AccountBookFilled />,
              },

              {
                title: "Doanh thu",
                value: formatter.format(
                  insuranceReportData?.accumulate?.revenue || 0
                ),
                icon: <AccountBookFilled />,
              },
            ]}
          />

          <InsuranceOverviewReport
            data={insuranceReportData}
            isLoading={isLoadingInsuranceReport}
          />
        </Col>
      </Row>
    </>
  );
};

export default ReportPage;

import { UploadOutlined } from "@ant-design/icons";
import { Alert, Button, Col, Form, Row, Upload } from "antd";
import type { NextPage } from "next";
import CustomBreadCrumb from "src/layout/CustomBreadCrumb";
import * as XLSX from "xlsx";
import React, { useState } from "react";
import { message } from 'antd';
import { ADMIN_PATH } from "store/APIs/common";
const AdminImportContractPage: NextPage = () => {
  const [dataExcel, setDataExcel] = useState([])
  const [loading, setLoading] = useState(false)

  const url = `${process.env.API_HOST}/api/`;
  const [form] = Form.useForm();
  const handleCustomUploadFile = async ({ file, onSuccess, onProgress }: Record<string, any>) => {
    let extension = file.name.split('.').pop();
    if (extension === 'xlsx' || extension === 'xls') {
      const options = {
        raw: false,
        dateNF: 'dd-mm-yyy', // Specify the date format string here
      };

      const fileReader = new FileReader();
      fileReader.readAsArrayBuffer(file);
      fileReader.onload = (e) => {
        if (e.target) {
          const jsonOpts = {
            raw: false,
            dateNF: 'd"/"m"/"yyyy' // <--- need dateNF in sheet_to_json options (note the escape chars)
          }
          const bufferArray = e.target.result;
          const wb = XLSX.read(bufferArray, {
            cellDates: true,
            cellText: false,
          });
          const wsname = wb.SheetNames[0];
          const ws = wb.Sheets[wsname];
          const dataEx = XLSX.utils.sheet_to_json(ws, jsonOpts);
          console.log(dataEx);
          setDataExcel(dataEx as []);
        }
      };
    } else {
      message.error('File import phải có định dạnh xls hoặc xlxs. Vui lòng thử lại', 4);
    }
    onProgress({ percent: 100 });
    onSuccess(`done`);
  }
  console.log(dataExcel);
  const originalDate = new Date("Sun Nov 26 2023 23:59:56 GMT+0700 (Indochina Time)");
  const year = originalDate.getFullYear();
  const month = String(originalDate.getMonth() + 1).padStart(2, '0');
  const day = String(originalDate.getDate()).padStart(2, '0');

  const convertedDate = `${year}/${month}/${day}`;
  console.log(convertedDate);
  return (
    <>
      <CustomBreadCrumb
        items={[
          {
            title: "Nhập hợp đồng theo lô",
            href: ADMIN_PATH.IMPORT_CONTRACT_LOTS,
          },
        ]}
      ></CustomBreadCrumb>
      <Form
        form={form}
        name="basic"
        labelCol={{ span: 24 }}
        wrapperCol={{ span: 24 }}
        style={{ width: "100%" }}
        initialValues={{ remember: true }}
        className="withdraw-form-container"
      >
        <Row gutter={24} style={{ padding: 12, flexDirection: "column", }}>
          <Col span={24} md={12}>
            <Form.Item
              required
              label="Tải hợp đồng của bạn lên:"
              name="GcnFiles"
              rules={[
                { required: true, message: "Không được để trống" },
              ]}
            >
              <Upload
                customRequest={handleCustomUploadFile}
                multiple={false}
                maxCount={1}
                accept={"Excel file |.xls, .xlsx"}
              >
                <div>
                  <Button icon={<UploadOutlined />}>Chọn tệp</Button>
                </div>
              </Upload>
            </Form.Item>
          </Col>
        </Row>
        <Row gutter={24} style={{ padding: 12, justifyContent: "center", }}>
          <Button
            loading={loading}
            className="withdraw-fomr-submit"
            type="primary"
            style={{ marginTop: 12, marginLeft: 12, }}
            onClick={ (e) => {
            }}
          >
            Upload hợp đồng
          </Button>
        </Row>
      </Form>
    </>
  );
};

export default AdminImportContractPage;
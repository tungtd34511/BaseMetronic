import type { NextPage } from "next";

const DashBoardPage: NextPage = () => {
  return <>Comming Soon</>;
};

export default DashBoardPage;

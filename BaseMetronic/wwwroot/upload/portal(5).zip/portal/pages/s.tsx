import { message, Spin } from "antd";
import { useRouter } from "next/router";
import React, { useEffect } from "react";
import { FlexBox } from "src/common/FlexBox";
import { ACCESS_TOKEN_KEY } from "src/constants";
import { useLoginBySignedStrMutation } from "store/APIs/user";

function LoginPage() {
  const router = useRouter();
  const [loginBySignedStrMutation, { data, isLoading, isError }] =
    useLoginBySignedStrMutation();

  useEffect(() => {
    if (!router.query.s) return;
    loginBySignedStrMutation({
      signedStr: String(router.query.s),
    });
  }, [router.query, loginBySignedStrMutation]);

  useEffect(() => {
    if (!router.query.s) return;
    if (data && !isLoading) {
      window.localStorage.setItem(ACCESS_TOKEN_KEY, data.jwtAccessToken);
      message.success("Đăng nhập thành công");
      window.open("/analytic/report", "_self");
    }
    if (isError) {
      window.open("/login", "_self");
    }
  }, [data, isLoading, router.query.s, isError]);

  return <Spin />;
}

export default LoginPage;

LoginPage.defaultProps = {
  layout: (props: Record<string, unknown>) => (
    <FlexBox
      style={{
        width: "100vw",
        height: "100vh",
        overflow: "auto",
        justifyContent: "center",
        alignItems: "center",
      }}
      {...props}
    />
  ),
  disableAuth: true,
};

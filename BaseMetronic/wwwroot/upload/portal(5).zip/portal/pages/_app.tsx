import "../styles/globals.css";
import "../styles/custom-theme.less";
import "nprogress/nprogress.css";

import React, { useMemo } from "react";
import { Provider } from "react-redux";

import { store } from "store/store";
import Head from "next/head";
import Router from "next/router";
import NProgress from "nprogress";
import CustomLayout from "src/layout";
import LoadAsset from "src/layout/LoadAsset";
import Auth from "src/layout/Auth";
import { IPageProps } from "interfaces/page_props.interface";
import { AppProps } from "next/app";

function MyApp({ Component, pageProps }: AppProps<IPageProps>) {
  React.useEffect(() => {
    const handleRouteStart = () => NProgress.start();
    const handleRouteDone = () => NProgress.done();

    Router.events.on("routeChangeStart", handleRouteStart);
    Router.events.on("routeChangeComplete", handleRouteDone);
    Router.events.on("routeChangeError", handleRouteDone);
    const script = document.createElement('script');

    script.innerHTML = `var Tawk_API=Tawk_API||{ }, Tawk_LoadStart=new Date();
    (function(){
      var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
      s1.async=true;
      s1.src='https://embed.tawk.to/652392596fcfe87d54b7d265/1hc9f7c8u';
      s1.charset='UTF-8';
      s1.setAttribute('crossorigin','*');
      s0.parentNode.insertBefore(s1,s0);
    })();
      setInterval(function () {
        var lstFrame = document.querySelectorAll('iframe');
        for (var i = 0; i < lstFrame.length; i++) {
          lstFrame[i].contentWindow.document.body.querySelector('.tawk-footer .tawk-text-center.tawk-padding-small')?.remove()
        }
    }, 10)
    `;
    script.async = true;
    document.body.appendChild(script);
    return () => {
      // Make sure to remove the event handler on unmount!
      Router.events.off("routeChangeStart", handleRouteStart);
      Router.events.off("routeChangeComplete", handleRouteDone);
      Router.events.off("routeChangeError", handleRouteDone);
      document.body.removeChild(script);
    };
  }, []);

  const FinalLayout = useMemo(
    () => Component?.defaultProps?.layout || CustomLayout,
    [Component?.defaultProps?.layout]
  );

  return (
    <Provider store={store}>
      <Head>
        <title>Portal</title>
        <meta
          name="viewport"
          content="minimum-scale=1, initial-scale=1, width=device-width"
        />
      </Head>
      <Auth
        disableAuth={Component?.defaultProps?.disableAuth}
        adminRequired={Component.defaultProps?.adminRequired}
      >
        <FinalLayout {...Component?.defaultProps?.layoutProps}>
          <LoadAsset />
          <Component {...pageProps} />
        </FinalLayout>
      </Auth>
    </Provider>
  );
}

export default MyApp;

/** @type {import('next').NextConfig} */

const withLess = require("next-with-less");

module.exports = withLess({
  output: "standalone",
  reactStrictMode: false,
  env: {
    API_HOST: process.env.API_HOST,
    CLOUD_FRONT_HOST: process.env.CLOUD_FRONT_HOST,
    WS_HOST: process.env.WS_HOST,
    ZALO_DEEPLINK: process.env.ZALO_DEEPLINK,
    ZALO_DEEPLINK_VERSION: process.env.ZALO_DEEPLINK_VERSION || "",
  },
  typescript: {
    // !! WARN !!
    // Dangerously allow production builds to successfully complete even if
    // your project has type errors.
    // !! WARN !!
    ignoreBuildErrors: true,
  },
});

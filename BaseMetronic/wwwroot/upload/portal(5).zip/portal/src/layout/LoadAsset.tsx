/* eslint-disable @typescript-eslint/no-explicit-any */
import { useEffect } from "react";
import { fontFamilyConfigs } from "src/config/font.config";

const LoadAsset = () => {
  useEffect(() => {
    // eslint-disable-next-line @typescript-eslint/no-var-requires
    const WebFont = require("webfontloader");

    WebFont.load({
      google: {
        families: fontFamilyConfigs.map(({ title }) => title),
      },
    });
  }, []);

  return <div style={{ display: "none" }} />;
};

export default LoadAsset;

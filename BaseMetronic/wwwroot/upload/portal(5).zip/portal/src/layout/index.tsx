import React, { PropsWithChildren, ReactElement, useState } from "react";
import { Layout } from "antd";
import Sider from "./Sider";
import Header from "./Header";

const CustomLayout = (props: PropsWithChildren<unknown>): ReactElement => {
  const [collapsed, setCollapsed] = useState(false);
  return (
    <Layout
      style={{
        minHeight: "100vh",
        width: "max-content",
        height: "max-content",
      }}
    >
      <Header />
      <Layout
        style={{
          width: "max-content",
          minWidth: "100vw",
          maxWidth: "100vw",
        }}
      >
        <Sider collapsed={collapsed} setCollapsed={setCollapsed} />
        <Layout.Content
          style={{
            padding: "0.5vh 1vw",
            height: "max-content",
            width: "max-content",
          }}
          {...props}
        />
      </Layout>
    </Layout>
  );
};

export default CustomLayout;

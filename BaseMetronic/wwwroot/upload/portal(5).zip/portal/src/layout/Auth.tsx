import { Spin } from "antd";
import { PropsWithChildren } from "react";
import useAuth from "src/hooks/useAuth";

const Auth = (
  props: PropsWithChildren<{ disableAuth?: boolean; adminRequired?: boolean }>
) => {
  const { userData } = useAuth({
    adminRequired: props.adminRequired,
    disableAuth: props.disableAuth,
  });

  if (!userData && !props.disableAuth) {
    return <Spin />;
  }

  return <>{props.children}</>;
};

export default Auth;

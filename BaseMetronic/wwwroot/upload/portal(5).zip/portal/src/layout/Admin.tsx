import { Breadcrumb, Typography } from "antd";
import { ILayoutProps } from "interfaces/page_props.interface";
import { useRouter } from "next/router";
import React, { PropsWithChildren } from "react";
import { Box } from "src/common/Box";
import { FlexBox } from "src/common/FlexBox";
import NextLink from "src/common/NextLink";

const AdminLayout = ({
  breadcrumbs,
  ...props
}: PropsWithChildren<ILayoutProps>) => {
  const router = useRouter();
  return (
    <Box
      style={{
        width: "100vw",
        height: "100vh",
        overflow: "auto",
      }}
    >
      {(breadcrumbs || []).length > 0 && (
        <FlexBox
          style={{
            justifyContent: "center",
            margin: 10,
          }}
        >
          <Box>
            <Breadcrumb>
              {breadcrumbs?.map((item) => (
                <Breadcrumb.Item
                  key={
                    typeof item.href == "string" ? item.href : item.href(router)
                  }
                >
                  <NextLink
                    href={
                      typeof item.href == "string"
                        ? item.href
                        : item.href(router)
                    }
                  >
                    <Typography.Text>
                      {typeof item.label == "string"
                        ? item.label
                        : item.label(router)}
                    </Typography.Text>
                  </NextLink>
                </Breadcrumb.Item>
              ))}
            </Breadcrumb>
          </Box>
        </FlexBox>
      )}
      <FlexBox {...props} />
    </Box>
  );
};

export default AdminLayout;

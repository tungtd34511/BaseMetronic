import {
  Layout,
  Menu,
  // Progress,
} from "antd";

import { useRouter } from "next/router";
import React, { useEffect, useMemo, useState } from "react";
import { Grid } from "antd";
import styled from "styled-components";
import type { MenuProps } from "antd";
import useRole from "src/hooks/useRole";
import {
  Chart,
  Clock,
  DocumentText,
  Game,
  Headphone,
  Home,
  Math,
  MoneyRecive,
  NotificationBing,
  PresentionChart,
  Profile2User,
  Setting2,
  TicketDiscount,
} from "iconsax-react";
import { FormOutlined, UserAddOutlined, UsergroupAddOutlined } from "@ant-design/icons";

type MenuItem = Required<MenuProps>["items"][number];

function getItem(
  label: React.ReactNode,
  key: React.Key,
  icon?: React.ReactNode,
  children?: MenuItem[],
  type?: "group"
): MenuItem {
  return {
    key,
    icon,
    children,
    label,
    type,
  } as MenuItem;
}

export enum RoutePath {
  DASHBOARD = "/dashboard",
  ANALYTIC_REPORT = "/analytic/report",
  ANALYTIC_REFER = "/analytic/referred",
  AGENT = "/agent",
  AGENT_REFER = "/agent/referred",
  TRANSACTION = "/my/transactions",
  WITHDRAW = "/agency/withdraw",
  VOUCHER = "/agency/voucher",
  DOCS = "/public/docs",
  NOTI = "/my/notifications",
  ACCOUNT_SETTING_INFO = "/my/account/info",
  ACCOUNT_SETTING_PASSWORD = "/my/account/password",
  CONTRACT = "/contract",
  TYPE_INSURANCE = "/type-insurance",
  CONTRACT_OFFLINE = "/contract-offline",
  ROLE = "/role",
  PARTNER = "/partner",
  ACCOUNT = "/account",

}

function Sider({
  collapsed,
  setCollapsed,
}: {
  collapsed: boolean;
  setCollapsed: React.Dispatch<React.SetStateAction<boolean>>;
}) {
  const screens = Grid.useBreakpoint();

  const { isAdmin, isAgency, isCS, isAccountant } = useRole();
  const [selectedKey, setSelectedKey] = useState(RoutePath.ANALYTIC_REPORT);
  const router = useRouter();
  const items: MenuProps["items"] = useMemo(
    () =>
      [
        getItem(
          "TỔNG QUAN",
          RoutePath.DASHBOARD,
          <Home color="#ffffff" size={20} />
        ),

        getItem(
          "THỐNG KÊ & BÁO CÁO",
          RoutePath.ANALYTIC_REPORT,
          <Chart color="#ffffff" size={20} />,

          [
            getItem("Báo cáo tổng quan", RoutePath.ANALYTIC_REPORT),
            getItem("Lịch sử giới thiệu", RoutePath.ANALYTIC_REFER),
          ]
        ),
        isAgency &&
        getItem(
          "THÀNH VIÊN",
          RoutePath.AGENT,
          <Profile2User color="#ffffff" size={20} />,
          [
            getItem("Danh sách thành viên", RoutePath.AGENT),
            getItem("Lịch sử giới thiệu", RoutePath.AGENT_REFER),
          ]
        ),
        // getItem(
        //   "Lịch sử mua BH",
        //   RoutePath.TRANSACTION,
        //   <Clock color="#555555" size={20} />
        // ),
        // isAgency &&
        getItem(
          "THANH TOÁN HOA HỒNG",
          RoutePath.WITHDRAW,
          <MoneyRecive size={20} color="#ffffff" />
        ),
        // isAgency &&
        // getItem(
        //   "KHUYẾN MÃI",
        //   RoutePath.VOUCHER,
        //   <TicketDiscount color="#ffffff" size={20} />
        // ),
        (isAgency || isAdmin) &&
        getItem(
          "HỢP ĐỒNG OFFLINE",
          RoutePath.CONTRACT,
          <FormOutlined color="#ffffff" size={20} />
        ),
        // (isAdmin) &&
        // getItem(
        //   "Loại bảo hiểm",
        //   RoutePath.TYPE_INSURANCE,
        //   <FormOutlined color="#555555" size={20} />
        // ),
        // getItem(
        //   "Vai trò",
        //   RoutePath.ROLE,
        //   <UserAddOutlined color="#555555" size={30} />
        // ),
        // getItem(
        //   "Đối tác",
        //   RoutePath.PARTNER,
        //   <UsergroupAddOutlined color="#555555" size={20} />
        // ),
        // getItem(
        //   "Tài khoản",
        //   RoutePath.ACCOUNT,
        //   <FormOutlined color="#555555" size={20} />
        // ),
        getItem(
          "TÀI LIỆU",
          RoutePath.DOCS,
          <DocumentText color="#ffffff" size={20} />
        ),
        isAdmin &&
        getItem(
          "QUẢN TRỊ HỆ THỐNG",
          "/admin/report",

          <PresentionChart size={20} color="#ffffff" />,
          [
            getItem("Báo cáo tổng quan", "/admin/report"),
            getItem("Cài đặt hoa hồng", "/admin/insurance-policy-configuration"),
            getItem("Quản lý tài khoản", "/admin/customer"),
            getItem("Quản lý đại lý", "/admin/agency"),
            getItem("Hợp đồng bảo hiểm", "/admin/policy"),
            // getItem("Quản lý khuyến mãi", "/admin/voucher"),
            getItem("Lô voucher giảm giá", "/admin/voucherv2"),
            // getItem("Nhập hợp đồng offline", "/admin/import-contract"),
            // getItem("Nhập hợp đồng theo lô", ADMIN_PATH.IMPORT_CONTRACT_LOTS),
            getItem("Phê duyệt hồ sơ", "/admin/vertified"),
            // getItem("Cài đặt hoa hồng", "/admin/commission"),
          ]
        ),

        // isCS &&
        getItem(
          "CSKH",
          "/cs/insurance",
          <Headphone size={20} color="#ffffff" />,
          [
            getItem("Cập nhật BH", "/cs/insurance"),
            getItem("Báo cáo", "/cs/report"),
            getItem("Xử lý thanh toán", "/cs/withdraw"),
          ]
        ),
        isAccountant &&
        getItem(
          "KẾ TOÁN",
          "/accountant/withdraw",
          <Math size={20} color="#ffffff" />,
          [getItem("Xử lý thanh toán", "/accountant/withdraw")]
        ),
        // isAdmin &&
        // getItem(
        //   "Quản lý trò chơi",
        //   "/games/log",
        //   <Game size={20} color="#555555" />,
        //   [
        //     getItem("Hoạt động", "/games/log"),
        //     getItem("Cấu hình", "/games/config"),
        //   ]
        // ),
      ].filter(Boolean) as MenuProps["items"],
    [isAdmin, isAgency, isCS, isAccountant]
  );

  const onClick: MenuProps["onClick"] = (e) => {
    router.push(e.key);
  };

  useEffect(() => {
    const menuItemMatch = (items || []).find(
      (item) => router.pathname == String(item?.key)
    );
    setSelectedKey((menuItemMatch?.key || router.pathname) as any);
  }, [router.pathname, items]);

  useEffect(() => {
    if (!Object.values(screens).length) return;
    if (!screens.xl) {
      setCollapsed(true);
    } else {
      setCollapsed(false);
    }
  }, [screens, setCollapsed]);

  return (
    <>
      <Layout.Sider
        trigger={null}
        collapsible
        collapsed={collapsed}
        width={280}
      >
        <StyledMenu theme={"dark"}
          inlineCollapsed
          onClick={onClick}
          style={{
            backgroundColor: "transparent",
          }}
          selectedKeys={[selectedKey]}
          defaultOpenKeys={["/analytic/report"]}
          mode="inline"
          items={items}
        />
        <StyledMenu theme={"dark"}
          inlineCollapsed
          onClick={onClick}
          style={{
            backgroundColor: "#0d1838",
            borderTop: "1px solid #0d1838",
            position: "sticky",
            bottom: 0,
            marginTop: 500,
          }}
          selectedKeys={[selectedKey]}
          defaultOpenKeys={["/analytic/report"]}
          mode="inline"
          items={[
            getItem(
              "Thông báo",
              RoutePath.NOTI,
              <NotificationBing size={20} color="#555555" />
            ),
            getItem(
              "Cài đặt tài khoản",
              RoutePath.ACCOUNT_SETTING_INFO,
              <Setting2 color="#555555" size={20} />,
              [
                getItem("Cập nhật thông tin", RoutePath.ACCOUNT_SETTING_INFO),
                getItem("Đổi mật khẩu", RoutePath.ACCOUNT_SETTING_PASSWORD),
              ]
            ),
          ]}
        />
      </Layout.Sider>
    </>
  );
}
const StyledMenu = styled(Menu)`
  //.ant-menu:not(.ant-menu-horizontal) .ant-menu-item-selected {
  //  background-color: #ffffff;
  //}
  //border: unset;
`;

export default Sider;

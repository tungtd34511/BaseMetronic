import { LogoutOutlined } from "@ant-design/icons";
import { Button, Image, Layout } from "antd";
import { useRouter } from "next/router";
import React from "react";
import { FlexBox } from "src/common/FlexBox";
import { useGetMyUserInfoQuery } from "store/APIs/user";

const Header = () => {
  const router = useRouter();

  const { data } = useGetMyUserInfoQuery();

  return (
    <Layout.Header
      style={{
        background: "rgb(13 24 56)",
        boxShadow: "0px 2px 4px rgba(0, 0, 0, 0.1)",
        zIndex: 100,
        padding: "0 20px",
      }}
    >
      <FlexBox
        style={{
          alignItems: "center",
          justifyContent: "space-between",
          height: "100%",
        }}
      >
        <Image
          src="/baohiemviet_logo_white_horizontal.png"
          alt="logo"
          style={{ height: 30,maxWidth:'182px' ,background: "rgba(0,0,0,0.1)" }}
        />
        <FlexBox style={{ alignItems: "center", flex: "unset" }}>
          {data?.avatar && (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={data?.avatar} alt={data.name} height={40} />
          )}

          <Button
            type="link"
            style={{ color: "white" }}
            icon={<LogoutOutlined />}
            onClick={() => {
              window.localStorage.clear();
              router.push("/login");
            }}
          ></Button>
        </FlexBox>
      </FlexBox>
    </Layout.Header>
  );
};

export default Header;

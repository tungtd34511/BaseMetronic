import { Breadcrumb, Typography } from "antd";
import React, { PropsWithChildren } from "react";
import { Box } from "src/common/Box";
import { FlexBox } from "src/common/FlexBox";
import NextLink from "src/common/NextLink";

type Props = {
  items: {
    title: string;
    href?: string;
  }[];
};

const CustomBreadCrumb = ({ items, children }: PropsWithChildren<Props>) => {
  return (
    <Box
      style={{
        borderBottom: "1px solid lightgray",
        marginBottom: 30,
        marginTop: 30,
        paddingBottom: 10,
        width: "100%",
      }}
    >
      <Breadcrumb>
        {[{ title: "Trang chủ", href: "/analytic/report" }, ...items].map(
          (item) => (
            <Breadcrumb.Item key={item.title}>
              {item.href ? (
                <NextLink href={item.href}>
                  <Typography.Text style={{ fontSize: 12 }}>
                    {item.title}
                  </Typography.Text>
                </NextLink>
              ) : (
                <Typography.Text style={{ fontSize: 12 }}>
                  {item.title}
                </Typography.Text>
              )}
            </Breadcrumb.Item>
          )
        )}
      </Breadcrumb>
      <FlexBox style={{ justifyContent: "space-between" }}>{children}</FlexBox>
    </Box>
  );
};

export default CustomBreadCrumb;

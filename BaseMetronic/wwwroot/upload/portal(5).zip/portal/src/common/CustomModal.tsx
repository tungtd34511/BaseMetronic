import { Modal, ModalProps } from 'antd';
import React from 'react';
interface ICustomModal extends ModalProps {
    children: JSX.Element[] | JSX.Element
    isModalOpen: boolean
    setIsModalOpen: React.Dispatch<React.SetStateAction<boolean>>
    handleOk: () => void
    handleCancel: () => void
    title?: string
    okText?: string
    cancelText?: string
}

const CustomModal = ({ children,
    handleOk,
    handleCancel,
    setIsModalOpen,
    isModalOpen,
    title = 'Thông báo',
    okText = 'Lưu',
    cancelText = 'Hủy'
}: ICustomModal) => {
    return <Modal
        width={1920}
        okText={okText}
        cancelText={cancelText}
        title={title}
        centered
        visible={isModalOpen}
        onOk={handleOk}
        onCancel={handleCancel}>
        {children}
    </Modal>



};

export default CustomModal;
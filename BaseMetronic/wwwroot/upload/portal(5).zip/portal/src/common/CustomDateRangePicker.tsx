import { DatePicker } from "antd";
import React from "react";
import { nowInSeconds } from "src/utils/date";
import moment from "moment";

type Props = {
  onChange: (startDate: number, endDate: number) => void;
  startDate: Date | number | string | any;
  endDate: Date | number | string | any;
};

const CustomDateRangePicker = ({ onChange, startDate, endDate }: Props) => {
  return (
    <DatePicker.RangePicker
      style={{ width: '100%' }}
      clearIcon={false}
      value={[moment(startDate), moment(endDate)]}
      onChange={(data) => {
        onChange(
          data?.[0]?.startOf("day").valueOf() || 0,
          data?.[1]?.endOf("day")?.valueOf() || nowInSeconds()
        );
      }}
    />
  );
};

export default CustomDateRangePicker;

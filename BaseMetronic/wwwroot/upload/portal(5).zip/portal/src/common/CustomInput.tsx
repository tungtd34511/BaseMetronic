import React from 'react';
import { Input, InputProps } from 'antd';

interface CustomInputProps extends InputProps {
    customProp?: string;
}

const CustomInput: React.FC<CustomInputProps> = (props) => {
    const { customProp, ...rest } = props;

    return <Input
        {...rest} />
};

export default CustomInput;
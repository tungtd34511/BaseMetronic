import Link, { LinkProps } from "next/link";
import React from "react";

const NextLink = ({
  children,
  target,
  style,
  ...props
}: LinkProps & {
  children: React.ReactElement;
  target?: "_self" | "_blank";
  style?: React.CSSProperties;
}) => {
  return (
    <Link {...props} passHref>
      <a target={target || "_self"} style={{ ...style }}>
        {children}
      </a>
    </Link>
  );
};

export default NextLink;

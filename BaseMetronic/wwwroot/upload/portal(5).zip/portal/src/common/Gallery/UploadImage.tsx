import { Upload, UploadFile, UploadProps } from "antd";
import React, {
  PropsWithChildren,
  useCallback,
  useEffect,
  useState,
} from "react";
import { getS3ImageUrl } from "src/utils/S3";
import { useLazyGetSingedUploadImageUrlQuery } from "store/APIs/storage";

type Props = PropsWithChildren<
  {
    onUpLoading?: () => void;
    onSuccessUpload?: (data: { origin: string }) => void;
    onChangeFileList?: (data: any) => void;
  } & UploadProps
>;

const UploadImage = ({
  onUpLoading,
  onSuccessUpload,
  onChangeFileList,
  ...props
}: Props) => {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any

  const [getSignedUrl] = useLazyGetSingedUploadImageUrlQuery();

  const handleCustomUploadImage = useCallback(
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    async ({ file, onSuccess, onProgress }: Record<string, any>) => {
      const fileName = file.name;
      const { data: resUrl } = await getSignedUrl({ fileName });
      onProgress({ percent: 10 });

      const signedUrl = resUrl?.url || "";
      await fetch(decodeURIComponent(signedUrl), {
        method: "PUT",
        body: file,
      });

      onProgress({ percent: 50 });

      onSuccessUpload?.({
        origin: getS3ImageUrl(fileName),
      });
      onSuccess(getS3ImageUrl(fileName));
    },
    [onUpLoading, onSuccessUpload, getSignedUrl]
  );

  const handleOnChange = ({ file, fileList, event }: any) => {
    //Using Hooks to update the state to the current filelist
    //filelist - [{uid: "-1",url:'Some url to image'}]
    onChangeFileList?.(fileList);
  };

  return (
    <>
      <Upload
        listType="picture-card"
        onChange={handleOnChange}
        customRequest={handleCustomUploadImage}
        accept="image/*"
        {...props}
      />
    </>
  );
};

export default UploadImage;

import { UploadOutlined } from "@ant-design/icons";
import { Button, Image, Modal, Row, Spin } from "antd";
import { PropsWithChildren, useState } from "react";
import { Box } from "../Box";
import UploadImage from "./UploadImage";
import useGallery from "./useGallery";

const Gallery = ({
  children,
  onSelected,
}: PropsWithChildren<{
  onSelected?: (data: { origin: string }) => void;
}>) => {
  const [visible, setVisible] = useState(false);
  const [uploading, setuploading] = useState(false);

  const { images, isLoading, selectedImage, setSelectedImage } = useGallery();

  return (
    <>
      <span onClick={() => setVisible(!visible)}>{children}</span>
      <Modal
        title="Gallery"
        centered
        visible={visible}
        onOk={() => {
          setVisible(false);
          if (selectedImage && onSelected) onSelected({ ...selectedImage });
        }}
        onCancel={() => setVisible(false)}
        width={1000}
        okText="Select"
        cancelText="Cancel"
      >
        <Row>
          <UploadImage
            onUpLoading={() => {
              setuploading(true);
            }}
            onSuccessUpload={() => {
              setuploading(false);
            }}
          >
            <Button
              type="dashed"
              style={{
                color: "rgba(0,0,0,0.5)",
                padding: 0,
                width: 150,
                height: 150,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                margin: 8,
                flexDirection: "column",
              }}
              loading={uploading}
              disabled={uploading}
              icon={<UploadOutlined style={{ fontSize: 40 }} />}
            >
              {uploading ? "" : "Upload"}
            </Button>
          </UploadImage>
          {isLoading && <Spin style={{ padding: 50 }} />}

          {images?.docs?.map((image) => (
            <Box
              key={image.origin}
              style={{
                margin: 8,
                width: 150,
                height: 150,
                ...(image.origin === selectedImage?.origin && {
                  border: "1px solid #456dc9",
                }),
                overflow: "hidden",
                padding: 10,
                cursor: "pointer",
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
              }}
              onClick={() => setSelectedImage(image)}
            >
              <Image
                preview={false}
                src={image.origin}
                alt=""
                style={{ maxWidth: "100%", maxHeight: "100%" }}
              />
            </Box>
          ))}
        </Row>
      </Modal>
    </>
  );
};

export default Gallery;

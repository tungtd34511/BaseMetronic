import { Upload, UploadFile, UploadProps } from "antd";
import React, {
  PropsWithChildren,
  useCallback,
  useEffect,
  useState,
} from "react";
import { getS3FileUrl, getS3ImageUrl } from "src/utils/S3";
import {
  useLazyGetSingedUploadFileUrlQuery,
  useLazyGetSingedUploadImageUrlQuery,
} from "store/APIs/storage";

type Props = PropsWithChildren<
  {
    onUpLoading?: () => void;
    onSuccessUpload?: (data: { origin: string }) => void;
    onChangeFileList?: (data: any) => void;
  } & UploadProps
>;

const UploadFiles = ({
  onUpLoading,
  onSuccessUpload,
  onChangeFileList,
  ...props
}: Props) => {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any

  const [getSignedUrl] = useLazyGetSingedUploadFileUrlQuery();

  const handleCustomUploadFile = useCallback(
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    async ({ file, onSuccess, onProgress }: Record<string, any>) => {
      const fileName = file.name;
      const { data: resUrl } = await getSignedUrl({ fileName });
      onProgress({ percent: 10 });

      const signedUrl = resUrl?.url || "";
      await fetch(decodeURIComponent(signedUrl), {
        method: "PUT",
        body: file,
      });

      onProgress({ percent: 50 });

      onSuccessUpload?.({
        origin: getS3FileUrl(fileName),
      });
      onSuccess(getS3FileUrl(fileName));
    },
    [onUpLoading, onSuccessUpload, getSignedUrl]
  );

  const handleOnChange = ({ file, fileList, event }: any) => {
    onChangeFileList?.(fileList);
  };

  return (
    <>
      <Upload
        onChange={handleOnChange}
        customRequest={handleCustomUploadFile}
        {...props}
      />
    </>
  );
};

export default UploadFiles;

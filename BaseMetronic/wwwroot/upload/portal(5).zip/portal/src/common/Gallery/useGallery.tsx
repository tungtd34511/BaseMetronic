import { useCallback, useState } from "react";
import { IImage, useGetAllImageQuery } from "store/APIs/storage";

const useGallery = () => {
  const [page, setPage] = useState(1);

  const { data: images, isLoading } = useGetAllImageQuery({
    page,
  });

  const [selectedImage, setSelectedImage] = useState<IImage | null>(null);

  const handleLoadMore = useCallback(() => {
    setPage((page) => page + 1);
  }, []);

  return {
    selectedImage,
    setSelectedImage,
    images,
    isLoading,
    handleLoadMore,
  };
};

export default useGallery;

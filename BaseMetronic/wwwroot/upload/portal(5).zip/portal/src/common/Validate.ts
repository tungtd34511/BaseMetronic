import { message } from 'antd';
export const validateCommistion = (numberLength = 1, message = 'Giá trị phần trăm không hợp lệ') => {
    // var regexPattern = new RegExp("^.{1," + numberLength + "}$");
    const regexPattern = new RegExp("^\\d+(\\.\\d{1," + numberLength + "})?$");

    return {
        regexPattern,
        message
    }
}

export const validateMaxLength = (numberLength = 100, message = 'Không được vượt quá') => {
    // var regexPattern = new RegExp("^.{1," + numberLength + "}$");
    // const regexPattern = new RegExp("^\\.{1," + numberLength + "}$/");
    const regexPattern = new RegExp("^.{1," + numberLength + "}$");

    return {
        regexPattern,
        message: `${message} ${numberLength} ký tự`
    }
}
export const validateChasisNumberAndEngineNumber = (numberLength = 5) => {
    const regexPattern = new RegExp("^.{" + numberLength + "," + 30 + "}$");

    return {
        regexPattern,
        message: 'Không hợp lệ'
    }
}

export const validateEmail = () => {
    const regexPattern = /^\S+@\S+\.\S+$/
    return {
        regexPattern,
        message: `Email không hợp lệ`
    }
}

export const validateIdCard = () => {
    const regexPattern = /^\d{9}(?:\d{3})?$/
    return {
        regexPattern,
        message: `CCCD không hợp lệ`
    }
}

export const validateOnlyNumber = () => {
    const regexPattern = /^\d+$/
    return {
        regexPattern,
        message: `Giá trị không hợp lệ`
    }
}


export const validateNumberWithDots = () => {
    const regexPattern = /^[0-9]+(\.[0-9]+)?$/;
    return {
        regexPattern,
        message: `Giá trị không hợp lệ`
    }
}
export const validatePhoneNumber = () => {

    const regexPattern = /^[0-9]{1,10}$/;
    return {
        regexPattern,
        message: `Số điện thoại không hợp lệ`
    }
}


// function validatePhoneNumber(phoneNumber) {
//     // Sử dụng biểu thức chính quy để kiểm tra định dạng số điện thoại
//     var regex = /((09|03|07|08|05)+([0-9]{8})\b)/g;
//     return regex.test(phoneNumber);
//   }

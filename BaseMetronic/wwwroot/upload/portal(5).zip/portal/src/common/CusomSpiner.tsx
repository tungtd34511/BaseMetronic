import { Spin } from 'antd';
import React from 'react';

const CustomSpiner = () => {
    return <div style={{ top: '50%', left: '50%', transform: 'translate(-50%,-50%)', position: 'fixed',zIndex:9999 }}>
        <Spin size='large' />
    </div>
};

export default CustomSpiner;
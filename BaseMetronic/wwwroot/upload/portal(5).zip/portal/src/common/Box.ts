import styled from "styled-components";

export const Box = styled.div`
  position: relative;
`;

import { Table } from 'antd';
import React, { useState } from 'react';
interface ICustomTable {
    isLoading: boolean,
    columns: any,
    data: any,
    pageSize?: number,
    pageCurrent?: number,
    totalDocs: number,
    onChange: (page: number, pageSize: number) => void,
    pagination?: boolean
}
const CustomTable = ({
    isLoading,
    columns,
    data,
    pageSize = 15,
    pageCurrent = 0,
    onChange,
    totalDocs,
    pagination = true
}: ICustomTable) => {
    const [selectedRowKeys, setSelectedRowKeys] = useState<React.Key[]>([]);
    const onSelectChange = (newSelectedRowKeys: React.Key[]) => {
        setSelectedRowKeys(newSelectedRowKeys);
    };
    const rowSelection = {
        selectedRowKeys,
        onChange: onSelectChange,
    };
    return <Table
        // rowSelection={rowSelection}
        loading={isLoading}
        columns={columns}
        dataSource={data}
        scroll={{
            x: 'max-content'
        }}
        pagination={pagination ? {
            current: pageCurrent,
            pageSizeOptions: [15, 30, 60],
            showSizeChanger: true,
            pageSize: pageSize,
            total: totalDocs || 0,
            onChange(page, pageSize) {
                if (onChange) {
                    onChange(page, pageSize)
                }
            },
        } : false}
    />
};

export default CustomTable;
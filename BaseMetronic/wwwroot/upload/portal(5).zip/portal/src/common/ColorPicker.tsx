import { CaretDownOutlined } from "@ant-design/icons";
import { Input, Popover } from "antd";
import React, { ChangeEvent } from "react";
import { SketchPicker } from "react-color";
import { Box } from "./Box";
import { FlexBox } from "./FlexBox";

type Props = {
  onChange: (color: string) => void;
  color: string;
  disableAlpha?: boolean;
  handleToggleClickOutside?: (visible: boolean) => void;
};

const ColorPicker = ({
  color,
  onChange,
  disableAlpha,
  handleToggleClickOutside,
}: Props) => {
  return (
    <FlexBox
      style={{
        maxHeight: "100%",
        background: "#F6F6F7",
        width: 200,
        flex: "unset",
        borderRadius: 6,
        border: "1.5px solid rgba(29, 27, 41, 0.1)",
        alignItems: "center",
        ...(disableAlpha && {
          width: 110,
        }),
      }}
    >
      <Popover
        onVisibleChange={(visible: boolean) => {
          if (handleToggleClickOutside) handleToggleClickOutside(visible);
        }}
        content={
          <SketchPicker
            disableAlpha={disableAlpha}
            color={color}
            onChange={({ rgb, hex }) => {
              if (disableAlpha) onChange?.(hex);
              else onChange?.(`rgba(${rgb.r},${rgb.g},${rgb.b},${rgb.a ?? 1})`);
            }}
          />
        }
        title="Title"
        trigger="hover"
      >
        <Box
          style={{
            borderRadius: 5,
            width: 20,
            height: 20,
            backgroundColor: color,
            margin: 6,
          }}
        />
      </Popover>
      <Input
        style={{
          border: "unset",
          padding: "0",
          width: 140,
          marginLeft: 5,
          fontSize: 12,
          ...(disableAlpha && {
            width: 60,
          }),
        }}
        value={color}
        onChange={(e: ChangeEvent<HTMLInputElement>) =>
          onChange?.(e.target.value)
        }
      />
      <CaretDownOutlined style={{ color: "rgba(0,0,0,0.3)" }} />
    </FlexBox>
  );
};

export default ColorPicker;

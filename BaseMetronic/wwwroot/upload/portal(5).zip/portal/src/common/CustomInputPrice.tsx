import React from 'react';
import { Form, InputNumber, InputProps } from 'antd';
interface CustomInputProps extends InputProps {
    itemMap: any
}
const CustomInputNumber = ({ itemMap }: CustomInputProps) => {
    const currencyFormatter = (value: any) => `${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    const currencyParser = (value: any) => value.replace(/\$\s?|(,*)/g, '');

    return <Form.Item
        // getValueProps={(i) => ({ value: (i?.trimStart()) })}
        name={itemMap.id}
        rules={itemMap.rules || []}
        label={<span>{itemMap.label}</span>}>
        <InputNumber
            style={{ width: '100%' }}
            formatter={currencyFormatter}
            parser={currencyParser} />
    </Form.Item>
};

export default CustomInputNumber;
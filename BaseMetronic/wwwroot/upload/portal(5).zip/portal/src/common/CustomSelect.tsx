import React from 'react';
import { FormInstance, Select } from 'antd';
import { DefaultOptionType, SelectProps } from 'antd/lib/select';
import { CloseOutlined } from '@ant-design/icons';
const { Option } = Select;
export interface OptionType {
    label: string;
    value: string;
    [x: string]: any;
}
interface CustomSelectProps extends SelectProps {
    options: OptionType[];
    onChange?: (value: string) => void;
    formInsert: FormInstance<any>
}
const CustomSelect: React.FC<CustomSelectProps> = ({ options, formInsert, onChange, ...props }) => {
    const handleSelection = (value: any) => {
        if (onChange) {
            onChange(value);
        }
    };
    function handleClear() {
        formInsert.setFieldsValue({
            [`${props.id}`]: null,
        })
    }
    return (
        <Select
        className='custom-select'
            suffixIcon={props?.value ? <CloseOutlined onClick={handleClear} /> : ''}
            {
            ...props
            }
            showSearch
            onChange={handleSelection}
            filterOption={(input, option: any) => option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0}
        >
            {options.map(option => (
                <Option key={option.value} value={option.value}>
                    {option.label}
                </Option>
            ))}
        </Select>
    );
};

export default CustomSelect;

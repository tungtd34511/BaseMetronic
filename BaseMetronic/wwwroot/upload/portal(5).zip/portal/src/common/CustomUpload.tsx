import { Upload, UploadProps } from "antd";
import React, { PropsWithChildren, useCallback, useState } from "react";
import { getS3SheetUrl } from "src/utils/S3";
import { useLazyGetSingedCustomUploadUrlQuery } from "store/APIs/storage";

type Props = PropsWithChildren<
  {
    onUpLoading?: () => void;
    onSuccessUpload?: (data: { origin: string }) => void;
    onChangeFileList?: (data: any) => void;
  } & UploadProps
>;

const CustomUpload = ({ onSuccessUpload, ...props }: Props) => {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any

  const [fileList, setfileList] = useState<UploadProps["fileList"]>([]);
  const [getSignedUrl] = useLazyGetSingedCustomUploadUrlQuery();

  const handleCustomCustomUpload = useCallback(
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    async ({ file, onSuccess, onProgress }: Record<string, any>) => {
      const fileName = file.name;
      const { data: resUrl } = await getSignedUrl({ fileName });
      onProgress({ percent: 10 });

      const signedUrl = resUrl?.url || "";
      await fetch(decodeURIComponent(signedUrl), {
        method: "PUT",
        body: file,
      });

      onProgress({ percent: 50 });

      onSuccessUpload?.({
        origin: getS3SheetUrl(fileName),
      });
      onSuccess(getS3SheetUrl(fileName));
    },
    [onSuccessUpload, getSignedUrl]
  );

  return (
    <>
      <Upload
        fileList={fileList}
        onRemove={() => {
          setfileList([]);
        }}
        beforeUpload={(file) => setfileList([file])}
        name="any"
        multiple={false}
        customRequest={handleCustomCustomUpload}
        accept=".xls, .xlsx, image/*, .xlm, application/pdf"
        {...props}
      />
    </>
  );
};

export default CustomUpload;

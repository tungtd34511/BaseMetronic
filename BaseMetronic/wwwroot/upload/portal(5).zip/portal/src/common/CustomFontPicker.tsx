import { Dropdown, Menu, Typography } from "antd";
import React, { PropsWithChildren } from "react";
import { fontFamilyConfigs } from "src/config/font.config";

const CustomFontPicker = ({
  onClick,
  onVisible,
  onFilter,
  ...props
}: PropsWithChildren<{
  onClick: (val: string) => void;
  onVisible?: (visible: boolean) => void;
  onFilter?: (font: string) => boolean;
}>) => {
  return (
    <Dropdown
      onVisibleChange={onVisible}
      overlay={
        <Menu
          style={{ maxHeight: "50vh", overflow: "auto" }}
          onClick={({ key, domEvent }) => {
            domEvent.stopPropagation();
            onClick(key);
          }}
          items={fontFamilyConfigs
            .filter(({ title }) => !onFilter || (onFilter && onFilter(title)))
            .map(({ title }) => ({
              key: title,
              label: (
                <Typography style={{ fontFamily: title }}>{title}</Typography>
              ),
            }))}
        />
      }
      placement="bottom"
      trigger={["click"]}
      {...props}
    />
  );
};

export default CustomFontPicker;

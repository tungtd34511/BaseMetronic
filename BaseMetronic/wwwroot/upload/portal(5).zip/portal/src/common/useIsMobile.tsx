import { useLayoutEffect, useState } from 'react';
export const MOBILE_MAX_SIZE = 768
const useIsMobile = (): boolean => {
    const [isMobile, setIsMobile] = useState(true);
    useLayoutEffect(() => {
        const updateSize = (): void => {
            setIsMobile(window.innerWidth < MOBILE_MAX_SIZE);
        };
        updateSize();
        window.addEventListener('resize', updateSize);

        return (): void => window.removeEventListener('resize', updateSize);
    }, []);

    return isMobile;
};

export default useIsMobile;

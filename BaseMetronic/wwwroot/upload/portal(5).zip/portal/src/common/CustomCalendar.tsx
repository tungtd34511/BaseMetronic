import { Calendar, Popover, PopoverProps, TimePicker } from "antd";
import moment from "moment";
import React, { PropsWithChildren } from "react";
import { convertToSeconds, convertToTimeStr } from "src/utils/time";
import { Box } from "./Box";

const format = "HH:mm";

const CustomCalendar = ({
  defaultValue,
  minDate,
  onChange,
  onChangeTime,
  time,
  timeZone,
  ...props
}: PropsWithChildren<
  {
    onChangeTime?: (_seconds: number) => void;
    time?: number;
    timeZone: number;
    defaultValue: moment.Moment;
    minDate?: Date;
    onChange: (timestamp: number) => void;
  } & PopoverProps
>) => {
  return (
    <Popover
      content={
        <Box
          style={{
            maxWidth: "100%",
            width: 400,
          }}
        >
          <Calendar
            fullscreen={false}
            onSelect={(data) => {
              onChange(data.utcOffset(timeZone).startOf("day").unix());
            }}
            disabledDate={(date) => {
              return (
                !!minDate &&
                date.utcOffset(timeZone).valueOf() <=
                  moment(minDate)
                    .utcOffset(timeZone)
                    .endOf("day")
                    .add(-1, "day")
                    .valueOf()
              );
            }}
            defaultValue={moment(defaultValue)}
          />
          {onChangeTime && time !== undefined && (
            <TimePicker
              onChange={(_, time: string) => {
                onChangeTime(convertToSeconds(time));
              }}
              defaultValue={moment(convertToTimeStr(time as number), format)}
              format={format}
              style={{ marginTop: 20 }}
            />
          )}
        </Box>
      }
      title="Date/time select"
      trigger="click"
      {...props}
    />
  );
};

export default CustomCalendar;

import { useRouter } from "next/router";
import { useCallback, useEffect } from "react";
import useRole from "./useRole";

const useAuth = ({
  adminRequired,
  disableAuth,
}: {
  adminRequired?: boolean;
  disableAuth?: boolean;
}) => {
  const router = useRouter();
  const { shop } = router.query;

  const { isAdmin, userData, isLoading } = useRole();

  const verifyUser = useCallback(() => {
    if (disableAuth) return;
    if (isLoading)
      // login

      return;
    const invalidAuth = !userData;
    if (invalidAuth) {
      router.push(`/login`);
    } else if (router.pathname == "/") {
      router.push("/analytic/report");
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isLoading, userData, shop, router.pathname]);

  useEffect(() => {
    verifyUser();
  }, [verifyUser]);

  useEffect(() => {
    if (userData) {
      if (adminRequired) {
        if (!isAdmin) {
          router.push("/analytic/report");
        }
      }
    }
  }, [userData, adminRequired, router, isAdmin]);

  return {
    userData,
  };
};

export default useAuth;

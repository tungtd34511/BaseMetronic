import { IUser } from "interfaces/user.interfaces";
import { useCallback } from "react";
import { useGetMyUserInfoQuery } from "store/APIs/user";

export enum EUserRole {
  AGENCY = "AGENCY",
  SUPER_AGENCY = "SUPER_AGENCY",
  ADMIN = "ADMIN",
  CS = "CS", // customer support
  ACCOUNTANT = "ACCOUNTANT",
}

export function checkRole(userRoles: EUserRole[] = [], role: EUserRole) {
  return userRoles?.includes(role);
}

const useRole = () => {
  const { data: userData, isLoading } = useGetMyUserInfoQuery();

  const checkUserRole = useCallback(
    (user: IUser) => ({
      userIsAdmin: checkRole(user?.roles, EUserRole.ADMIN),
      userIsCustomer: !!user,
      userIsAgency: checkRole(user?.roles, EUserRole.AGENCY),
      userIsCS: checkRole(user?.roles, EUserRole.CS),
      userIsAccountant: checkRole(user?.roles, EUserRole.ACCOUNTANT),
    }),
    []
  );

  return {
    isAdmin: checkRole(userData?.roles, EUserRole.ADMIN),
    isCustomer: !!userData,
    isAgency: checkRole(userData?.roles, EUserRole.AGENCY),
    isCS: checkRole(userData?.roles, EUserRole.CS),
    isAccountant: checkRole(userData?.roles, EUserRole.ACCOUNTANT),
    checkUserRole,
    userData,
    isLoading,
  };
};

export default useRole;

import { RefObject } from "react";
import { useAppSelector } from "store/hooks";

import useEventListener from "./useEventListener";

type Handler = (event: MouseEvent) => void;

function useOnClickOutside<T extends HTMLElement = HTMLElement>(
  ref: RefObject<T>,
  handler: Handler,
  mouseEvent: "mousedown" | "mouseup" = "mousedown"
): void {
  const disableClickOutside = useAppSelector(
    (state) => state.global.disableClickOutside
  );
  useEventListener(mouseEvent, (event) => {
    const el = ref?.current;

    // Do nothing if clicking ref's element or descendent elements
    if (!el || el.contains(event.target as Node)) {
      return;
    }
    if (!disableClickOutside) handler(event);
  });
}

export default useOnClickOutside;

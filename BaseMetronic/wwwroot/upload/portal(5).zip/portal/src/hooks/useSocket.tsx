import { useEffect, useRef, useState } from "react";
import { Manager, Socket } from "socket.io-client";

const manager = new Manager(`${process.env.WS_HOST}`, {
  reconnectionDelayMax: 10000,
  query: {},
  transports: ["websocket"],
});

type Props = {
  namespace: string;
  handleMessage: (message: any) => void;
};

const useSocket = (props: Props) => {
  const socketNamespace = useRef<Socket>();

  const [cọnnected, setcọnnected] = useState(false);
  const [clientId, setClientId] = useState<string | undefined>();

  useEffect(() => {
    socketNamespace.current = manager.socket(props.namespace);

    socketNamespace.current.io.on("open", () => {
      console.log("opened", props.namespace);
      setcọnnected(true);
    });

    socketNamespace.current.on("msgToClient", props.handleMessage);
    socketNamespace.current.on("message", (message) => {
      console.log("message", message);
      setClientId(message);
    });

    socketNamespace.current.io.on("error", (e) => {
      console.log("error", e);
    });

    // return () => {
    //   socketNamespace.current?.io?._close();
    // };
  }, [props.namespace, props.handleMessage]);

  return {
    clientId: cọnnected && clientId,
    cọnnected,
  };
};

export default useSocket;

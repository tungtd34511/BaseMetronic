export const fontFamilyConfigs: { title: string; url?: string }[] = [
  {
    title: "inherit",
  },
  {
    title: "Open Sans",
  },
  {
    title: "Roboto",
  },
  {
    title: "Lato",
  },
  {
    title: "Abhaya Libre",
  },
  {
    title: "Merriweather",
  },
  {
    title: "Alegreya",
  },
  {
    title: "Montserrat",
  },

  {
    title: "Aleo",
  },
  {
    title: "Muli",
  },
  {
    title: "Arapey",
  },

  {
    title: "Nunito",
  },
  {
    title: "Asap Condensed",
  },
  {
    title: "Assistant",
  },
  {
    title: "Barlow",
  },
  {
    title: "Oswald",
  },
  {
    title: "Bitter",
  },
  {
    title: "Poppins",
  },
  {
    title: "Brawler",
  },
  {
    title: "Caladea",
  },
  {
    title: "Rokkitt",
  },
];

export const primaryColor = "#18A0FB";

export const CLOUD_FRONT_HOST =
  process.env.CLOUD_FRONT_HOST || "https://df5tnwfq42mjn.cloudfront.net";
export const ACCESS_TOKEN_KEY = "accessToken";
export const DEFAULT_PAGE_SIZE = 15;
export const ONE_HOUR_IN_SECONDS = 60 * 60;
export const ONE_DAY_IN_SECONDS = 24 * ONE_HOUR_IN_SECONDS;

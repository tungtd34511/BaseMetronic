import {EUserRole} from "../hooks/useRole";

export function mapRolesToStrings(roles: EUserRole[] = []): string {
  const roleMapping: { [key: string]: string } = {
    [EUserRole.ADMIN]: "Quản trị viên",
    [EUserRole.AGENCY]: "Đại lý/ Cộng tác viên",
    [EUserRole.ACCOUNTANT]: "Kế toán",
    [EUserRole.CS]: "Chăm sóc khách hàng"
  };

  const translatedRoles: string[] = roles
  .filter(role => role in roleMapping)
  .map(role => roleMapping[role]);

  let response = translatedRoles.join(", ");

  return response ? ("Khách hàng, " + response)  : "Khách hàng";
}
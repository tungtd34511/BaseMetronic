import { uniqueId } from "lodash";
import { nowInSeconds } from "./date";

const prefix = nowInSeconds();

export const getUniqueId = () => uniqueId(String(prefix));

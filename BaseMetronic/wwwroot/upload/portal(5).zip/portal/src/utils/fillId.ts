/* eslint-disable @typescript-eslint/no-explicit-any */
export const genUniqueId = () => Math.random().toString(16).slice(2);

export const fillIdToArray = <T extends Record<any, any>>(arrObj: T[]): T[] => {
  return arrObj.map((item) => fillIdToObject(item));
};

export const fillIdToObject = <T extends Record<any, any>>(obj: T): T => {
  return {
    ...obj,
    id: genUniqueId(),
    ...(Array.isArray(obj.childs) && {
      childs: fillIdToArray(obj.childs),
    }),
  };
};

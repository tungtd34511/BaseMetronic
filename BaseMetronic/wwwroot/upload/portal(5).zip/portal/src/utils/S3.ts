import { CLOUD_FRONT_HOST } from "src/constants";

export const getS3ImageUrl = (fileName: string) =>
  `${CLOUD_FRONT_HOST}/upload/images/${fileName}`;

export const getS3SheetUrl = (fileName: string) =>
  `${CLOUD_FRONT_HOST}/upload/sheets/${fileName}`;

  export const getS3FileUrl = (fileName: string) =>
  `${CLOUD_FRONT_HOST}/upload/files/${fileName}`;

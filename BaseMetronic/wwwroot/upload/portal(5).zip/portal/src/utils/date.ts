import moment from "moment";
import { ONE_DAY_IN_SECONDS, ONE_HOUR_IN_SECONDS } from "src/constants";

export const nowInSeconds = () => ~~(Date.now() / 1000);

export const startOfDay = (date: number | Date | moment.Moment) =>
  moment(date).utcOffset(currentTimezone()).startOf("day").unix();

export const currentTimezone = () => new Date().getTimezoneOffset() / -60;

export const mixWithTimezoneSecond = (timestamp: number) =>
  timestamp - currentTimezone() * ONE_HOUR_IN_SECONDS;

export const getXDayRangeInSecondFromNow = (xDays = 1) => {
  const start = startOfDay(Date.now()) - +ONE_DAY_IN_SECONDS * (xDays - 1);
  const end = start + ONE_DAY_IN_SECONDS * xDays;

  const startXDayAgo = start - xDays * ONE_DAY_IN_SECONDS;
  const endXDayAgo = end - xDays * ONE_DAY_IN_SECONDS;

  return [
    {
      start,
      end,
    },
    { start: startXDayAgo, end: endXDayAgo },
  ];
};

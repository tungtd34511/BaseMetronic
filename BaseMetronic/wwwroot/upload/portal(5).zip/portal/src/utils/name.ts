import { EWithdrawTransactionStatus } from "enums/payment.enum";
import {EMotorCategoryValue} from "../../store/APIs/common";

export const WithdrawCommissionStatusNextStepName: {
  [key in EWithdrawTransactionStatus]: string;
} = {
  [EWithdrawTransactionStatus.PENDING]: "Chờ CS duyệt",
  [EWithdrawTransactionStatus.CS_ACCEPTED]: "Chờ kế toán thanh toán",
  [EWithdrawTransactionStatus.CS_REJECTED]: "Yêu cầu đã bị huỷ",
  [EWithdrawTransactionStatus.ACCOUNTANT_PAID]: "Đã thanh toán",
};


export const MotorInsuranceCategoryName: {
  [key in EMotorCategoryValue | any]: string;
} = {
  [EMotorCategoryValue.CC50Up]: "Trên 50CC",
  [EMotorCategoryValue.CC50Down]: "Dưới 50CC",
  [EMotorCategoryValue.Electric]: "Xe điện",
  [EMotorCategoryValue.Other]: "Xe 3 bánh/ Xe khác",
};

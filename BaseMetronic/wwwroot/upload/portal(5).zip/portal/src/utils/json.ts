/* eslint-disable @typescript-eslint/no-explicit-any */
import { isObject } from "lodash";

export interface IFilterType {
  searchTitle: string;
  searchTag: string;
  vendor: string;
  selectedVendor: string;
  variantIds?: string[];
  productIds?: string[];
  quantity: number;
}

export const handleParseValue = <T = any>(
  valueStr: string
): IFilterType | T => {
  const parseValue = JSON.parse(valueStr as any) as any;

  if (isObject(parseValue as IFilterType))
    return {
      quantity: 1,
      searchTag: "",
      searchTitle: "",
      vendor: "",
      selectedVendor: "",
      ...parseValue,
      variantIds: (parseValue.variantIds || []).map(Number),
      productIds: (parseValue.productIds || []).map(Number),
    };
  return parseValue;
};

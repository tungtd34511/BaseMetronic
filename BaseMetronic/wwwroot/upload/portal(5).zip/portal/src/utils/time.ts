export function convertToSeconds(timeStr: string) {
  const [hours, minutes] = timeStr.split(":");
  return Number(hours) * 60 * 60 + Number(minutes) * 60;
}

export function convertToTimeStr(seconds: number) {
  return new Date(seconds * 1000).toISOString().slice(11, 16);
}

import { omitBy, isNil } from "lodash";

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export const removeNullOrUndefined = (object: Record<string, any>) =>
  omitBy(object, isNil);

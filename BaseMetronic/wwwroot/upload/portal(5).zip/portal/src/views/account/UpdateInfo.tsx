import { PlusOutlined } from "@ant-design/icons";
import {
  Button,
  Checkbox,
  Col,
  DatePicker,
  Form,
  Input,
  message,
  Row,
  Select,
  Spin,
  Typography,
} from "antd";
import { IUserDetails } from "interfaces/user.interfaces";
import React, { useEffect, useState } from "react";
import { Box } from "src/common/Box";
import UploadImage from "src/common/Gallery/UploadImage";
import {
  useGetUserDetailsQuery,
  useUpdateDetailsMutation,
} from "store/APIs/user";
import moment from "moment";
import { CheckboxValueType } from "antd/lib/checkbox/Group";
import styled from "styled-components";

// default fileListItem
// {
//   uid: '-1',
//   name: 'image.png',
//   status: 'done',
//   url: 'https://zos.alipayobjects.com/rmsportal/jkjgkEfvpUPVyRjUImniVslZfWPnJuuZ.png',
// },

function genDefaultImageList(imageUrls: string[]) {
  return (imageUrls || []).map((imageUrl, index) => ({
    uid: String(index),
    name: imageUrl,
    status: "done" as any,
    url: imageUrl,
    response: imageUrl,
  }));
}

const UpdateInfo = () => {
  const [form] = Form.useForm();
  const [checkBox, setcheckBox] = useState<CheckboxValueType[]>([]);
  const { data, isLoading } = useGetUserDetailsQuery();

  const [
    updateDetailsMutation,
    { isLoading: isUpdateLoading, isError, isSuccess },
  ] = useUpdateDetailsMutation();

  useEffect(() => {
    if (isError) {
      message.error("Có lỗi xảy ra");
    }
    if (isSuccess) {
      message.success("Cập nhật thành công");
    }
  }, [isError, isSuccess]);

  useEffect(() => {
    if (data) {
      form.setFieldsValue({
        ...data,
        birthday: moment(data.birthday),
        dateOfIssue: moment(data.dateOfIssue),
        dueDate: moment(data.dueDate),
        IDCardImages: { fileList: genDefaultImageList(data.IDCardImages) },
        cardImages: { fileList: genDefaultImageList(data.cardImages) },
        signImage: { fileList: genDefaultImageList([data.signImage]) },
      });
    }
  }, [data]);

  const onFinish = () => {
    const formData = form.getFieldsValue();
    const data: IUserDetails = {
      ...formData,
      birthday: formData.birthday.toISOString(),
      dateOfIssue: formData.dateOfIssue.toISOString(),
      dueDate: formData.dueDate.toISOString(),
      IDCardImages: formData.IDCardImages.fileList.map(
        (item: any) => item.response
      ),
      cardImages: formData.cardImages.fileList.map(
        (item: any) => item.response
      ),
      signImage: formData.signImage.fileList[0]?.response,
      contractSented : false,
      isVertified : false
    };
    updateDetailsMutation(data);
  };

  const onGenderChange = (value: string) => {
    form.setFieldsValue({
      ...form.getFieldsValue(),
      gender: value,
    });
  };

  const onChange = (checkedValues: CheckboxValueType[]) => {
    setcheckBox(checkedValues);
  };
  if (isLoading || !data) return <Spin size="large" />;
  return (
    <Box style={{ width: "100%" }}>
      <Typography.Text
        style={{
          color: "#ff4d4f",
          fontSize: 12,
        }}
      >
        Các trường có dấu * là bắt buộc
      </Typography.Text>
      <Form
        form={form}
        name="basic"
        labelCol={{ span: 24 }}
        wrapperCol={{ span: 24 }}
        style={{ width: "100%" }}
        initialValues={{ remember: true }}
        onFinish={onFinish}
        // onFinishFailed={onFinishFailed}

        autoComplete="off"
      >
        <Box
          style={{
            background: "white",
            borderTop: "3px solid gray",
            padding: "12px 0",
          }}
        >
          <Typography.Title
            level={5}
            style={{
              paddingLeft: 10,
              borderBottom: "1px solid lightgray",
              paddingBottom: 10,
            }}
          >
            Thông tin thành viên
          </Typography.Title>

          <Row gutter={24} style={{ padding: 12 }}>
            <Col span={24} md={8}>
              <Form.Item
                style={{
                  width: "100%",
                }}
                label="Họ và tên"
                name="fullName"
                rules={[{ required: true, message: "Không được để trống" }]}
              >
                <Input defaultValue={data.fullName} />
              </Form.Item>
            </Col>
            <Col span={24} md={8}>
              <Form.Item
                style={{
                  width: "100%",
                }}
                label="Ngày sinh"
                name="birthday"
                rules={[{ required: true, message: "Không được để trống" }]}
              >
                <DatePicker
                  defaultValue={moment(data.birthday)}
                  style={{ width: "100%" }}
                  placeholder="dd/mm/yyyy"
                  disabledDate={(date) => {
                    return date.valueOf() > Date.now();
                  }}
                />
              </Form.Item>
            </Col>
            <Col span={24} md={8}>
              <Form.Item
                style={{
                  width: "100%",
                }}
                label="Giới tính"
                name="gender"
                rules={[{ required: true, message: "Không được để trống" }]}
              >
                <Select
                  placeholder="Chọn giới tính"
                  onChange={onGenderChange}
                  allowClear
                  defaultValue={data.gender}
                >
                  <Select.Option value="MALE">Nam</Select.Option>
                  <Select.Option value="FEMALE">Nữ</Select.Option>
                </Select>
              </Form.Item>
            </Col>
            <Col span={24} md={8}>
              <Form.Item
                style={{
                  width: "100%",
                }}
                label="Số điện thoại"
                name="phone"
                rules={[
                  { required: true, message: "Không được để trống" },
                  {
                    validator: async function (_rule, value) {
                      if (
                        value?.replace(/[^\d]/g, "")?.length !== value.length
                      ) {
                        return Promise.reject(
                          new Error("Số điện thoại không hợp lệ")
                        );
                      }
                    },
                  },
                ]}
              >
                <Input style={{ width: "100%" }} defaultValue={data.phone} />
              </Form.Item>
            </Col>
            <Col span={24} md={8}>
              <Form.Item
                style={{
                  width: "100%",
                }}
                label="Địa chỉ"
                name="address"
                rules={[{ required: true, message: "Không được để trống" }]}
              >
                <Input defaultValue={data.address} />
              </Form.Item>
            </Col>
            <Col span={24} md={8}>
              <Form.Item
                style={{
                  width: "100%",
                }}
                label="Số CMT/CCCD"
                name="IDCardNum"
                rules={[
                  { required: true, message: "Không được để trống" },
                  {
                    validator: async function (_rule, value) {
                      if (
                        ![9, 12].includes(
                          value?.replace(/[^\d]/g, "")?.length || 0
                        )
                      ) {
                        return Promise.reject(
                          new Error("Số CMT/CCCD không hợp lệ")
                        );
                      }
                    },
                  },
                ]}
              >
                <Input
                  style={{ width: "100%" }}
                  defaultValue={data.IDCardNum}
                />
              </Form.Item>
            </Col>
            <Col span={24} md={8}>
              <Form.Item
                style={{
                  width: "100%",
                }}
                label="Ngày cấp CMND/CCCD"
                name="dateOfIssue"
                rules={[{ required: true, message: "Không được để trống" }]}
              >
                <DatePicker
                  defaultValue={moment(data.dateOfIssue)}
                  disabledDate={(date) => {
                    return date.valueOf() > Date.now();
                  }}
                  style={{ width: "100%" }}
                  placeholder="dd/mm/yyyy"
                />
              </Form.Item>
            </Col>
            <Col span={24} md={8}>
              <Form.Item
                style={{
                  width: "100%",
                }}
                label="Nơi cấp CMND/CCCD"
                name="issuedBy"
                rules={[{ required: true, message: "Không được để trống" }]}
              >
                <Input defaultValue={data.issuedBy} />
              </Form.Item>
            </Col>
            <Col span={24} md={8}>
              <Form.Item
                style={{
                  width: "100%",
                }}
                label="Có giá trị đến"
                name="dueDate"
                rules={[{ required: true, message: "Không được để trống" }]}
              >
                <DatePicker
                  defaultValue={moment(data.dueDate)}
                  disabledDate={(date) => {
                    return date.valueOf() < Date.now();
                  }}
                  style={{ width: "100%" }}
                  placeholder="dd/mm/yyyy"
                />
              </Form.Item>
            </Col>
          </Row>
        </Box>

        <Box
          style={{
            background: "white",
            borderTop: "3px solid gray",
            padding: "12px 0",
            marginTop: 30,
          }}
        >
          <Typography.Title
            level={5}
            style={{
              paddingLeft: 10,
              borderBottom: "1px solid lightgray",
              paddingBottom: 10,
            }}
          >
            Thông tin thanh toán
          </Typography.Title>

          <Row gutter={24} style={{ padding: 12 }}>
            <Col span={24} md={8}>
              <Form.Item
                style={{
                  width: "100%",
                }}
                label="Số tài khoản"
                name="bankAccNum"
                rules={[
                  { required: true, message: "Không được để trống" },
                  {
                    validator: async function (_rule, value) {
                      if (
                        value?.replace(/[^\d]/g, "")?.length !== value.length
                      ) {
                        return Promise.reject(
                          new Error("Số tài khoản không hợp lệ")
                        );
                      }
                    },
                  },
                ]}
              >
                <Input
                  style={{ width: "100%" }}
                  defaultValue={data.bankAccNum}
                />
              </Form.Item>
            </Col>
            <Col span={24} md={8}>
              <Form.Item
                style={{
                  width: "100%",
                }}
                label="Chủ tài khoản (Họ và tên không dấu)"
                name="bankAccName"
                rules={[{ required: true, message: "Không được để trống" }]}
              >
                <Input defaultValue={data.bankAccName} />
              </Form.Item>
            </Col>
            <Col span={24} md={8}>
              <Form.Item
                style={{
                  width: "100%",
                }}
                label="Ngân hàng"
                name="bankName"
                rules={[{ required: true, message: "Không được để trống" }]}
              >
                <Input defaultValue={data.bankName} />
              </Form.Item>
            </Col>
            <Col span={24} md={8}>
              <Form.Item
                style={{
                  width: "100%",
                }}
                label="Mã số thuế"
                name="taxCode"
                rules={[
                  {
                    validator: async function (_rule, value) {
                      if (
                        value &&
                        value?.replace(/[^\d]/g, "")?.length !== value.length
                      ) {
                        return Promise.reject(
                          new Error("Mã số thuế không hợp lệ")
                        );
                      }
                    },
                  },
                ]}
              >
                <Input style={{ width: "100%" }} />
              </Form.Item>
            </Col>
          </Row>
        </Box>

        <Box
          style={{
            background: "white",
            borderTop: "3px solid gray",
            padding: "12px 0",
            marginTop: 30,
          }}
        >
          <Typography.Title
            level={5}
            style={{
              paddingLeft: 10,
              borderBottom: "1px solid lightgray",
              paddingBottom: 10,
            }}
          >
            Thông tin và thoả thuận của thành viên với Bảo Hểm Việt
          </Typography.Title>
          <Row gutter={24} style={{ padding: 12 }}>
            <Col span={24} md={8}>
              <Form.Item
                required
                label="Ảnh CMT/CCCD 2 mặt"
                name="IDCardImages"
                rules={[
                  { required: true, message: "Không được để trống" },
                  {
                    validator: async function (_rule, value) {
                      if (value?.fileList?.length < 2) {
                        return Promise.reject(
                          new Error("Phải có ít nhất 2 ảnh")
                        );
                      }
                    },
                  },
                ]}
              >
                <UploadImage
                  defaultFileList={genDefaultImageList(data.IDCardImages)}
                >
                  <div>
                    <PlusOutlined />
                    <div style={{ marginTop: 8 }}>Tải lên</div>
                  </div>
                </UploadImage>
              </Form.Item>
            </Col>
            <Col span={24} md={8}>
              <Form.Item
                required
                label="Ảnh thẻ 3x4"
                name="cardImages"
                rules={[{ required: true, message: "Không được để trống" }]}
              >
                <UploadImage
                  defaultFileList={genDefaultImageList(data.cardImages)}
                >
                  <div>
                    <PlusOutlined />
                    <div style={{ marginTop: 8 }}>Tải lên</div>
                  </div>
                </UploadImage>
              </Form.Item>
            </Col>
            <Col span={24} md={8}>
              <Form.Item
                required
                label="Chữ ký"
                name="signImage"
                rules={[{ required: true, message: "Không được để trống" }]}
              >
                <UploadImage
                  defaultFileList={genDefaultImageList([data.signImage])}
                  maxCount={1}
                >
                  <div>
                    <PlusOutlined />
                    <div style={{ marginTop: 8 }}>Tải lên</div>
                  </div>
                </UploadImage>
              </Form.Item>
            </Col>
          </Row>
          <Checkbox.Group onChange={onChange}>
            <StyledCheckbox style={{ marginLeft: 8 }} value="1">
              Tôi cam kết mọi thông tin là chính xác và hoàn toàn chịu trách
              nhiệm với thông tin mà tôi cung cấp
            </StyledCheckbox>
            <StyledCheckbox value="2">
              Tôi hiểu và đồng ý sử dụng giao dịch điện tử trên
              portal.baohiem.app
            </StyledCheckbox>
            <StyledCheckbox value="3">
              Tôi cam kết đã đọc, hiểu và thực hiện các văn bản theo Hợp đồng
              hợp tác tư vấn và phân phối sản phẩm bảo hiểm do Bảo Hiểm Việt ban
              hành.
            </StyledCheckbox>
          </Checkbox.Group>
        </Box>
        <Form.Item
          wrapperCol={{ offset: 8, span: 16 }}
          style={{ marginTop: 20 }}
        >
          <Button
            disabled={checkBox.length < 3}
            type="primary"
            htmlType="submit"
            loading={isUpdateLoading}
          >
            Xác nhận & gửi thông tin cho Bảo hiểm Việt
          </Button>
        </Form.Item>
      </Form>
    </Box>
  );
};

const StyledCheckbox = styled(Checkbox)`
  width: 100%;
`;

export default UpdateInfo;

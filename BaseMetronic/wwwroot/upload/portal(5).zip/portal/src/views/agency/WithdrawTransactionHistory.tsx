import { Spin, Table, Typography } from "antd";
import { ColumnsType } from "antd/lib/table";
import { EWithdrawTransactionStatus } from "enums/payment.enum";
import { IWithdrawTransaction } from "interfaces/payment.interface";
import React, { useState } from "react";
import moment from "moment";
import { useGetMyWithdrawCommissionRequestQuery } from "store/APIs/referrer";
import { DEFAULT_PAGE_SIZE } from "src/constants";
import useFormatter from "src/hooks/useFormatter";

const WithdrawTransactionHistory = () => {
  const [page, setPage] = useState(1);

  const [pageSize, setPageSize] = useState(DEFAULT_PAGE_SIZE);
  const { data, isLoading } = useGetMyWithdrawCommissionRequestQuery({
    page,
    limit: pageSize,
  });

  const { formatter } = useFormatter();

  const columns: ColumnsType<IWithdrawTransaction> = [
    {
      title: "Mã giao dịch",
      dataIndex: "id",
      key: "id",
      render: (text) => <Typography>{text}</Typography>,
    },

    {
      title: "Số tiền",
      dataIndex: "totalAmount",
      key: "totalAmount",
      render: (totalAmount) => (
        <Typography>{formatter.format(totalAmount)}</Typography>
      ),
    },
    {
      title: "Trạng thái",
      dataIndex: "status",
      key: "status",
      render: (status: EWithdrawTransactionStatus) => {
        switch (status) {
          case EWithdrawTransactionStatus.CS_REJECTED:
            return "Đã bị từ chối";
          case EWithdrawTransactionStatus.ACCOUNTANT_PAID:
            return "Đã thanh toán";

          default:
            return "Chờ duyệt";
        }
      },
    },
    {
      title: "Khởi tạo lúc",
      dataIndex: "createdAt",
      key: "createdAt",
      render: (createdAt: string) =>
        moment(createdAt).format("DD/MM/YYYY  HH:mm"),
    },
    {
      title: "Cập nhật lần cuối lúc",
      dataIndex: "updatedAt",
      key: "updatedAt",
      render: (updatedAt: string) =>
        moment(updatedAt).format("DD/MM/YYYY HH:mm"),
    },
    {
      title: "Dữ liệu gửi duyệt",
      dataIndex: "submitFileUrl",
      key: "submitFileUrl",
      render: (submitFileUrl) => (
        // eslint-disable-next-line react/jsx-no-target-blank
        <a target="_blank" href={submitFileUrl}>
          Tải xuống
        </a>
      ),
    },
  ];

  if (isLoading) return <Spin />;
  return (
    <Table
      loading={isLoading}
      columns={columns}
      dataSource={data?.docs}
      scroll={{ x: 300 }}
      style={{ width: "100%" }}
      pagination={{
        pageSizeOptions: [15, 30, 60],
        showSizeChanger: true,
        pageSize: pageSize,
        total: data?.totalDocs || 0,
        onChange(page, pageSize) {
          setPage(page);
          setPageSize(pageSize);
        },
      }}
    />
  );
};

export default WithdrawTransactionHistory;

import { Button, Image, Input, Popover, Space, Table, Typography } from "antd";
import { ColumnsType } from "antd/lib/table";
import { IUser } from "interfaces/user.interfaces";
import { debounce } from "lodash";
import { useRouter } from "next/router";
import React, { useCallback, useState } from "react";
import { FlexBox } from "src/common/FlexBox";
import { DEFAULT_PAGE_SIZE } from "src/constants";
import useRole from "src/hooks/useRole";
import { useGetUserListQuery } from "store/APIs/user";

const ListCustomer = () => {
  const { isAdmin, isAgency, checkUserRole } = useRole();
  const router = useRouter();
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState("");
  const [pageSize, setPageSize] = useState(DEFAULT_PAGE_SIZE);
  const { data, isLoading } = useGetUserListQuery({
    page,
    limit: pageSize,
    search,
  });

  const columns: ColumnsType<IUser> = [
    {
      title: "Mã định danh",
      dataIndex: "id",
      key: "id",
      width: 150,
      render: (text) => <Typography>{text}</Typography>,
    },

    {
      title: "Vai trò",
      dataIndex: "role",
      key: "role",
      render: (_role, record: IUser) => {
        const { userIsCustomer, userIsAgency } = checkUserRole(record);
        return (
          <Typography>
            {(userIsAgency && "Đại lý") || (userIsCustomer && "Người dùng")}
          </Typography>
        );
      },
    },

    {
      title: "Tên",
      dataIndex: "name",
      key: "name",
    },
    {
      title: "Ảnh đại diện",
      dataIndex: "avatar",
      key: "avatar",
      render: (avatar) => <Image src={avatar} alt="" width={100} />,
    },

    {
      title: "",
      key: "action",
      render: (_, record: IUser) => {
        const { userIsAgency } = checkUserRole(record);

        const actions: { lable: string; onClick: () => void }[] = [
          isAdmin &&
            !userIsAgency && {
              lable: "Chuyển thành cộng tác viên",
              onClick: () => {
                ///
              },
            },

          (isAdmin || isAgency) && {
            lable: "Lịch sử giao dịch",
            onClick: () => {
              ///
              router.push(`/admin/customer/${record.id}/history`);
            },
          },
          userIsAgency &&
            isAgency && {
              lable: "Xem lịch sử giới thiệu",
              onClick: () => {
                ///
                router.push(`/agency/${record.id}/referred`);
              },
            },
        ].filter(Boolean) as any;

        const content = () => (
          <div>
            {actions.map((item) => (
              <FlexBox
                key={item.lable}
                style={{
                  cursor: "pointer",
                  padding: "12px 8px",
                  borderBottom: "1px solid rgba(0,0,0,0.1)",
                }}
                onClick={item.onClick}
              >
                <Typography>{item.lable}</Typography>
              </FlexBox>
            ))}
          </div>
        );
        return (
          <Space size="middle">
            <Popover content={content} trigger="click">
              <Button>Hành động</Button>
            </Popover>
          </Space>
        );
      },
    },
  ];
  const handleSearch = useCallback(
    debounce((value) => {
      setSearch(value);
    }, 500),
    []
  );

  return (
    <div>
      <Input
        style={{
          margin: "20px 0",
          background: "white",
          borderRadius: 5,
          maxWidth: 300,
        }}
        onChange={(e) => handleSearch(e.target.value)}
        placeholder="Tìm kiếm"
      />
      <Table
        loading={isLoading}
        columns={columns}
        dataSource={data?.docs}
        scroll={{ x: 300 }}
        pagination={{
          pageSizeOptions: [15, 30, 60],
          showSizeChanger: true,
          pageSize: pageSize,
          total: data?.totalDocs || 0,
          onChange(page, pageSize) {
            setPage(page);
            setPageSize(pageSize);
          },
        }}
      />
    </div>
  );
};

export default ListCustomer;

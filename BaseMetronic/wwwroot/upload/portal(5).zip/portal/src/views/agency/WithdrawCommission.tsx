import {
  AccountBookFilled,
  HighlightFilled,
  ProfileFilled,
} from "@ant-design/icons";
import { Button, Modal, Spin, Tabs, Typography } from "antd";
import React, { useEffect, useState } from "react";
import { FlexBox } from "src/common/FlexBox";
import useFormatter from "src/hooks/useFormatter";
import {
  useCreateWithdrawCommissionRequestMutation,
  useGetCommissionQuery,
} from "store/APIs/referrer";
import Metric from "../analytic/Metric";
import WithdrawTransactionHistory from "./WithdrawTransactionHistory";

const WithdrawCommission = () => {
  const { formatter } = useFormatter();
  const { data, isLoading } = useGetCommissionQuery();

  const [
    createWithdrawCommissionRequestMutation,
    { isLoading: isCreateRequestLoading, data: createRequestData },
  ] = useCreateWithdrawCommissionRequestMutation();
  const [tab, settab] = useState("2");
  const [isModalOpen, setIsModalOpen] = useState(false);
  const handleOk = () => {
    createWithdrawCommissionRequestMutation();
  };

  const handleCancel = () => {
    setIsModalOpen(false);
  };

  const isDisableWithdraw =
    (data?.unpaidCommission?.accumulate?.amount || 0) < 200000;

  useEffect(() => {
    if (!isCreateRequestLoading) {
      if (createRequestData?.submitFileUrl) {
        window.open(createRequestData?.submitFileUrl, "_blank");
      }
      setIsModalOpen(false);
      settab("1");
    }
  }, [isCreateRequestLoading, createRequestData]);

  if (isLoading) return <Spin />;

  return (
    <Tabs centered style={{ height: "100%" }} activeKey={tab} onChange={settab}>
      <Tabs.TabPane tab="Tổng hợp" key="1">
        <FlexBox
          style={{
            alignItems: "center",
            flexDirection: "column",
            marginTop: 50,
          }}
        >
          <Typography
            style={{
              color: "red",
              fontSize: 14,
              fontWeight: 300,
              fontStyle: "italic",
            }}
          >
            Lưu ý: Hoa hồng tối thiểu cần có để thanh toán là: 200.000VNĐ
          </Typography>

          <Button
            type="primary"
            style={{ margin: "30px 0" }}
            disabled={isDisableWithdraw}
            onClick={() => setIsModalOpen(true)}
          >
            Rút tiền
          </Button>
          <Modal
            title="Xác nhận rút tiền"
            visible={isModalOpen}
            onOk={handleOk}
            onCancel={handleCancel}
            cancelText="Huỷ"
            okText="Xác nhận"
            okButtonProps={{
              loading: isCreateRequestLoading,
            }}
          >
            <Typography.Paragraph>
              Tạo yêu cầu rút{" "}
              <Typography.Text style={{ fontWeight: "bold" }}>
                {formatter.format(
                  data?.unpaidCommission.accumulate.amount || 0
                )}
              </Typography.Text>
            </Typography.Paragraph>

            <Typography
              style={{
                fontSize: 14,
                fontWeight: 300,
                fontStyle: "italic",
              }}
            >
              Lưu ý: Yêu cầu thanh toán sẽ được duyệt trong 5-10 ngày làm việc
            </Typography>
          </Modal>

          <Button style={{ marginBottom: 30 }} onClick={() => settab("1")}>
            Xem lịch sử yêu cầu rút tiền
          </Button>

          <Metric
            size={4}
            items={[
              {
                title: "Hoa hồng tạm tính (chưa thể rút)",
                value: formatter.format(
                  data?.preCalcCommission?.accumulate?.amount || 0
                ),
                icon: <ProfileFilled />,
              },

              {
                title: "Hoa hồng",
                value: formatter.format(
                  data?.unpaidCommission?.accumulate?.originalAmount || 0
                ),
                icon: <AccountBookFilled />,
              },

              {
                title: "Khấu trừ mã giảm giá",
                value: formatter.format(
                  -(data?.unpaidCommission?.accumulate?.discount || 0)
                ),
                icon: <ProfileFilled />,
              },

              {
                title: "Thuế",
                value: formatter.format(
                  -(data?.unpaidCommission?.accumulate?.tax || 0)
                ),
                icon: <AccountBookFilled />,
              },
            ]}
          />
          <Metric
            size={1}
            items={[
              {
                title: "Hoa hồng có thể rút",
                value: formatter.format(
                  data?.unpaidCommission?.accumulate?.amount || 0
                ),
                icon: <AccountBookFilled />,
              },
            ]}
          />
          <FlexBox style={{ paddingTop: 40, width: "100%" }}>
            <Metric
              size={2}
              items={[
                {
                  title: "Hoa hồng chờ duyệt thanh toán",
                  value: formatter.format(
                    data?.pendingCommission?.accumulate?.amount || 0
                  ),
                  icon: <ProfileFilled />,
                },

                {
                  title: "Hoa hồng đã thanh toán",
                  value: formatter.format(
                    data?.paidCommission?.accumulate?.amount || 0
                  ),
                  icon: <HighlightFilled />,
                },
              ]}
            />
          </FlexBox>
        </FlexBox>
      </Tabs.TabPane>
      <Tabs.TabPane tab="Lịch sử" key="2">
        <FlexBox
          style={{
            alignItems: "center",
            flexDirection: "column",
            marginTop: 50,
          }}
        >
          <WithdrawTransactionHistory />
        </FlexBox>
      </Tabs.TabPane>
    </Tabs>
  );
};

export default WithdrawCommission;

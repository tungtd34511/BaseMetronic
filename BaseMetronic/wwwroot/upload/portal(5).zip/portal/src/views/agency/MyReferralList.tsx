import {Divider, Table, Typography} from "antd";
import { ColumnsType } from "antd/lib/table";
import { IReferrerCommissionLog } from "interfaces/referrer.interface";
import React, { useState } from "react";
import { DEFAULT_PAGE_SIZE } from "src/constants";
import useFormatter from "src/hooks/useFormatter";
import useRole from "src/hooks/useRole";
import { useGetMyCommissionLogReportDetailsQuery } from "store/APIs/referrer";
import moment from "moment";
import Metric from "../analytic/Metric";
import { AccountBookFilled, ProfileFilled } from "@ant-design/icons";
import { EInsuranceFeature } from "enums/insurance.enum";
import { useGetInsuranceServicesQuery } from "store/APIs/insurance";
import { BLACK_LIST_USER } from "store/APIs/common";
import useIsMobile from "../../common/useIsMobile";

const MyReferralList = ({
  dateRange,
}: {
  dateRange: {
    from: number;
    to: number;
  };
}) => {
  const { isAgency } = useRole();
  const isMobile = useIsMobile();
  const { formatter, numberFormatter } = useFormatter();
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(DEFAULT_PAGE_SIZE);
  const { data, isLoading } = useGetMyCommissionLogReportDetailsQuery({
    page,
    limit: pageSize,
    ...dateRange,
  });
  const { data: insuranceServices } = useGetInsuranceServicesQuery();

  const columns: ColumnsType<IReferrerCommissionLog> = [
    {
      title: "Ngày",
      dataIndex: "createdAt",
      key: "createdAt",
      render: (createdAt: Date) => (
        <Typography>{moment(createdAt).format("DD/MM/YYYY HH:mm")}</Typography>
      ),
    },
    // {
    //   title: "Loại bảo hiểm",
    //   dataIndex: "feature",
    //   key: "feature",
    //   render: (feature: EInsuranceFeature) => {
    //     if (!insuranceServices?.features?.length) return;
    //     return insuranceServices.features.find(
    //       (item) => item.feature === feature
    //     )?.title;
    //   },
    // },
    {
      title: "Người mua",
      dataIndex: "userName",
      key: "userName",
      render: (text) => <Typography>{text}</Typography>,
    },

    {
      title: "Người dùng thanh toán",
      dataIndex: "revenue",
      key: "revenue",
      render: (revenue: number) => (
        <Typography>{formatter.format(revenue)}</Typography>
      ),
    },
    {
      title: "Doanh thu tính hoa hồng",
      dataIndex: "revenueCalcCommission",
      key: "revenueCalcCommission",
      render: (revenue: number, record: IReferrerCommissionLog) => (
        <Typography>{formatter.format(revenue)}</Typography>
      ),
    },

    {
      title: "Hoa hồng",
      dataIndex: "commission",
      key: "commission",
      render: (_c: number, record: IReferrerCommissionLog) => (
        <Typography>
          {formatter.format(record.directReferrer?.originalAmount as number)}

          <Typography.Text
            style={{
              color: "blue",
              paddingLeft: 10,
            }}
          >
            (
            {!record.indirectReferrer
              ? record.setting.commissionPercentDirectRefer
              : record.setting.commissionPercentIndirectRefer}
            %)
          </Typography.Text>
        </Typography>
      ),
    },

    {
      title: "Khấu trừ mã giảm giá",
      dataIndex: "discount",
      key: "discount",
      render: (_c: number, record: IReferrerCommissionLog) => (
        <Typography>
          {formatter.format(
            -((record.directReferrer?.discount as number) || 0)
          )}
        </Typography>
      ),
    },

    {
      title: "Thuế",
      dataIndex: "tax",
      key: "tax",
      render: (_c: number, record: IReferrerCommissionLog) => (
        <Typography>
          {formatter.format(-((record.directReferrer?.tax as number) || 0))}
        </Typography>
      ),
    },

    {
      title: "Nhận về",
      dataIndex: "commissionReceive",
      key: "commissionReceive",
      render: (_c: number, record: IReferrerCommissionLog) => (
        <Typography>
          {isAgency
            ? formatter.format(record.directReferrer?.amount as number)
            : formatter.format(record.indirectReferrer?.amount as number)}
        </Typography>
      ),
    },
  ];
  const { userData } = useRole();
  const hiddenItem = BLACK_LIST_USER.includes(userData?.id as string)

  return (
    <div>
      <div style={{ margin: "20px 0" }}>
        <Metric
          items={[
            {
              title: "Số bảo hiểm phát hành",
              value: numberFormatter.format(data?.totalDocs || 0),
              icon: <ProfileFilled />,
            },

            {
              title: "Doanh thu",
              value: formatter.format(
                data?.accumulate?.revenueCalcCommission || 0
              ),
              icon: <ProfileFilled />,
            },

            {
              title: "Hoa hồng",
              value: formatter.format(data?.accumulate?.originalAmount || 0),
              icon: <ProfileFilled />,
              hiddenItem
            },

            {
              title: "Khấu trừ mã giảm giá",
              value: formatter.format(-(data?.accumulate?.discount || 0)),
              icon: <ProfileFilled />,
              hiddenItem
            },

            {
              title: "Hoa hồng thực nhận",
              value: formatter.format(data?.accumulate?.amount || 0),
              icon: <AccountBookFilled />,
              hiddenItem
            },

            {
              title: "Số người chuyển đổi thành cộng tác viên",
              value: numberFormatter.format(
                data?.accumulate?.convert2AgentCount || 0
              ),
              icon: <ProfileFilled />,
              hiddenItem
            },
          ].filter((item) => !item.hiddenItem)}
        />
      </div>
      <div className='pd-24' style={{background: 'white',}}>
        <div className={`d-flex  ${isMobile ? 'flex-column' : 'align-item-center flex-row'}`}>
          <h3 className='flex-1'>Danh sách lịch sử giới thiệu</h3>
        </div>
        <Divider/>
        <Table
            loading={isLoading}
            columns={columns}
            dataSource={data?.docs}
            scroll={{ x: 300 }}
            pagination={{
              pageSizeOptions: [15, 30, 45],
              showSizeChanger: true,
              locale: { items_per_page: "/trang" },
              pageSize: pageSize,
              total: data?.totalDocs || 0,
              onChange(page, pageSize) {
                setPage(page);
                setPageSize(pageSize);
              },
            }}
        />
      </div>
    </div>
  );
};

export default MyReferralList;

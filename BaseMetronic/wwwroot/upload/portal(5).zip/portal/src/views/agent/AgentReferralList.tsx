import {Divider, Table, Typography} from "antd";
import { ColumnsType } from "antd/lib/table";
import {
  IReferrerCommissionLevelLog,
  IReferrerCommissionLog,
} from "interfaces/referrer.interface";
import React, { useState } from "react";
import { DEFAULT_PAGE_SIZE } from "src/constants";
import useFormatter from "src/hooks/useFormatter";
import {
  useGetAgentCommissionLogReportDetailsQuery
} from "store/APIs/referrer";
import moment from "moment";
import { useRouter } from "next/router";
import Metric from "../analytic/Metric";
import { AccountBookFilled, ProfileFilled } from "@ant-design/icons";
import { useGetInsuranceServicesQuery } from "store/APIs/insurance";
import useIsMobile from "../../common/useIsMobile";

const AgencyReferralList = ({
  dateRange,
  showReferrer,
}: {
  dateRange: {
    from: number;
    to: number;
  };
  showReferrer?: boolean;
}) => {
  const { query } = useRouter();
  const isMobile = useIsMobile();
  const { formatter, numberFormatter } = useFormatter();
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(DEFAULT_PAGE_SIZE);
  const { data, isLoading } = useGetAgentCommissionLogReportDetailsQuery({
    page,
    limit: pageSize,
    ...dateRange,
    ...(query.agentId && { agentId: String(query.agentId) }),
  });
  const { data: insuranceServices } = useGetInsuranceServicesQuery();

  const columns: ColumnsType<IReferrerCommissionLog> = [
    {
      title: "Ngày",
      dataIndex: "createdAt",
      key: "createdAt",
      render: (createdAt: Date) => (
        <Typography>{moment(createdAt).format("DD/MM/YYYY HH:mm")}</Typography>
      ),
    },
    // {
    //   title: "Loại bảo hiểm",
    //   dataIndex: "feature",
    //   key: "feature",
    //   render: (feature: EInsuranceFeature) => {
    //     if (!insuranceServices?.features?.length) return;
    //     return insuranceServices.features.find(
    //       (item) => item.feature === feature
    //     )?.title;
    //   },
    // },

    {
      title: "Người mua",
      dataIndex: "userName",
      key: "userName",
      render: (text) => <Typography>{text}</Typography>,
    },
    ...((showReferrer && [
      {
        title: "Người bán",
        dataIndex: "directReferrer",
        key: "directReferrer",
        render: (referrer: IReferrerCommissionLevelLog) => (
          <Typography>{referrer.referrerName}</Typography>
        ),
      },
    ]) ||
      []),

    {
      title: "Người dùng thanh toán",
      dataIndex: "revenue",
      key: "revenue",
      render: (revenue: number) => (
        <Typography>{formatter.format(revenue)}</Typography>
      ),
    },
    {
      title: "Doanh thu tính hoa hồng",
      dataIndex: "revenueCalcCommission",
      key: "revenueCalcCommission",
      render: (revenue: number, record: IReferrerCommissionLog) => (
        <Typography>{formatter.format(revenue)}</Typography>
      ),
    },

    {
      title: "Hoa hồng",
      dataIndex: "commission",
      key: "commission",
      render: (_c: number, record: IReferrerCommissionLog) => (
        <Typography>
          {formatter.format(record.indirectReferrer?.originalAmount || 0)}

          <Typography.Text
            style={{
              color: "blue",
              paddingLeft: 10,
            }}
          >
            ({record.setting.commissionPercentIndirectRefer}
            %)
          </Typography.Text>
        </Typography>
      ),
    },

    {
      title: "Thuế",
      dataIndex: "tax",
      key: "tax",
      render: (_c: number, record: IReferrerCommissionLog) => (
        <Typography>
          {formatter.format(-((record.indirectReferrer?.tax as number) || 0))}
        </Typography>
      ),
    },

    {
      title: "Nhận về",
      dataIndex: "commissionReceive",
      key: "commissionReceive",
      render: (_c: number, record: IReferrerCommissionLog) => (
        <Typography>
          {formatter.format(record.indirectReferrer?.amount || 0)}
        </Typography>
      ),
    },
  ];

  return (
      <div>
        <div
            style={{
              padding: "20px 0",
            }}
        >
          <Metric
              size={3}
              items={[
                {
                  title: "Số bảo hiểm phát hành",
                  value: numberFormatter.format(data?.totalDocs || 0),
                  icon: <ProfileFilled/>,
                },

                {
                  title: "Doanh thu",
                  value: formatter.format(
                      data?.accumulate?.revenueCalcCommission || 0
                  ),
                  icon: <ProfileFilled/>,
                },

                {
                  title: "Hoa hồng thực nhận",
                  value: formatter.format(data?.accumulate?.amount || 0),
                  icon: <AccountBookFilled/>,
                },
              ]}
          />
        </div>
        <div className='pd-24' style={{background: 'white',}}>
          <div className={`d-flex  ${isMobile ? 'flex-column' : 'align-item-center flex-row'}`}>
            <h3 className='flex-1'>Danh sách lịch sử giới thiệu</h3>
          </div>
          <Divider/>
          <Table
              loading={isLoading}
              columns={columns}
              dataSource={data?.docs}
              scroll={{x: 300}}
              pagination={{
                pageSizeOptions: [15, 30, 60],
                showSizeChanger: true,
                locale: {items_per_page: "/trang"},
                pageSize: pageSize,
                total: data?.totalDocs || 0,
                onChange(page, pageSize) {
                  setPage(page);
                  setPageSize(pageSize);
                },
              }}
          />
        </div>
      </div>
  );
};

export default AgencyReferralList;

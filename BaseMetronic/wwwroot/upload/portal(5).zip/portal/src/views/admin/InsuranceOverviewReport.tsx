import { Spin } from "antd";
import { ReportResponse } from "interfaces/global.interface";
import {
  IInsuranceReport,
  IReferrerAccessLogReport,
} from "interfaces/referrer.interface";
import React from "react";
import {
  Legend,
  LineChart,
  ResponsiveContainer,
  XAxis,
  YAxis,
  Tooltip,
  Line,
  Bar,
  BarChart,
} from "recharts";
import { Box } from "src/common/Box";
import useFormatter from "src/hooks/useFormatter";

type Props = {
  data?: ReportResponse<IInsuranceReport>;
  isLoading: boolean;
};

const InsuranceOverviewReport = ({ data, isLoading }: Props) => {
  const { formatter } = useFormatter();
  if (isLoading) return <Spin size="large" />;
  return (
    <>
      <Box
        style={{
          height: 400,
          width: "100%",
          margin: "30px 0",
          background: "white",
          borderRadius: 10,
        }}
      >
        <ResponsiveContainer width="100%" height="100%">
          <LineChart
            data={data?.docs}
            margin={{
              top: 30,
              right: 30,
              left: 30,
              bottom: 10,
            }}
          >
            <XAxis dataKey="date" />
            <YAxis />
            <Tooltip
              formatter={(value: number, field: string, props: any) => {
                const fieldName: { [key: string]: string } = {
                  finishedCount: "Số bảo hiểm phát hành (đã thanh toán)",
                  hasReferrerCount: "Lượt tạo bảo hiểm có người giới thiệu",
                };
                return [value, fieldName[field], props];
              }}
            />
            <Legend
              formatter={(field: string) => {
                const fieldName: { [key: string]: string } = {
                  paidCount: "Lượt tạo bảo hiểm (đã + chưa thanh toán)",
                  finishedCount: "Số bảo hiểm phát hành (đã thanh toán)",
                  hasReferrerCount: "Lượt tạo bảo hiểm qua người giới thiệu",
                };
                return fieldName[field];
              }}
            />
            <Line type="monotone" dataKey="finishedCount" stroke="#b21616" />
            <Line
              type="monotone"
              dataKey="hasReferrerCount"
              stroke="rgb(0 168 0)"
            />
          </LineChart>
        </ResponsiveContainer>
      </Box>
      <Box
        style={{
          height: 400,
          width: "100%",
          margin: "30px 0",
          background: "white",
          borderRadius: 10,
        }}
      >
        <ResponsiveContainer width="100%" height="100%">
          <BarChart
            data={data?.docs}
            margin={{
              top: 30,
              right: 30,
              left: 30,
              bottom: 10,
            }}
          >
            <XAxis dataKey="date" />
            <YAxis />
            <Tooltip
              formatter={(value: number, field: string, props: any) => {
                const fieldName: { [key: string]: string } = {
                  revenue: "Doanh thu (đã trừ voucher)",
                  discount: "Giá trị Voucher đã dùng",
                };
                return [formatter.format(value), fieldName[field], props];
              }}
            />
            <Legend
              formatter={(field: string) => {
                const fieldName: { [key: string]: string } = {
                  revenue: "Doanh thu (đã trừ voucher)",
                  discount: "Giá trị Voucher đã dùng",
                };
                return fieldName[field];
              }}
            />
            <Bar dataKey="revenue" fill="#cf1322" />

            <Bar dataKey="discount" fill="#0b7dd4" />
          </BarChart>
        </ResponsiveContainer>
      </Box>
    </>
  );
};

export default InsuranceOverviewReport;

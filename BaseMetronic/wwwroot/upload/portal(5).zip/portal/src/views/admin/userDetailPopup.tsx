import React from "react";
import { Modal, Descriptions, Button , Image} from "antd";
import { IUser, IUserDetails } from "interfaces/user.interfaces";
import moment from "moment";

interface UserDetailPopupProps {
  visible: boolean;
  record: {
    user : IUser,
    userDetails : IUserDetails
  };
  onClose: () => void;
}

const UserDetailPopup: React.FC<UserDetailPopupProps> = ({ visible, record, onClose }) => {
    const detail =record?.userDetails
  return (
    <Modal
      visible={visible}
      title="User File Details"
      onCancel={onClose}
      footer={[
        // <Button key="close" onClick={onClose}>
        //   Đóng
        // </Button>
      ]}
    >
        {detail && 
            <Descriptions column={1}>
            <Descriptions.Item label="Họ Tên">{detail.fullName}</Descriptions.Item>
            <Descriptions.Item label="Ngày Sinh">{moment(detail.birthday).format('DD/MM/YYYY') }</Descriptions.Item>
            <Descriptions.Item label="Giới Tính">{detail.gender}</Descriptions.Item>
            <Descriptions.Item label="Số Điện Thoại">{detail.phone}</Descriptions.Item>
            <Descriptions.Item label="Địa">{detail.address}</Descriptions.Item>
            <Descriptions.Item label="Số CMT/CCCD">{detail.IDCardNum}</Descriptions.Item>
            <Descriptions.Item label="Ngày cấp CMND/CCCD">{moment(detail.dateOfIssue).format('DD/MM/YYYY')}</Descriptions.Item>
            <Descriptions.Item label="Nơi cấp CMND/CCCD">{detail.issuedBy}</Descriptions.Item>
            <Descriptions.Item label="Có giá trị đến">{moment(detail.dueDate).format('DD/MM/YYYY')}</Descriptions.Item>
            <Descriptions.Item label="Số tài khoản">{detail.bankAccNum}</Descriptions.Item>
            <Descriptions.Item label="Chủ tài khoản (Họ và tên không dấu)">{detail.bankAccName}</Descriptions.Item>
            <Descriptions.Item label="Ngân hàng">{detail.bankName}</Descriptions.Item>
            {detail.taxCode && <Descriptions.Item label="Mã số thuế">{detail.taxCode}</Descriptions.Item>}
            <Descriptions.Item label="Ảnh CMT/CCCD 2 mặt">
            {detail.IDCardImages.map(imageUrl => (
                <Image key={imageUrl} src={imageUrl} alt="ID Card" style={{ maxWidth: '100px', maxHeight: '100px' }} />
            ))
            }
            </Descriptions.Item>
            <Descriptions.Item label="Ảnh thẻ 3x4">
            {detail.cardImages.map(imageUrl => (
                <Image key={imageUrl} src={imageUrl} alt="Card" style={{ maxWidth: '100px', maxHeight: '100px' }} />
            ))}
            </Descriptions.Item>
            <Descriptions.Item label="Chữ ký">
            <Image src={detail.signImage} alt="Sign" style={{ maxWidth: '100px', maxHeight: '100px' }} />
            </Descriptions.Item>
            <Descriptions.Item label="Duyệt hồ sơ">{detail.isVertified ? 'Đã xác nhận' : 'Chưa xác nhận'}</Descriptions.Item>
            <Descriptions.Item label="Gửi hợp đồng">{detail.contractSented ? 'Đã gửi hợp đồng' : 'Chưa gửi hợp đồng'}</Descriptions.Item>
        </Descriptions>
        } 

    </Modal>
  );
};
export default UserDetailPopup;

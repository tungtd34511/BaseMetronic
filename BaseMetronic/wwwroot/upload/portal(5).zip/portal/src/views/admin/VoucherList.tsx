import {Divider, Table, Typography} from "antd";
import { ColumnsType } from "antd/lib/table";
import React, { useState } from "react";
import { DEFAULT_PAGE_SIZE } from "src/constants";
import {
  EVoucherStatus,
  useAdminGetListVoucherQuery,
} from "store/APIs/referrer";
import moment from "moment";
import { IVoucher } from "interfaces/referrer.interface";
import useFormatter from "src/hooks/useFormatter";
import useIsMobile from "../../common/useIsMobile";

const VoucherList = () => {
  const isMobile = useIsMobile();
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(DEFAULT_PAGE_SIZE);
  const { data, isLoading } = useAdminGetListVoucherQuery({
    page,
    limit: pageSize,
    status: EVoucherStatus.APPROVED,
  });

  const { formatter } = useFormatter();

  const columns: ColumnsType<IVoucher> = [
    {
      title: "Người tạo",
      dataIndex: "agencyName",
      key: "agencyName",
      render: (agencyName) => <Typography>{agencyName}</Typography>,
    },
    {
      title: "Mã",
      dataIndex: "code",
      key: "code",
      render: (code) => <Typography>{code}</Typography>,
    },

    {
      title: "Số tiền",
      dataIndex: "value",
      key: "value",
      render: (value: number) => formatter.format(value),
    },

    {
      title: "Số lượng",
      dataIndex: "qty",
      key: "qty",
      render: (qty) => <Typography>{qty}</Typography>,
    },

    {
      title: "Đã dùng",
      dataIndex: "remainingQty",
      key: "remaingQty",
      render: (remaingQty, record: IVoucher) => (
        <Typography>{record.qty - remaingQty}</Typography>
      ),
    },
    {
      title: "Mô tả",
      dataIndex: "description",
      key: "description",
      width: 300,
    },
    {
      title: "Ngày bắt đầu",
      dataIndex: "startDate",
      key: "startDate",
      render: (startDate) => (
        <Typography>{moment(startDate).format("DD/MM/YYYY")}</Typography>
      ),
    },

    {
      title: "Ngày kết thúc",
      dataIndex: "endDate",
      key: "endDate",
      render: (endDate) => (
        <Typography>{moment(endDate).format("DD/MM/YYYY")}</Typography>
      ),
    },
    {
      title: "Trạng thái",
      dataIndex: "status",
      key: "status",
      render: (status) => <Typography>{status}</Typography>,
    },
  ];

  return (
    <div>
      <div className='pd-24' style={{background: 'white',}}>
        <div className={`d-flex  ${isMobile ? 'flex-column' : 'align-item-center flex-row'}`}>
          <h3 className='flex-1'>Danh sách mã khuyến mãi đã duyệt</h3>
        </div>
        <Divider/>
        <Table
            loading={isLoading}
            columns={columns as any}
            dataSource={data?.docs}
            scroll={{ x: 300 }}
            pagination={{
              pageSizeOptions: [15, 30, 60],
              showSizeChanger: true,
              pageSize: pageSize,
              total: data?.totalDocs || 0,
              onChange(page, pageSize) {
                setPage(page);
                setPageSize(pageSize);
              },
            }}
        />
      </div>
    </div>
  );
};

export default VoucherList;

import { Table, Typography } from "antd";
import { ColumnsType } from "antd/lib/table";
import { IUser } from "interfaces/user.interfaces";
import { useRouter } from "next/router";
import React, { useState } from "react";
import { DEFAULT_PAGE_SIZE } from "src/constants";
import useFormatter from "src/hooks/useFormatter";
import { useGetTransactionHistoryQuery } from "store/APIs/insurance";

const TransactionHistory = () => {
  const { formatter } = useFormatter();
  const router = useRouter();
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(DEFAULT_PAGE_SIZE);
  const { data, isLoading } = useGetTransactionHistoryQuery({
    page,
    limit: pageSize,
    userId: router.query.customerId as any,
  });

  const columns: ColumnsType<IUser> = [
    {
      title: "Id bảo hiểm",
      dataIndex: "id",
      key: "id",
      width: 150,
      render: (text) => <Typography>{text}</Typography>,
    },

    {
      title: "Nguồn",
      dataIndex: "source",
      key: "source",
    },

    {
      title: "Loại bảo hiểm",
      dataIndex: "feature",
      key: "feature",
    },
    {
      title: "Giá",
      dataIndex: "fee",
      key: "fee",
      render: (fee) => <Typography>{formatter.format(fee)}</Typography>,
    },

    {
      title: "Trạng thái",
      dataIndex: "status",
      key: "status",
      render: (_: string, record: any) => (
        <Typography>
          {record.createBody
            ? (record.createBody &&
                record.createResponse.success &&
                !record.callbackResponse &&
                "Đang xử lý") ||
              (record.createBody &&
                !record.createResponse.success &&
                "Có lỗi xảy ra (đã thanh toán)") ||
              "Đã thanh toán"
            : "Chưa thanh toán"}
        </Typography>
      ),
    },
  ];

  return (
    <div>
      <Table
        loading={isLoading}
        columns={columns}
        dataSource={data?.docs}
        scroll={{ x: 300 }}
        pagination={{
          pageSizeOptions: [15, 30, 60],
          showSizeChanger: true,
          pageSize: pageSize,
          total: data?.totalDocs || 0,
          onChange(page, pageSize) {
            setPage(page);
            setPageSize(pageSize);
          },
        }}
      />
    </div>
  );
};

export default TransactionHistory;

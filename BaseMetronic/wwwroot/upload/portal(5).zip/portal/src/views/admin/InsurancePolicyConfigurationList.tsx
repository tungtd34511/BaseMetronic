import { Button, Col, Divider, Form, Modal, Row, Spin } from "antd";
import { ColumnsType } from "antd/lib/table";
import React, { useEffect, useState } from "react";
import {
    useCreateDataMutation,
    useDeleteDataMutation,
    useLazyGetDataQuery,
    useUpdateDataMutation,
} from "store/APIs/configuration";
import { ICreateInsurancePolicy } from "interfaces/referrer.interface";
import useIsMobile from "../../common/useIsMobile";
import { DeleteOutlined, EditOutlined } from "@ant-design/icons";
import CustomTable from "src/common/CustomTable";
import CustomModal from "src/common/CustomModal";
import moment from "moment";
import { ConvertNameFeature, TITLE_NOTIFICATION } from "store/APIs/common";
import CustomInput from "src/common/CustomInput";
import { ARR_INSURANCE_FEATURE } from "enums/insurance.enum";
import { NOT_EMPTY, PRESS, TYPE_ARR_INPUT } from "store/APIs/const";
import { validateMaxLength } from "src/common/Validate";
import CustomSelect from "src/common/CustomSelect";
import CustomInputNumber from "src/common/CustomInputPrice";
const InsurancePolicyConfigurationList = () => {
    const isMobile = useIsMobile();
    const [lazyGetListData, { data, isLoading }] = useLazyGetDataQuery();
    const [createInsurancePolicy, { data: voucherResponse, isSuccess,isLoading: isCreateLoading,isError, }] = useCreateDataMutation();
    const [updateData, {isLoading: isUpdateLoading,isSuccess:isSuccessUpdate}] = useUpdateDataMutation();
    const [deleteVoucherMutationV2, { isLoading: isDeleteLoading }] = useDeleteDataMutation();
    const [formInsert] = Form.useForm();
    const statusFormInsert = formInsert?.getFieldValue('status')
    const [isModalOpen, setIsModalOpen] = useState(false)
    const columns: ColumnsType<ICreateInsurancePolicy> = [
        {
            title: "Loại bảo hiểm",
            render: (row: ICreateInsurancePolicy) => ConvertNameFeature(row?.feature) || '',
        },
        {
            title: "% Hoa hồng trực tiếp",
            render: (row: ICreateInsurancePolicy) => row?.commissionPercentDirectRefer || '',
        },
        {
            title: "% Hoa hồng gián tiếp",
            render: (row: ICreateInsurancePolicy) => row?.commissionPercentIndirectRefer || '',
        },
        {
            title: "% Thuế",
            render: (row: ICreateInsurancePolicy) => row?.basePriceTax || '',
        },
        {
            title: "% Hoa hồng thuế",
            render: (row: ICreateInsurancePolicy) => row?.commissionTax || '',
        },
        {
            title: "Ngày tạo",
            render: (row: ICreateInsurancePolicy) => row?.createdAt && moment(row?.createdAt).format('DD-MM-YYYY'),
        },
        {
            title: 'Thao tác',
            render: (row: ICreateInsurancePolicy) => <div>
                {
                    <EditOutlined onClick={() => {
                        formInsert.setFieldsValue({
                            'status': 'UPDATE'
                        })
                        formInsert.setFieldsValue({
                            'id': row?.id
                        })
                        formInsert.setFieldsValue({
                            'basePriceTax': row?.basePriceTax
                        })
                        formInsert.setFieldsValue({
                            'commissionPercentDirectRefer': row?.commissionPercentDirectRefer
                        })
                        formInsert.setFieldsValue({
                            'commissionPercentIndirectRefer': row?.commissionPercentIndirectRefer
                        })
                        formInsert.setFieldsValue({
                            'commissionTax': row?.commissionTax
                        })
                        formInsert.setFieldsValue({
                            'feature': row?.feature
                        })
                        setIsModalOpen(true)
                    }} className='cursor-pointer' style={{ fontSize: '20px' }} />
                }
                {
                    <DeleteOutlined onClick={() => {
                        showConfirm(row)
                    }} className='ml-12 cursor-pointer' style={{ fontSize: '20px' }} />
                }

            </div>,
        },
    ];
    const handleSubmit = (values: ICreateInsurancePolicy) => {
        if (formInsert?.getFieldValue('id')) {
            updateData({
                ...values,
                id: formInsert?.getFieldValue('id')
            })
        } else {
            createInsurancePolicy(values)
        }
    }
    const showConfirm = (row: ICreateInsurancePolicy) => {
        Modal.confirm({
            okButtonProps: {
                className: 'ant-btn ant-btn-danger'
            },
            title: TITLE_NOTIFICATION,
            content: 'Xác nhận xóa loại bảo hiểm này?',
            onOk: async () => {
                await deleteVoucherMutationV2({ id: row.id });
                lazyGetListData({})
            },
            onCancel() {
                console.log('Hủy bỏ');
            },
            cancelText: 'Hủy',
            okText: 'Xác nhận',
            closable: true
        });
    };
    const ARR_SELECT = [
        {
            id: 'feature',
            label: 'Tên loại bảo hiểm',
            options: ARR_INSURANCE_FEATURE,
            rules: [{ required: true, message: NOT_EMPTY }],
        },
    ]
    const ARR_INPUT_TYPE_INSURNCE = [
        {
            id: 'commissionPercentDirectRefer',
            label: '% Hoa hồng trực tiếp',
            type: TYPE_ARR_INPUT.INPUT_PRICE,
            placeholder: `${PRESS} % hoa hồng trực tiếp`,
            rules: [
                {
                    required: true,
                    message: `${NOT_EMPTY}`
                },
                {
                    pattern: validateMaxLength(4).regexPattern,
                    message: validateMaxLength(4).message
                },
            ]
        },
        {
            id: 'commissionPercentIndirectRefer',
            label: '% Hoa hồng gián tiếp',
            type: TYPE_ARR_INPUT.INPUT_PRICE,
            placeholder: `${PRESS}`,
            rules: [
                {
                    required: true,
                    message: `${NOT_EMPTY}`
                },
                {
                    pattern: validateMaxLength(4).regexPattern,
                    message: validateMaxLength(4).message
                },
            ]
        },
        {
            id: 'basePriceTax',
            label: '% Thuế',
            type: TYPE_ARR_INPUT.INPUT_PRICE,
            placeholder: `${PRESS} % Thuế`,
            rules: [
                {
                    required: true,
                    message: `${NOT_EMPTY}`
                },
                {
                    pattern: validateMaxLength(4).regexPattern,
                    message: validateMaxLength(4).message
                },
            ]
        },
        {
            id: 'commissionTax',
            label: '% Hoa hồng thuế',
            type: TYPE_ARR_INPUT.INPUT_PRICE,
            placeholder: `${PRESS} % Hoa hồng thuế`,
            rules: [
                {
                    required: true,
                    message: `${NOT_EMPTY}`
                },
                {
                    pattern: validateMaxLength(4).regexPattern,
                    message: validateMaxLength(4).message
                },
            ]
        },
    ]
    useEffect(() => {
        if (isSuccess || isSuccessUpdate) {
            setIsModalOpen(false)
            formInsert.resetFields()
            lazyGetListData({})
        }
    }, [isSuccess, isSuccessUpdate])
    useEffect(() => {
        lazyGetListData({})
    }, [])
    return (
        <div>
            {
                (isLoading||isCreateLoading || isUpdateLoading || isDeleteLoading) && <Spin
                    style={{ position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%,-50%)' }}
                    size="large" />
            }
            <Form
                onFinish={handleSubmit}
                form={formInsert}
            >
                <CustomModal
                    title={statusFormInsert === 'UPDATE' ? 'Cập nhật loại bảo hiểm' : 'Tạo mới loại bảo hiểm'}
                    handleCancel={() => {
                        formInsert.resetFields()
                        setIsModalOpen(false)
                    }}
                    handleOk={formInsert.submit}
                    isModalOpen={isModalOpen}
                    setIsModalOpen={setIsModalOpen}
                >
                    <Row gutter={[12, 12]}>
                        {
                            ARR_SELECT.map((itemMap, key) => {
                                return <Col key={itemMap.id + key} xs={12} xl={12}>
                                    <Form.Item
                                        name={itemMap.id}
                                        rules={itemMap.rules}
                                        label={itemMap.label}
                                    >
                                        <CustomSelect
                                            formInsert={formInsert}
                                            id={itemMap.id}
                                            onChange={(e) => {
                                            }}
                                            options={itemMap.options}
                                        />
                                    </Form.Item>
                                </Col>
                            })
                        }
                        {
                            ARR_INPUT_TYPE_INSURNCE.map((itemMap, key) => <Col key={itemMap.id + key} xs={12} xl={12}>
                                {
                                    itemMap.type === TYPE_ARR_INPUT.INPUT && <Form.Item
                                        name={itemMap.id}
                                        rules={itemMap.rules || []}
                                        label={<span>{itemMap.label}</span>}>

                                        <CustomInput
                                            placeholder={itemMap.placeholder}
                                            id={itemMap.id}
                                        />
                                    </Form.Item>
                                }
                                {
                                    itemMap.type === TYPE_ARR_INPUT.INPUT_PRICE &&
                                    <CustomInputNumber
                                        itemMap={itemMap}
                                    />
                                }
                            </Col>)
                        }
                    </Row>
                </CustomModal>
            </Form>
            <div className='pd-24' style={{ background: 'white', }}>
                <div className={`d-flex  ${isMobile ? 'flex-column' : 'align-item-center flex-row'}`}>
                    <h3 className='flex-1'>Danh sách cấu hình hoa hồng</h3>
                    {/* <Button className={`${!isMobile ? 'ml-12' : 'mgbt-12'} `} type="primary" danger>Xóa</Button> */}
                    <Button
                        onClick={() => {
                            setIsModalOpen(true)
                        }}
                        className={`${!isMobile ? 'ml-12' : 'mgbt-12'}`}
                        type="primary">
                        Tạo mới
                    </Button>
                </div>
                <Divider />
                <CustomTable
                    columns={columns}
                    totalDocs={data?.length || 0}
                    data={data || []}
                    isLoading={isLoading}
                    onChange={(page, limit) => {
                        window.scrollTo(0, 0);
                    }}
                    pageSize={15}
                    pageCurrent={1}
                    pagination={false}
                />
            </div>
        </div>
    );
};

export default InsurancePolicyConfigurationList;

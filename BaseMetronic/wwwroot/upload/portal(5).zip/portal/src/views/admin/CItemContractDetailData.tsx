import { Card, Col, Descriptions, Empty, Row } from 'antd';
import { EInsuranceFeature } from 'enums/insurance.enum';
import React, { useEffect, useState } from 'react';
import useIsMobile from 'src/common/useIsMobile';
import { MotorInsuranceCategoryName } from 'src/utils/name';
import { ECategory } from 'store/APIs/common';
import { IContractAdminOnline, useLazyGetUserIntentByPartnerIdQuery } from 'store/APIs/contract';
interface ICItemContractDetailData {
  contractDetailData: IContractAdminOnline | undefined
}
const renderNameInsurance = (nameInsurance: string) => {
  let tmp = ''
  if (nameInsurance) {
    if (nameInsurance.toUpperCase() === EInsuranceFeature.MOTOR_01) {
      tmp = 'THÔNG TIN BẢO HIỂM XE MÁY'
    }
    else if (nameInsurance.toUpperCase() === EInsuranceFeature.AUTO_01) {
      tmp = 'THÔNG TIN BẢO HIỂM Ô TÔ'
    }
    else if (nameInsurance.toUpperCase() === EInsuranceFeature.PERSONAL_01) {
      tmp = 'THÔNG TIN BẢO HIỂM TAI NẠN CÁ NHÂN'
    }
    else if (nameInsurance.toUpperCase() === EInsuranceFeature.TRAVEL_01) {
      tmp = 'THÔNG TIN BẢO HIỂM DU LỊCH'
    }
    else if (nameInsurance.toUpperCase() === EInsuranceFeature.HEALTH_01) {
      tmp = 'THÔNG TIN BẢO HIỂM SỨC KHỎE'
    }
    else if (nameInsurance.toUpperCase() === EInsuranceFeature.FIRE_01) {
      tmp = 'THÔNG TIN BẢO HIỂM CHÁY NỔ'
    }
    else if (nameInsurance.toUpperCase() === EInsuranceFeature.HOME_01) {
      tmp = 'THÔNG TIN BẢO HIỂM NHÀ TƯ NHÂN'
    }
  }

  return tmp
}
const TEXT_MISS_INFO = 'chưa cung cấp'
const CItemContractDetailData = ({ contractDetailData }: ICItemContractDetailData) => {
  const findName = (arr: any[] | undefined, code: string | number) => {
    const rsFindName = arr?.find((itemFind) => {
      if (arr) {
        return itemFind?.code == code
      }
    })
    return rsFindName
  }
  const [LazyGetDataProvinceIdQuery, dataProvince] = useLazyGetUserIntentByPartnerIdQuery();
  const [dataDistrict, setDataDistrict] = useState([])
  const [dataWard, setDataWard] = useState([])
  const findNameProvince = findName(dataProvince?.data, contractDetailData?.insuranceObject?.province)
  const findNameDistrict = findName(findNameProvince?.districts, contractDetailData?.insuranceObject?.district)
  const findNameWard = findName(findNameDistrict?.wards, contractDetailData?.insuranceObject?.ward)
  useEffect(() => {
    LazyGetDataProvinceIdQuery({
      name: ECategory.PROVINCE,
    })
  }, [])
  return <Row gutter={60}>
    <Col className="gutter-row" xl={12} xs={24}>
      <Card title={renderNameInsurance(contractDetailData?.insuranceObject?.feature)} size="small">
        <Descriptions column={1}>
          {
            contractDetailData?.insuranceObject?.feature === EInsuranceFeature.AUTO_01 || contractDetailData?.insuranceObject?.feature === EInsuranceFeature.MOTOR_01 && <>
              <Descriptions.Item label="Dung tích xe">
                {MotorInsuranceCategoryName[contractDetailData?.insuranceObject?.category] || TEXT_MISS_INFO}
              </Descriptions.Item>
              <Descriptions.Item label="Biển số xe">
                {contractDetailData?.insuranceObject?.licensePlates || TEXT_MISS_INFO}
              </Descriptions.Item>
              <Descriptions.Item label="Số khung">{contractDetailData?.insuranceObject?.chassisNumber || TEXT_MISS_INFO}
              </Descriptions.Item>
              <Descriptions.Item label="Số máy">
                {contractDetailData?.insuranceObject?.engineNumber || TEXT_MISS_INFO}
              </Descriptions.Item>
            </>
          }
          {
            contractDetailData?.insuranceObject?.feature === EInsuranceFeature.AUTO_01 && <>
              <Descriptions.Item label="Hãng xe">
                {contractDetailData?.insuranceObject[contractDetailData?.insuranceObject?.source]?.automaker || TEXT_MISS_INFO}
              </Descriptions.Item>
              <Descriptions.Item label="Hiệu xe">
                {contractDetailData?.insuranceObject[contractDetailData?.insuranceObject?.source]?.label || TEXT_MISS_INFO}
              </Descriptions.Item>
              <Descriptions.Item label="Năm sản xuất">
                {contractDetailData?.insuranceObject?.mfgDate || TEXT_MISS_INFO}
              </Descriptions.Item>
              <Descriptions.Item label="Số chỗ ngồi">
                {contractDetailData?.insuranceObject?.seats || TEXT_MISS_INFO}
              </Descriptions.Item>
              <Descriptions.Item label="Trọng tải">
                {contractDetailData?.insuranceObject?.vehicleLoad || TEXT_MISS_INFO}
              </Descriptions.Item>
              <Descriptions.Item label="Biển số xe">
                {contractDetailData?.insuranceObject?.licensePlates || TEXT_MISS_INFO}
              </Descriptions.Item>
              <Descriptions.Item label="Số khung">{contractDetailData?.insuranceObject?.chassisNumber || TEXT_MISS_INFO}
              </Descriptions.Item>
              <Descriptions.Item label="Số máy">
                {contractDetailData?.insuranceObject?.engineNumber || TEXT_MISS_INFO}
              </Descriptions.Item>
            </>
          }
          {
            contractDetailData?.insuranceObject?.feature === EInsuranceFeature.PERSONAL_01 && <>
              <Descriptions.Item label="Tên người thụ hưởng">
                {contractDetailData?.insuranceObject?.beneficiaryName || TEXT_MISS_INFO}
              </Descriptions.Item>
              <Descriptions.Item label="Giới tính">
                {contractDetailData?.insuranceObject?.gender || TEXT_MISS_INFO}
              </Descriptions.Item>
              <Descriptions.Item label="CCCD">
                {contractDetailData?.insuranceObject?.identityCardNum || TEXT_MISS_INFO}
              </Descriptions.Item>
              <Descriptions.Item label="Số điện thoại">
                {contractDetailData?.insuranceObject?.phone || TEXT_MISS_INFO}
              </Descriptions.Item>
              <Descriptions.Item label="Email">
                {contractDetailData?.insuranceObject?.email || TEXT_MISS_INFO}
              </Descriptions.Item>
            </>
          }
          {
            contractDetailData?.insuranceObject?.feature === EInsuranceFeature.HOME_01 && <>
              <Descriptions.Item label="Tỉnh/Thành phố">
                {findNameProvince?.name || TEXT_MISS_INFO}
              </Descriptions.Item>
              <Descriptions.Item label="Quận/Huyện">
                {findNameDistrict?.name || TEXT_MISS_INFO}
              </Descriptions.Item>
              <Descriptions.Item label="Phường/Xã">
                {findNameWard?.name || TEXT_MISS_INFO}
              </Descriptions.Item>
              <Descriptions.Item label="Địa chỉ">
                {contractDetailData?.insuranceObject?.address || TEXT_MISS_INFO}
              </Descriptions.Item>
              <Descriptions.Item label="CCCD">
                {contractDetailData?.insuranceObject?.identityCardNum || TEXT_MISS_INFO}
              </Descriptions.Item>
              <Descriptions.Item label="Số điện thoại">
                {contractDetailData?.insuranceObject?.phone || TEXT_MISS_INFO}
              </Descriptions.Item>
              <Descriptions.Item label="Email">
                {contractDetailData?.insuranceObject?.email || TEXT_MISS_INFO}
              </Descriptions.Item>
            </>
          }
        </Descriptions>
      </Card>
    </Col>
    <Col className="gutter-row" xl={12} xs={24}>
      <Card title="HÌNH ẢNH ĐÍNH KÈM" size="small">
        <div style={{ textAlign: "center" }}>
          <Empty
            image="https://gw.alipayobjects.com/zos/antfincdn/ZHrcdLPrvN/empty.svg"
            imageStyle={{ height: 200 }}
            description={
              <span>
                Chưa cung cấp hình ảnh
              </span>
            }
          >
          </Empty>
        </div>
      </Card>
    </Col>
  </Row >
};

export default CItemContractDetailData;
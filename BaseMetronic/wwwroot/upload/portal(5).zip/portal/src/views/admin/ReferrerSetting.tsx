import { Button, Form, InputNumber, Spin, Typography } from "antd";
import React from "react";
import { Box } from "src/common/Box";
import { FlexBox } from "src/common/FlexBox";
import useFormatter from "src/hooks/useFormatter";
import styled from "styled-components";
import useReferrerSetting from "./useReferrerSetting";

const FAKE_REVENUE = 66000;

export function commissionRound(commission: number): number {
  return Math.floor(commission / 1000) * 1000;
}

const ReferrerSetting = () => {
  const { formatter } = useFormatter();
  const {
    isLoading,
    currentSetting,
    handleUpdateSetting,
    isSaving,
    handleSaveSetting,
  } = useReferrerSetting();

  if (isLoading || !currentSetting) return <Spin />;

  return (
    <StyledContainer>
      <StyledTitle>Affiliate:</StyledTitle>
      <StyledSettingContainer>
        <Form.Item label="Số % giá trừ trước khi tính hoa hồng cho đại lý: ">
          <InputNumber
            defaultValue={currentSetting.basePriceTax || 0}
            formatter={(value) => `${value}%`}
            parser={(value) => Number(value?.replace("%", ""))}
            onChange={(value) => handleUpdateSetting("basePriceTax", value)}
          />
        </Form.Item>
      </StyledSettingContainer>
      <StyledSettingContainer>
        <Form.Item label="% Chiết khấu khi tự giới thiệu: ">
          <InputNumber
            defaultValue={currentSetting.commissionPercentDirectRefer || 0}
            formatter={(value) => `${value}%`}
            parser={(value) => Number(value?.replace("%", ""))}
            onChange={(value) =>
              handleUpdateSetting("commissionPercentDirectRefer", value)
            }
          />
        </Form.Item>
      </StyledSettingContainer>
      <StyledSettingContainer>
        <Form.Item label="% Chiết khấu nhận được khi cấp dưới (trực tiếp) giới thiệu: ">
          <InputNumber
            defaultValue={currentSetting.commissionPercentIndirectRefer || 0}
            formatter={(value) => `${value}%`}
            parser={(value) => Number(value?.replace("%", ""))}
            onChange={(value) =>
              handleUpdateSetting("commissionPercentIndirectRefer", value)
            }
          />
        </Form.Item>
      </StyledSettingContainer>
      <StyledSettingContainer>
        <Form.Item label="Số % thuế trừ khi trả hoa hồng: ">
          <InputNumber
            defaultValue={currentSetting.commissionTax || 0}
            formatter={(value) => `${value}%`}
            parser={(value) => Number(value?.replace("%", ""))}
            onChange={(value) => handleUpdateSetting("commissionTax", value)}
          />
        </Form.Item>
      </StyledSettingContainer>

      <Typography.Paragraph style={{ fontWeight: "bold" }}>
        Công thức tính hoa hồng khi tự giới thiệu:
      </Typography.Paragraph>
      <Typography.Paragraph
        style={{ fontSize: 12, fontStyle: "italic", color: "red" }}
      >
        {`Hoa hồng thực nhận = Giá bảo hiểm * (100/${
          100 + currentSetting.basePriceTax
        }) * ${currentSetting.commissionPercentDirectRefer / 100} * ${
          1 - currentSetting.commissionTax / 100
        }`}
      </Typography.Paragraph>
      <FlexBox style={{ justifyContent: "space-between" }}>
        <Typography>Doanh thu: {formatter.format(FAKE_REVENUE)}</Typography>
        <Typography></Typography>
      </FlexBox>
      <FlexBox style={{ justifyContent: "space-between" }}>
        <Typography>
          Doanh thu tính hoa hồng:{" "}
          {formatter.format(
            (FAKE_REVENUE * 100) / (100 + currentSetting.basePriceTax)
          )}
        </Typography>
        <Typography></Typography>
      </FlexBox>

      <FlexBox style={{ justifyContent: "space-between" }}>
        <Typography>
          Hoa hồng:{" "}
          {formatter.format(
            (FAKE_REVENUE *
              (100 / (100 + currentSetting.basePriceTax)) *
              currentSetting.commissionPercentDirectRefer) /
              100
          )}
        </Typography>
        <Typography></Typography>
      </FlexBox>

      <FlexBox style={{ justifyContent: "space-between" }}>
        <Typography>
          Hoa hồng thực nhận:{" "}
          {formatter.format(
            (((FAKE_REVENUE *
              (100 / (100 + currentSetting.basePriceTax)) *
              currentSetting.commissionPercentDirectRefer) /
              100) *
              (100 - currentSetting.commissionTax)) /
              100
          )}
        </Typography>
      </FlexBox>

      <Typography.Paragraph style={{ fontWeight: "bold", marginTop: 30 }}>
        Công thức tính hoa hồng khi đại lý cấp dưới giới thiệu:
      </Typography.Paragraph>

      <FlexBox>
        <Box style={{ paddingRight: 30 }}>
          <Typography.Paragraph
            style={{ fontSize: 12, fontStyle: "italic", color: "red" }}
          >
            {`Hoa hồng thực nhận = Giá bảo hiểm * (100/${
              100 + currentSetting.basePriceTax
            }) * ${currentSetting.commissionPercentIndirectRefer / 100} * ${
              1 - currentSetting.commissionTax / 100
            }`}
          </Typography.Paragraph>
          <FlexBox style={{ justifyContent: "space-between" }}>
            <Typography>Doanh thu: {formatter.format(FAKE_REVENUE)}</Typography>
            <Typography></Typography>
          </FlexBox>
          <FlexBox style={{ justifyContent: "space-between" }}>
            <Typography>
              Doanh thu tính hoa hồng:{" "}
              {formatter.format(
                FAKE_REVENUE * (100 / (100 + currentSetting.basePriceTax))
              )}
            </Typography>
            <Typography></Typography>
          </FlexBox>

          <FlexBox style={{ justifyContent: "space-between" }}>
            <Typography>
              Hoa hồng:{" "}
              {formatter.format(
                FAKE_REVENUE *
                  (100 / (100 + currentSetting.basePriceTax)) *
                  (currentSetting.commissionPercentIndirectRefer / 100)
              )}
            </Typography>
            <Typography></Typography>
          </FlexBox>

          <FlexBox style={{ justifyContent: "space-between" }}>
            <Typography>
              Hoa hồng thực nhận:{" "}
              {formatter.format(
                (FAKE_REVENUE *
                  (100 / (100 + currentSetting.basePriceTax)) *
                  (currentSetting.commissionPercentIndirectRefer / 100) *
                  (100 - currentSetting.commissionTax)) /
                  100
              )}
            </Typography>
            <Typography></Typography>
          </FlexBox>
        </Box>
      </FlexBox>

      <FlexBox style={{ justifyContent: "right", marginTop: 50 }}>
        <Button type="primary" loading={isSaving} onClick={handleSaveSetting}>
          Save
        </Button>
      </FlexBox>
    </StyledContainer>
  );
};

const StyledContainer = styled(Box)`
  padding: 20px 40px;
  background: white;
  box-shadow: 0px 2px 6px rgba(0, 0, 0, 0.05);
  width: 100%;
`;

const StyledTitle = styled(Typography)`
  font-weight: 700;
  padding: 10px 0;
  border-bottom: 1.5px solid rgba(0, 0, 0, 0.1);
`;

const StyledSettingContainer = styled(FlexBox)`
  margin-top: 15px;
  align-items: center;
`;

export default ReferrerSetting;

import {ImportOutlined, MoreOutlined} from "@ant-design/icons";
import {Avatar, Button, Col, Divider, Form, Popover, Row, Space, Typography} from "antd";
import {ColumnsType} from "antd/lib/table";
import {IUser} from "interfaces/user.interfaces";
import {useRouter} from "next/router";
import React, {useEffect} from "react";
import {FlexBox} from "src/common/FlexBox";
import useRole, {EUserRole} from "src/hooks/useRole";
import {useLazyGetUserFilterQuery} from "store/APIs/user";
import CustomInput from "../../common/CustomInput";
import CustomSelect from "../../common/CustomSelect";
import {
  DEFAULT_PAGE_START,
  DEFAULT_PARAMS_FILTER,
  USER_PARAMS_FILTER,
} from "../../../store/APIs/const";
import {removeNullValues} from "../../../store/APIs/common";
import CustomTable from "../../common/CustomTable";
import useIsMobile from "../../common/useIsMobile";
import {mapRolesToStrings} from "../../utils/roles";

const ListCustomer = () => {
  const {checkUserRole} = useRole();
  const router = useRouter();
  const [formFilter] = Form.useForm();
  const userId = Form.useWatch('userId', formFilter) || formFilter.getFieldValue('userId');
  const name = Form.useWatch('userName', formFilter) || formFilter.getFieldValue('userName');
  const role = Form.useWatch('userRole', formFilter) || formFilter.getFieldValue('userRole');
  const page = Form.useWatch('page', formFilter) || formFilter.getFieldValue('page');
  const limit = Form.useWatch('limit', formFilter) || formFilter.getFieldValue('limit');
  const isMobile = useIsMobile();

  const [GetUserLazyFilterQuery, { data, isLoading, isFetching, isSuccess, }] = useLazyGetUserFilterQuery();

  const paramsFilter = {
    userId, name, role, page, limit,
  }

  const rolesFilter = [{
    label: 'Khách hàng', value: '',
  }, {
    label: 'Quản trị viên', value: EUserRole.ADMIN
  }, {
    label: 'Đại lý/ Cộng tác viên', value: EUserRole.AGENCY
  }, {
    label: 'Chăm sóc khách hàng', value: EUserRole.CS
  }, {
    label: 'Kế toán', value: EUserRole.ACCOUNTANT
  },]

  useEffect(() => {
    GetUserLazyFilterQuery(removeNullValues(USER_PARAMS_FILTER))
  }, [])

  const columns: ColumnsType<IUser> = [{
    title: "Mã định danh",
    dataIndex: "id",
    key: "id",
    render: (text) => <Typography>{text}</Typography>,
  }, {
    title: "Hình ảnh",
    dataIndex: "avatar",
    key: "avatar",
    width: 100,
    render: (avatar) => <Avatar src={avatar} size={60}/>,
  }, {
    title: "Tên tài khoản", dataIndex: "name", key: "name",
    render: value => <strong>{value}</strong>
  }, {
    title: "Vai trò", dataIndex: "role", key: "role", render: (_role, record: IUser) => {
      return (<Typography>
            {
              mapRolesToStrings(record.roles)
            }
          </Typography>);
    },
  }, {
    title: "Ngày tạo tài khoản", dataIndex: "createdAt", key: "createdAt",
  }, {
    title: "", key: "action", render: (_, record: IUser) => {
      const {userIsAgency} = checkUserRole(record);

      const actions: { lable: string; onClick: () => void }[] = [...((!userIsAgency && [{
        lable: "Chuyển thành cộng tác viên", onClick: () => {
          ///
        },
      },]) || []),

        {
          lable: "Lịch sử giao dịch", onClick: () => {
            ///
            router.push(`/admin/customer/${record.id}/history`);
          },
        }, ...((userIsAgency && [{
          lable: "Xem lịch sử giới thiệu", onClick: () => {
            ///
            router.push(`/admin/customer/${record.id}/referred`);
          },
        },]) || []),];

      const content = () => (<div>
            {actions.map((item) => (<FlexBox
                    key={item.lable}
                    style={{
                      cursor: "pointer",
                      padding: "12px 8px",
                      borderBottom: "1px solid rgba(0,0,0,0.1)",
                    }}
                    onClick={item.onClick}
                >
                  <Typography>{item.lable}</Typography>
                </FlexBox>))}
          </div>);
      return (<Space size="middle">
            <Popover content={content} trigger="click">
              <Button icon={<MoreOutlined/>}/>
            </Popover>
          </Space>);
    },
  },];

  return (<div>
    <Form
        initialValues={USER_PARAMS_FILTER}
        layout={'vertical'}
        form={formFilter}
    >
      <Row gutter={[12, 12]}>
        <Col xs={24} lg={4} xl={4}>
          <Form.Item
              getValueProps={(i) => ({value: (i?.trimStart())})}
              name={'userId'}
              label="Mã định danh">
            <CustomInput
                placeholder="Nhập mã định danh"
            />
          </Form.Item>
        </Col>
        <Col xs={24} lg={4} xl={4}>
          <Form.Item
              getValueProps={(i) => ({value: (i?.trimStart())})}
              name={'userName'}
              label="Tên tài khoản">
            <CustomInput
                placeholder="Nhập tên tài khoản"
            />
          </Form.Item>
        </Col>
        <Col xs={24} lg={4} xl={4}>
          <Form.Item
              getValueProps={(i) => ({value: (i?.trimStart())})}
              name={'userRole'}
              label="Vai trò">
            <CustomSelect
                formInsert={formFilter}
                options={rolesFilter}
                placeholder="Chọn vai trò"
            />
          </Form.Item>
        </Col>
        <Col xs={24} lg={4} xl={4}>
          <Form.Item label=" ">
            <Button onClick={() => {
              formFilter.setFieldsValue({
                page: DEFAULT_PAGE_START,
              })
              GetUserLazyFilterQuery(removeNullValues({...paramsFilter, page: 1}))
            }} type="primary">Tìm kiếm</Button>
            <Button
                className='ml-12'
                onClick={() => {
                  formFilter.resetFields();
                  GetUserLazyFilterQuery(removeNullValues(DEFAULT_PARAMS_FILTER))
                }}>Đặt lại</Button>
          </Form.Item>
        </Col>
      </Row>
    </Form>
    <div className='pd-24' style={{background: 'white',}}>
      <div className={`d-flex  ${isMobile ? 'flex-column' : 'align-item-center flex-row'}`}>
        <h3 className='flex-1'>Danh sách tài khoản</h3>
      </div>
      <Divider/>
      <CustomTable
          columns={columns}
          totalDocs={data?.totalDocs || 0}
          data={data?.docs?.map((itemMap, key) => {
            return {
              ...itemMap, key: key + itemMap.id
            }
          }) || []}
          isLoading={false}
          onChange={(page, limit) => {
            if (paramsFilter.limit === limit) {
              formFilter.setFieldsValue({
                page,
              })
            } else {
              formFilter.setFieldsValue({
                page: DEFAULT_PAGE_START,
              })
            }
            const params = {
              ...paramsFilter, limit, page
            }
            formFilter.setFieldsValue({
              limit,
            })

            GetUserLazyFilterQuery(removeNullValues(params))
            window.scrollTo(0, 0);
          }}
          pageSize={limit}
          pageCurrent={page}
      />
    </div>
  </div>);
};

export default ListCustomer;

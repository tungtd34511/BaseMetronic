import { message } from "antd";
import { IReferrerSetting } from "interfaces/referrer.interface";
import { isEqual } from "lodash";
import { useCallback, useEffect, useState } from "react";
import {
  useGetReferrerSettingQuery,
  useUpdateReferrerSettingMutation,
} from "store/APIs/referrer";

const useReferrerSetting = () => {
  const { data: setting, isLoading } = useGetReferrerSettingQuery();
  const [updateSetting, { isLoading: isSaving, isSuccess }] =
    useUpdateReferrerSettingMutation();

  const [currentSetting, setCurrentSetting] =
    useState<Required<IReferrerSetting>>();

  const handleUpdateSetting = useCallback(
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    (key: keyof IReferrerSetting, value: any) => {
      setCurrentSetting({
        ...currentSetting,
        [key]: value,
      } as Required<IReferrerSetting>);
    },
    [currentSetting]
  );

  const handleSaveSetting = useCallback(() => {
    if (currentSetting) updateSetting(currentSetting);
  }, [currentSetting, updateSetting]);

  useEffect(() => {
    if (setting && !isEqual(setting, currentSetting)) {
      setCurrentSetting(setting);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [setting, setCurrentSetting]);

  useEffect(() => {
    if (isSuccess) {
      message.success("Saved");
    }
  }, [isSuccess]);

  return {
    isLoading,
    currentSetting,
    handleUpdateSetting,
    isSaving,
    handleSaveSetting,
  };
};

export default useReferrerSetting;

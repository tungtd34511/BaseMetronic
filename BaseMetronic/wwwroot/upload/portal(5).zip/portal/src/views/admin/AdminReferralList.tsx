import { Table, Typography } from "antd";
import { ColumnsType } from "antd/lib/table";
import { EInsuranceFeature } from "enums/insurance.enum";
import { IReferrerCommissionLog } from "interfaces/referrer.interface";
import moment from "moment";
import React, { useState } from "react";
import { DEFAULT_PAGE_SIZE } from "src/constants";
import useFormatter from "src/hooks/useFormatter";
import useRole from "src/hooks/useRole";
import { useGetInsuranceServicesQuery } from "store/APIs/insurance";
import { useGetMyCommissionLogListQuery } from "store/APIs/referrer";

const AdminReferralList = ({
  dateRange,
}: {
  dateRange: {
    from: number;
    to: number;
  };
}) => {
  const { isAgency } = useRole();
  const { formatter } = useFormatter();
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(DEFAULT_PAGE_SIZE);
  const { data, isLoading } = useGetMyCommissionLogListQuery({
    page,
    limit: pageSize,
    ...dateRange,
  });

  const { data: insuranceServices } = useGetInsuranceServicesQuery();

  const columns: ColumnsType<IReferrerCommissionLog> = [
    {
      title: "Ngày",
      dataIndex: "createdAt",
      key: "createdAt",
      render: (createdAt: Date) => (
        <Typography>{moment(createdAt).format("DD/MM/YYYY HH:mm")}</Typography>
      ),
    },
    // {
    //   title: "Loại bảo hiểm",
    //   dataIndex: "feature",
    //   key: "feature",
    //   render: (feature: EInsuranceFeature) => {
    //     if (!insuranceServices?.features?.length) return;
    //     return insuranceServices.features.find(
    //       (item) => item.feature === feature
    //     )?.title;
    //   },
    // },
    {
      title: "Người mua",
      dataIndex: "userName",
      key: "userName",
      render: (text) => <Typography>{text}</Typography>,
    },

    {
      title: "Người dùng thanh toán",
      dataIndex: "revenue",
      key: "revenue",
      render: (revenue: number) => (
        <Typography>{formatter.format(revenue)}</Typography>
      ),
    },
    {
      title: "Doanh thu tính hoa hồng",
      dataIndex: "revenueCalcCommission",
      key: "revenueCalcCommission",
      render: (revenue: number, record: IReferrerCommissionLog) => (
        <Typography>
          {formatter.format(revenue)}
          <Typography.Text
            style={{
              color: "red",
              paddingLeft: 10,
            }}
          >
            (-{record.setting.basePriceTax}% thuế)
          </Typography.Text>
        </Typography>
      ),
    },

    {
      title: "Hoa hồng",
      dataIndex: "commission",
      key: "commission",
      render: (_c: number, record: IReferrerCommissionLog) => (
        <Typography>
          {isAgency
            ? formatter.format(record.directReferrer?.originalAmount as number)
            : formatter.format(
                record.indirectReferrer?.originalAmount as number
              )}

          <Typography.Text
            style={{
              color: "blue",
              paddingLeft: 10,
            }}
          >
            (
            {!record.indirectReferrer
              ? record.setting.commissionPercentDirectRefer
              : record.setting.commissionPercentIndirectRefer}
            %)
          </Typography.Text>
        </Typography>
      ),
    },

    {
      title: "Nhận về",
      dataIndex: "commissionReceive",
      key: "commissionReceive",
      render: (_c: number, record: IReferrerCommissionLog) => (
        <Typography>
          {isAgency
            ? formatter.format(record.directReferrer?.amount as number)
            : formatter.format(record.indirectReferrer?.amount as number)}
          <Typography.Text
            style={{
              color: "red",
              paddingLeft: 10,
            }}
          >
            (-{record.setting.commissionTax}% thuế)
          </Typography.Text>
        </Typography>
      ),
    },
    {
      title: "Nguồn",
      dataIndex: "source",
      key: "source",
      render: (_source: string, record: IReferrerCommissionLog) => (
        <Typography>
          {record.indirectReferrer ? "Đại lý cấp dưới" : "Tự giới thiệu"}
        </Typography>
      ),
    },
  ];

  return (
    <div>
      <Table
        loading={isLoading}
        columns={columns}
        dataSource={data?.docs}
        scroll={{ x: 300 }}
        pagination={{
          pageSizeOptions: [15, 30, 45],
          showSizeChanger: true,
          locale: { items_per_page: "/trang" },
          pageSize: pageSize,
          total: data?.totalDocs || 0,
          onChange(page, pageSize) {
            setPage(page);
            setPageSize(pageSize);
          },
        }}
      />
    </div>
  );
};

export default AdminReferralList;

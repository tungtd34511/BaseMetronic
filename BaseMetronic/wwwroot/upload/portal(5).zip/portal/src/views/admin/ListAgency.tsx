import { MoreOutlined } from "@ant-design/icons";
import {
  Avatar,
  Button,
  Col, Divider,
  Form,
  Image,
  Input,
  Popover,
  Row,
  Space,
  Table,
  Typography
} from "antd";
import { ColumnsType } from "antd/lib/table";
import { IUser } from "interfaces/user.interfaces";
import { debounce } from "lodash";
import { useRouter } from "next/router";
import React, {useCallback, useEffect, useState} from "react";
import { FlexBox } from "src/common/FlexBox";
import { DEFAULT_PAGE_SIZE } from "src/constants";
import useRole from "src/hooks/useRole";
import {
  useGetAgencyListQuery, useLazyGetAgencyAdminListQuery,
  useLazyGetAgencyListV2Query,
  useLazyGetUserFilterQuery
} from "store/APIs/user";
import CustomInput from "../../common/CustomInput";
import {
  AGENCY_PARAMS_FILTER,
  DEFAULT_PAGE_START,
  DEFAULT_PARAMS_FILTER, USER_PARAMS_FILTER
} from "../../../store/APIs/const";
import {removeNullValues} from "../../../store/APIs/common";
import CustomTable from "../../common/CustomTable";
import useIsMobile from "../../common/useIsMobile";

const ListAgency = () => {
  const { checkUserRole } = useRole();
  const router = useRouter();
  const [formFilter] = Form.useForm();
  const userId = Form.useWatch('userId', formFilter) || formFilter.getFieldValue('userId');
  const name = Form.useWatch('userName', formFilter) || formFilter.getFieldValue('userName');
  const phone = Form.useWatch('userPhone', formFilter) || formFilter.getFieldValue('userPhone');
  const email = Form.useWatch('userEmail', formFilter) || formFilter.getFieldValue('userEmail');
  const page = Form.useWatch('page', formFilter) || formFilter.getFieldValue('page');
  const limit = Form.useWatch('limit', formFilter) || formFilter.getFieldValue('limit');
  const isMobile = useIsMobile()

  const [GetLazyAgencyListV2Query, { data, isLoading, isFetching, isSuccess, }] = useLazyGetAgencyAdminListQuery();

  const paramsFilter = {
    userId, name, phone, email, page, limit,
  }

  const columns: ColumnsType<IUser> = [
    {
      title: "Mã định danh",
      dataIndex: "id",
      key: "id",
      render: (text) => <Typography>{text}</Typography>,
    },
    {
      title: "Hình ảnh",
      dataIndex: "avatar",
      key: "avatar",
      width: 100,
      render: (avatar) => <Avatar src={avatar} size={60} />,
    },
    {
      title: "Tên đại lý",
      dataIndex: "name",
      key: "name",
      render: value => <strong>{value}</strong>
    },
    {
      title: "Email",
      dataIndex: "email",
      key: "email",
    },
    {
      title: "Số điện thoại",
      dataIndex: "phone",
      key: "phone",
    },
    {
      title: "Nhãn gán",
      dataIndex: "tags",
      key: "tags",
      render: (text : string[]) => <Typography>
        {text?.join(" ,")}
        </Typography>,
    },
    {
      title: "",
      key: "action",
      render: (_, record: IUser) => {
        const { userIsAgency } = checkUserRole(record);
        const actions: { lable: string; onClick: () => void }[] = [
          userIsAgency && {
            lable: "Xem lịch sử giới thiệu",
            onClick: () => {
              ///
              router.push(`/admin/${record.id}/referred`);
            },
          },
        ].filter(Boolean) as any;

        const content = () => (
          <div>
            {actions.map((item) => (
              <FlexBox
                key={item.lable}
                style={{
                  cursor: "pointer",
                  padding: "12px 8px",
                  borderBottom: "1px solid rgba(0,0,0,0.1)",
                }}
                onClick={item.onClick}
              >
                <Typography>{item.lable}</Typography>
              </FlexBox>
            ))}
          </div>
        );
        return (
          <Space size="middle">
            <Popover content={content} trigger="click">
              <Button icon={<MoreOutlined />} />
            </Popover>
          </Space>
        );
      },
    },
  ];

  useEffect(() => {
    GetLazyAgencyListV2Query(removeNullValues(AGENCY_PARAMS_FILTER))
  }, [])

  return (
      <div>
        <Form
            initialValues={AGENCY_PARAMS_FILTER}
            layout={'vertical'}
            form={formFilter}
        >
          <Row gutter={[12, 12]}>
            <Col xs={24} lg={4} xl={4}>
              <Form.Item
                  getValueProps={(i) => ({value: (i?.trimStart())})}
                  name={'userId'}
                  label="Mã định danh">
                <CustomInput
                    placeholder="Nhập mã định danh"
                />
              </Form.Item>
            </Col>
            <Col xs={24} lg={4} xl={4}>
              <Form.Item
                  getValueProps={(i) => ({value: (i?.trimStart())})}
                  name={'userName'}
                  label="Tên đại lý">
                <CustomInput
                    placeholder="Tên đại lý"
                />
              </Form.Item>
            </Col>
            <Col xs={24} lg={4} xl={4}>
              <Form.Item
                  getValueProps={(i) => ({value: (i?.trimStart())})}
                  name={'userEmail'}
                  label="Email">
                <CustomInput
                    placeholder="Nhập email"
                />
              </Form.Item>
            </Col>
            <Col xs={24} lg={4} xl={4}>
              <Form.Item
                  getValueProps={(i) => ({value: (i?.trimStart())})}
                  name={'userPhone'}
                  label="Số điện thoại">
                <CustomInput
                    placeholder="Nhập số điện thoại"
                />
              </Form.Item>
            </Col>
            <Col xs={24} lg={4} xl={4}>
              <Form.Item label=" ">
                <Button onClick={() => {
                  formFilter.setFieldsValue({
                    page: DEFAULT_PAGE_START,
                  })
                  GetLazyAgencyListV2Query(removeNullValues({...paramsFilter, page: 1}))
                }} type="primary">Tìm kiếm</Button>
                <Button
                    className='ml-12'
                    onClick={() => {
                      formFilter.resetFields();
                      GetLazyAgencyListV2Query(removeNullValues(DEFAULT_PARAMS_FILTER))
                    }}>Đặt lại</Button>
              </Form.Item>
            </Col>
          </Row>
        </Form>
        <div className='pd-24' style={{background: 'white',}}>
          <div className={`d-flex  ${isMobile ? 'flex-column' : 'align-item-center flex-row'}`}>
            <h3 className='flex-1'>Danh sách đại lý</h3>
          </div>
          <Divider/>
          <CustomTable
              columns={columns}
              totalDocs={data?.totalDocs || 0}
              data={data?.docs?.map((itemMap, key) => {
                return {
                  ...itemMap, key: key + itemMap.id
                }
              }) || []}
              isLoading={false}
              onChange={(page, limit) => {
                if (paramsFilter.limit === limit) {
                  formFilter.setFieldsValue({
                    page,
                  })
                } else {
                  formFilter.setFieldsValue({
                    page: DEFAULT_PAGE_START,
                  })
                }
                const params = {
                  ...paramsFilter, limit, page
                }
                formFilter.setFieldsValue({
                  limit,
                })

                GetLazyAgencyListV2Query(removeNullValues(params))
                window.scrollTo(0, 0);
              }}
              pageSize={limit}
              pageCurrent={page}
          />
        </div>
      </div>
  );
};

export default ListAgency;

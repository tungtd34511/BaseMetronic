import {Button, Divider, Popover, Space, Table, Typography} from "antd";
import { ColumnsType } from "antd/lib/table";
import React, { useState } from "react";
import { DEFAULT_PAGE_SIZE } from "src/constants";
import {
  EVoucherStatus,
  useAdminGetListVoucherQuery,
  useAdminApproveVoucherMutation,
  useAdminRejectVoucherMutation,
} from "store/APIs/referrer";
import moment from "moment";
import { IVoucher } from "interfaces/referrer.interface";
import { FlexBox } from "src/common/FlexBox";
import useFormatter from "src/hooks/useFormatter";
import useIsMobile from "../../common/useIsMobile";

const VoucherRequest = () => {
  const isMobile = useIsMobile();
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(DEFAULT_PAGE_SIZE);
  const { data, isLoading } = useAdminGetListVoucherQuery({
    page,
    limit: pageSize,
    status: EVoucherStatus.SUBMITTED,
  });
  const [rejectVoucherMutation, { isLoading: isRejectLoading }] =
    useAdminRejectVoucherMutation();
  const [approveVoucherMutation, { isLoading: isApproveLoading }] =
    useAdminApproveVoucherMutation();
  const { formatter } = useFormatter();

  const columns: ColumnsType<IVoucher> = [
    {
      title: "Người tạo",
      dataIndex: "agencyName",
      key: "agencyName",
      render: (agencyName) => <Typography>{agencyName}</Typography>,
    },
    {
      title: "Mã",
      dataIndex: "code",
      key: "code",
      render: (code) => <Typography>{code}</Typography>,
    },
    {
      title: "Số lượng",
      dataIndex: "qty",
      key: "qty",
      render: (qty) => <Typography>{qty}</Typography>,
    },

    {
      title: "Số tiền",
      dataIndex: "value",
      key: "value",
      render: (value: number) => formatter.format(value),
    },

    {
      title: "Mô tả",
      dataIndex: "description",
      key: "description",
      width: 300,
    },
    {
      title: "Ngày bắt đầu",
      dataIndex: "startDate",
      key: "startDate",
      render: (startDate) => (
        <Typography>{moment(startDate).format("DD/MM/YYYY")}</Typography>
      ),
    },

    {
      title: "Ngày kết thúc",
      dataIndex: "endDate",
      key: "endDate",
      render: (endDate) => (
        <Typography>{moment(endDate).format("DD/MM/YYYY")}</Typography>
      ),
    },
    {
      title: "Trạng thái",
      dataIndex: "status",
      key: "status",
      render: (status) => <Typography>{status}</Typography>,
    },

    {
      title: "Hành động",
      key: "action",
      render: (_: string, record: IVoucher) => {
        const actions: { lable: string; onClick: () => void }[] = [
          {
            lable: "Chấp nhận",
            onClick: () => {
              approveVoucherMutation({ id: record.id as string });
            },
          },
          {
            lable: "Từ chối",
            onClick: () => {
              rejectVoucherMutation({ id: record.id as string });
            },
          },
        ].filter(Boolean) as any;

        const content = () => (
          <div>
            {actions.map((item) => (
              <FlexBox
                key={item.lable}
                style={{
                  cursor: "pointer",
                  padding: "12px 8px",
                  borderBottom: "1px solid rgba(0,0,0,0.1)",
                }}
                onClick={item.onClick}
              >
                <Typography>{item.lable}</Typography>
              </FlexBox>
            ))}
          </div>
        );

        if (!actions.length) return null;
        return (
          <Space size="middle">
            <Popover content={content} title="" trigger="hover">
              <Button loading={isRejectLoading || isApproveLoading}>
                Hành động
              </Button>
            </Popover>
          </Space>
        );
      },
    },
  ];

  return (
    <div>
      <div className='pd-24' style={{background: 'white',}}>
        <div className={`d-flex  ${isMobile ? 'flex-column' : 'align-item-center flex-row'}`}>
          <h3 className='flex-1'>Danh sách mã khuyến mãi chờ duyệt</h3>
        </div>
        <Divider/>
        <Table
            loading={isLoading}
            columns={columns as any}
            dataSource={data?.docs}
            scroll={{ x: 300 }}
            pagination={{
              pageSizeOptions: [15, 30, 60],
              showSizeChanger: true,
              pageSize: pageSize,
              total: data?.totalDocs || 0,
              onChange(page, pageSize) {
                setPage(page);
                setPageSize(pageSize);
              },
            }}
        />
      </div>
    </div>
  );
};

export default VoucherRequest;

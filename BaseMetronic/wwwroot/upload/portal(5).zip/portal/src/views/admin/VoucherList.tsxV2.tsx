import { Button, Col, DatePicker, Divider, Form, Modal, Row, Select, Spin } from "antd";
import Table, { ColumnsType } from "antd/lib/table";
import React, { useEffect, useState } from "react";
import { DEFAULT_PAGE_SIZE } from "src/constants";
import {
    useCreateVoucherV2Mutation,
    useDeleteVoucherV2Mutation,
    useGetDetailVoucherByBatchV2Mutation,
    useGetDetailVoucherV2Mutation,
    useGetListVoucherV2Query,
    useLazyGetListVoucherV2Query,
    useUpdateVoucherV2Mutation,
} from "store/APIs/referrer";
import { ICreateVoucherV2, IVoucherDetailV2, IVoucherV2 } from "interfaces/referrer.interface";
import useIsMobile from "../../common/useIsMobile";
import { DeleteOutlined, EditOutlined, EyeOutlined } from "@ant-design/icons";
import CustomTable from "src/common/CustomTable";
import CustomModal from "src/common/CustomModal";
import moment from "moment";
import { ConvertNameFeature, TITLE_NOTIFICATION } from "store/APIs/common";
import CustomDateRangePicker from "src/common/CustomDateRangePicker";
import CustomInput from "src/common/CustomInput";
import { ARR_INSURANCE_FEATURE } from "enums/insurance.enum";
import { NOT_EMPTY, PRESS, TYPE_ARR_INPUT } from "store/APIs/const";
import { validateMaxLength, validateOnlyNumber } from "src/common/Validate";
import CustomSelect from "src/common/CustomSelect";
import CustomInputNumber from "src/common/CustomInputPrice";
import { useLazyGetAgencyListV2Query } from "store/APIs/user";
function formatVND(amount: number) {
    return amount.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
}
const VoucherListV2 = () => {
    const lastMonth = moment().subtract(1, 'months').toISOString(true);
    const currentMonth = moment().toISOString(true);
    const DEFAULT_PARAMS_FILTER = {
        startDate: lastMonth,
        endDate: currentMonth,
        feature: '',
        batchName: '',
        page: 1,
        limit: DEFAULT_PAGE_SIZE
    }
    const DEFAULT_PARAMS_FILTER_VIEW_DETAIL = {
        page: 1,
        limit: DEFAULT_PAGE_SIZE
    }
    const isMobile = useIsMobile();
    const [paramsFilter, setParamsFilter] = useState(DEFAULT_PARAMS_FILTER)
    const [paramsFilterViewDetail, setParamsFilterViewDetail] = useState(DEFAULT_PARAMS_FILTER_VIEW_DETAIL)
    // const { data, isLoading } = useGetListVoucherV2Query(paramsFilter);
    const [lazyGetListVoucherV2, { data, isLoading }] = useLazyGetListVoucherV2Query();
    const [lazyGetDetailVoucherV2, { data: dataGetdetail, isLoading: isGetDetailVoucherV2Loading }] = useGetDetailVoucherV2Mutation();
    const [lazyGetDetailVoucherByBatchV2, { data: dataGetdetailByBatch, isLoading: isGetDetailVoucherV2LoadingByBatch }] = useGetDetailVoucherByBatchV2Mutation();
    const [createVoucherMutation, { data: voucherResponse, isSuccess, status }] =
        useCreateVoucherV2Mutation();
    const [updateVoucherV2, info] = useUpdateVoucherV2Mutation();
    const [deleteVoucherMutationV2, { isLoading: isDeleteLoading }] =
        useDeleteVoucherV2Mutation();
    const [formInsert] = Form.useForm();
    const statusFormInsert = formInsert?.getFieldValue('status')
    const [isModalOpen, setIsModalOpen] = useState(false)
    const columns: ColumnsType<IVoucherV2> = [
        {
            title: "Mã lô voucher",
            render: (row: IVoucherV2) => row?.id,
        },
        {
            title: "Tên lô voucher",
            render: (row: IVoucherV2) => row?.batchName,
        },
        {
            title: "Bảo hiểm áp dụng",
            render: (row: IVoucherV2) => ConvertNameFeature(row?.feature),
        },
        {
            title: "Mệnh giá",
            render: (row: IVoucherV2) => formatVND(row?.amount || 0) + ' VNĐ',
        },
        {
            title: "Số voucher",
            render: (row: IVoucherV2) => formatVND(row?.quantity),
        },
        {
            title: "Trạng thái",
            render: (row: IVoucherV2) => <span style={{ color: '#f5222d' }}>{row?.deleted ? 'Đã xóa' : ''}</span>,
        },
        {
            title: "Ngày tạo",
            render: (row: IVoucherV2) => row?.createdAt && moment(row?.createdAt).format('DD-MM-YYYY'),
        },
        {
            title: 'Thao tác',
            render: (row: IVoucherV2) => <div>
                {
                    !row?.deleted && <EditOutlined onClick={() => {
                        lazyGetDetailVoucherV2(row)
                        formInsert.setFieldsValue({
                            'status': 'EDIT'
                        })
                    }} className='cursor-pointer' style={{ fontSize: '20px' }} />
                }
                {
                    !row?.deleted && <DeleteOutlined onClick={() => {
                        showConfirm(row)
                    }} className='ml-12 cursor-pointer' style={{ fontSize: '20px' }} />
                }
                {
                    !row?.deleted && <EyeOutlined onClick={async () => {
                        lazyGetDetailVoucherV2(row)
                        formInsert.setFieldsValue({
                            'status': 'VIEW'
                        })
                    }} className='ml-12 cursor-pointer' style={{ fontSize: '20px' }} />
                }
            </div>,
        },

    ];

    const columnsListVoucher: ColumnsType<IVoucherDetailV2> = [
        {
            title: "Mã voucher",
            render: (row: IVoucherDetailV2) => row?.code,
        },
        {
            title: "Trạng thái",
            render: (row: IVoucherDetailV2) => row?.status === 'UNUSED' ? 'Chưa sử dụng' : 'Đã sử dụng',
        },
        {
            title: "ID người sử dụng voucher",
            render: (row: IVoucherDetailV2) => row?.userUsedId,
        },
        {
            title: "Ngày sử dụng",
            render: (row: IVoucherDetailV2) => row?.usedDate && moment(row?.usedDate).format('DD-MM-YYYY'),
        },


    ];
    const handleSubmit = (values: ICreateVoucherV2) => {
        values.startDate = (moment(values.startDate).toISOString());
        values.endDate = (moment(values.endDate).toISOString());
        if (formInsert?.getFieldValue('id')) {
            updateVoucherV2({
                ...values,
                id: formInsert?.getFieldValue('id')
            })
        } else {
            createVoucherMutation(values)
        }
    }
    const showConfirm = (row: IVoucherV2) => {
        Modal.confirm({
            okButtonProps: {
                className: 'ant-btn ant-btn-danger'
            },
            title: TITLE_NOTIFICATION,
            content: 'Xác nhận xóa lô voucher này?',
            onOk: async () => {
                await deleteVoucherMutationV2({ id: row.id });
            },
            onCancel() {
                console.log('Hủy bỏ');
            },
            cancelText: 'Hủy',
            okText: 'Xác nhận',
            closable: true
        });
    };
    const ARR_INPUT_TYPE_INSURNCE = [
        {
            id: 'batchName',
            label: 'Tên lô voucher  ',
            type: TYPE_ARR_INPUT.INPUT,
            placeholder: `${PRESS} Tên lô voucher`,
            rules: [
                {
                    required: true,
                    message: `Tên lô voucher ${NOT_EMPTY}`
                },
                {
                    pattern: validateMaxLength(50).regexPattern,
                    message: validateMaxLength(50).message
                },

            ]
        },
        {
            id: 'amount',
            label: 'Mệnh giá',
            type: TYPE_ARR_INPUT.INPUT_PRICE,
            placeholder: `${PRESS} Mệnh giá`,
            rules: [
                {
                    required: true,
                    message: `Mệnh giá ${NOT_EMPTY}`
                },
                {
                    pattern: validateMaxLength(10).regexPattern,
                    message: validateMaxLength(10).message
                },
                {
                    pattern: validateOnlyNumber().regexPattern,
                    message: validateOnlyNumber().message
                },
            ]
        },
        {
            id: 'quantity',
            label: 'Số lượng',
            type: TYPE_ARR_INPUT.INPUT_PRICE,
            placeholder: `${PRESS} Số lượng`,
            rules: [
                {
                    required: true,
                    message: `Số lượng ${NOT_EMPTY}`
                },
                {
                    pattern: validateMaxLength(4).regexPattern,
                    message: validateMaxLength(4).message
                },
                {
                    pattern: validateOnlyNumber().regexPattern,
                    message: validateOnlyNumber().message
                },


            ]
        },
    ]
    const ARR_SELECT = [
        {
            id: 'feature',
            label: 'Bảo hiểm áp dụng',
            options: ARR_INSURANCE_FEATURE,
            rules: [{ required: true, message: 'Không được để trống' }],
        },
    ]
    const validateDates = (_: any, value: any) => {
        const startDate = formInsert.getFieldValue('startDate');
        if (startDate && value && value.isBefore(startDate, 'day')) {
            return Promise.reject(new Error('Ngày kết thúc phải lớn hơn ngày bắt đầu!'));
        }
        return Promise.resolve();
    };
    useEffect(() => {
        if (isSuccess || info?.isSuccess) {
            setIsModalOpen(false)
            formInsert.resetFields()
        }
    }, [isSuccess, info?.isSuccess])
    useEffect(() => {
        lazyGetListVoucherV2(paramsFilter)
    },
        [paramsFilter.page, paramsFilter.limit])
    useEffect(() => {
        lazyGetDetailVoucherByBatchV2({
            id: dataGetdetail?.id as string,
            page: paramsFilterViewDetail.page,
            limit: paramsFilter.limit
        })
    },
        [paramsFilterViewDetail.page, paramsFilterViewDetail.limit])
    useEffect(() => {
        if (dataGetdetail) {
            setParamsFilterViewDetail(DEFAULT_PARAMS_FILTER_VIEW_DETAIL)
            formInsert.setFieldsValue({
                'batchName': dataGetdetail?.batchName
            })
            formInsert.setFieldsValue({
                'id': dataGetdetail?.id
            })
            formInsert.setFieldsValue({
                'amount': dataGetdetail?.amount
            })
            formInsert.setFieldsValue({
                'quantity': dataGetdetail?.quantity
            })
            formInsert.setFieldsValue({
                'feature': dataGetdetail?.feature
            })
            formInsert.setFieldsValue({
                'startDate': moment(dataGetdetail?.startDate)
            })
            formInsert.setFieldsValue({
                'endDate': moment(dataGetdetail?.endDate)
            })
            if (statusFormInsert === 'VIEW') {
                lazyGetDetailVoucherByBatchV2({
                    id: dataGetdetail?.id,
                    page: paramsFilterViewDetail.page,
                    limit: paramsFilter.limit
                })

            }
            setIsModalOpen(true)
        }
    }, [dataGetdetail])
    return (
        <div>
            {
                (isLoading || info?.isLoading || isDeleteLoading || isGetDetailVoucherV2Loading) && <Spin
                    style={{ position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%,-50%)' }}
                    size="large" />
            }
            <Row gutter={[12, 12]}>
                {/* CustomInput */}
                <Col xs={24} lg={4} xl={4}>
                    <Form.Item label={'Tên voucher'}>
                        <CustomInput
                            maxLength={50}
                            value={paramsFilter.batchName}
                            placeholder="Điền tên voucher"
                            onChange={(e) => {
                                console.log(e)
                                setParamsFilter({
                                    ...paramsFilter,
                                    batchName: e.target.value.trimStart()
                                })
                            }}
                        />
                    </Form.Item>
                </Col>
                <Col xs={24} lg={4} xl={4}>
                    <Form.Item label={'Bảo hiểm áp dụng'}>
                        <Select
                            value={paramsFilter.feature}
                            onChange={(e) => {
                                setParamsFilter({
                                    ...paramsFilter,
                                    feature: e
                                })
                            }}>
                            {
                                ARR_INSURANCE_FEATURE.map((itemMap) => <Select.Option value={itemMap.value}>{itemMap.label}</Select.Option>)
                            }
                        </Select>
                    </Form.Item>
                </Col>

                <Col xs={24} lg={4} xl={4}>
                    <Form.Item label={'Ngày tạo'}>
                        <CustomDateRangePicker
                            startDate={paramsFilter.startDate}
                            endDate={paramsFilter.endDate}
                            onChange={(from, to) => {
                                setParamsFilter({
                                    ...paramsFilter,
                                    startDate: moment(new Date(from)).toISOString(),
                                    endDate: moment(new Date(to)).toISOString()
                                })
                            }}
                        />
                    </Form.Item>
                </Col>
                <Col style={{ display: 'flex', alignItems: 'center', marginTop: '6px' }} xs={24} lg={4} xl={4}>
                    <Button onClick={() => {
                        lazyGetListVoucherV2(paramsFilter)
                        setParamsFilter({
                            ...paramsFilter,
                            page: 1
                        })
                    }} type="primary">Tìm kiếm</Button>
                    <Button
                        className='ml-12'
                        onClick={() => {
                            setParamsFilter(DEFAULT_PARAMS_FILTER)
                            lazyGetListVoucherV2(DEFAULT_PARAMS_FILTER)
                        }}>Đặt lại</Button>
                </Col>


            </Row>
            <Form
                onFinish={handleSubmit}
                form={formInsert}
            >
                <CustomModal
                    title={statusFormInsert === 'EDIT' ? 'Cập nhật lô voucher' : statusFormInsert === 'VIEW' ? 'Chi tiết lô' : 'Tạo mới lô voucher'}
                    handleCancel={() => {
                        formInsert.resetFields()
                        setIsModalOpen(false)
                    }}
                    handleOk={formInsert.submit}
                    isModalOpen={isModalOpen}
                    setIsModalOpen={setIsModalOpen}
                >
                    <Row gutter={[12, 12]}>
                        <Col xl={24} xs={24}>
                            <h3>
                                {'Thông tin voucher'}
                            </h3>
                        </Col>

                        {
                            ARR_INPUT_TYPE_INSURNCE.map((itemMap, key) => <Col key={itemMap.id + key} xs={12} xl={12}>
                                {
                                    itemMap.type === TYPE_ARR_INPUT.INPUT && <Form.Item
                                        name={itemMap.id}
                                        rules={itemMap.rules || []}
                                        label={<span>{itemMap.label}</span>}>

                                        <CustomInput
                                            placeholder={itemMap.placeholder}
                                            id={itemMap.id}
                                        />
                                    </Form.Item>
                                }
                                {
                                    itemMap.type === TYPE_ARR_INPUT.INPUT_PRICE &&
                                    <CustomInputNumber
                                        itemMap={itemMap}
                                    />
                                }
                            </Col>)
                        }
                        {
                            ARR_SELECT.map((itemMap, key) => {
                                return <Col key={itemMap.id + key} xs={12} xl={12}>
                                    <Form.Item
                                        name={itemMap.id}
                                        rules={itemMap.rules}
                                        label={itemMap.label}
                                    >
                                        <CustomSelect
                                            formInsert={formInsert}
                                            id={itemMap.id}
                                            onChange={(e) => {
                                            }}
                                            options={itemMap.options}
                                        />
                                    </Form.Item>
                                </Col>
                            })
                        }
                        <Col xs={12} xl={12}>
                            <Form.Item
                                className="w-100"
                                name="startDate"
                                label="Ngày bắt đầu"
                                rules={[{ required: true, message: 'Ngày bắt đầu không được để trống' }]}
                            >
                                <DatePicker

                                    placeholder="Chọn ngày bắt đầu"
                                    format={'DD-MM-YYYY'}
                                    className="w-100"
                                />
                            </Form.Item>
                        </Col>
                        <Col xs={12} xl={12}>
                            <Form.Item
                                className="w-100"
                                name="endDate"
                                label="Ngày kết thúc"
                                rules={[
                                    { required: true, message: 'Ngày bắt đầu không được để trống' },
                                    { validator: validateDates },
                                ]}
                            >
                                <DatePicker
                                    placeholder="Chọn ngày kết thúc"
                                    format={'DD-MM-YYYY'}
                                    className="w-100"
                                />
                            </Form.Item>
                        </Col>
                        {
                            statusFormInsert === 'VIEW' && <Col xl={24} xs={24} xxl={24}>
                                <h3>Danh sách lô voucher lẻ</h3>
                                <CustomTable
                                    columns={columnsListVoucher}
                                    totalDocs={dataGetdetailByBatch?.totalDocs || 0}
                                    data={dataGetdetailByBatch?.docs}
                                    isLoading={isLoading}
                                    onChange={(page, limit) => {
                                        window.scrollTo(0, 0);
                                        setParamsFilterViewDetail({
                                            ...paramsFilterViewDetail,
                                            page,
                                            limit
                                        })
                                    }}
                                    pageSize={paramsFilterViewDetail.limit}
                                    pageCurrent={paramsFilterViewDetail.page}
                                />
                            </Col>
                        }

                    </Row>
                </CustomModal>

            </Form>
            <div className='pd-24' style={{ background: 'white', }}>
                <div className={`d-flex  ${isMobile ? 'flex-column' : 'align-item-center flex-row'}`}>
                    <h3 className='flex-1'>Quản lý lô voucher</h3>
                    {/* <Button className={`${!isMobile ? 'ml-12' : 'mgbt-12'} `} type="primary" danger>Xóa</Button> */}
                    <Button
                        onClick={() => {
                            setIsModalOpen(true)
                        }}
                        className={`${!isMobile ? 'ml-12' : 'mgbt-12'}`}
                        type="primary">
                        Tạo mới
                    </Button>
                </div>
                <Divider />
                <CustomTable
                    columns={columns}
                    totalDocs={data?.totalDocs || 0}
                    data={data?.docs}
                    isLoading={isLoading}
                    onChange={(page, limit) => {
                        window.scrollTo(0, 0);
                        setParamsFilter({
                            ...paramsFilter,
                            page,
                            limit
                        })
                    }}
                    pageSize={paramsFilter.limit}
                    pageCurrent={paramsFilter.page}
                />
            </div>
        </div>
    );
};

export default VoucherListV2;

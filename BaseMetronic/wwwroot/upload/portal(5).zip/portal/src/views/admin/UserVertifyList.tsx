import { MoreOutlined } from "@ant-design/icons";
import { Button, Image, Input, Popover, Space, Table, Typography, message } from "antd";
import { ColumnsType } from "antd/lib/table";
import { IUser, IUserDetails } from "interfaces/user.interfaces";
import { debounce } from "lodash";
import { useRouter } from "next/router";
import React, { useCallback, useEffect, useState } from "react";
import { FlexBox } from "src/common/FlexBox";
import { DEFAULT_PAGE_SIZE } from "src/constants";
import useRole from "src/hooks/useRole";
import { useGetUserDetailsListQuery, useUpdateDetailsMutation } from "store/APIs/user";
import UserDetailPopup from "./userDetailPopup";

const UserVertiyList : React.FC<{isVertified:boolean}> = ({isVertified}) => {
  const { checkUserRole } = useRole();
  const router = useRouter();
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState("");
  const [pageSize, setPageSize] = useState(DEFAULT_PAGE_SIZE);
  const { data, isLoading } = useGetUserDetailsListQuery({
    page,
    limit: pageSize,
    isVertified : isVertified,
    search,
  });

  const columns: ColumnsType<IUser> = [
    {
      title: "Mã định danh",
      dataIndex: ["user", "id"],
      key: "id",
      width: 150,
      render: (text) => <Typography>{text}</Typography>,
    },

    {
      title: "Vai trò",
      dataIndex: ["user", "role"],
      key: "role",
      render: (_role, record : any) => {
        const { userIsCustomer, userIsAgency } = checkUserRole(record.user);
        return (
          <Typography>
            {(userIsAgency && "Đại lý") || (userIsCustomer && "Người dùng")}
          </Typography>
        );
      },
    },

    {
      title: "Tên",
      dataIndex: ["user", "name"],
      key: "name",
    },
    {
      title: "Ảnh đại diện",
      dataIndex: ["user", "avatar"],
      key: "avatar",
      render: (avatar) => <Image src={avatar} alt="" width={100} />,
    },

    {
      title: "",
      key: "action",
      render: (_, record: any) => {
        const actions: { lable: string; onClick: () => void }[] = [
          {
            lable: "Thông tin đã điền",
            onClick: () => {
              handleOpenFile(record);
            },
          },
          {
            lable: isVertified ? "Đổi thành chưa duyệt" : "Đổi thành đã duyệt",
            onClick: () => {
              updateUser(record,1)
            },
          },
          {
            lable: record.userDetails.contractSented ? "Đổi thành chưa gửi hợp đồng" : "Đổi thành đã gửi hợp đồng",
            onClick: () => {
              updateUser(record,2)
            },
          },
        ];

        const content = () => (
          <div>
            {actions.map((item) => (
              <FlexBox
                key={item.lable}
                style={{
                  cursor: "pointer",
                  padding: "12px 8px",
                  borderBottom: "1px solid rgba(0,0,0,0.1)",
                }}
                onClick={item.onClick}
              >
                <Typography>{item.lable}</Typography>
              </FlexBox>
            ))}
          </div>
        );
        return (
          <Space size="middle">
            <Popover content={content} trigger="click">
              <Button icon={<MoreOutlined />} />
            </Popover>
          </Space>
        );
      },
    },
  ];
  const handleSearch = useCallback(
    debounce((value) => {
      setSearch(value);
    }, 500),
    []
  );
  const [selectedRecord, setSelectedRecord] = useState<any>(null);
  const [isPopupVisible, setIsPopupVisible] = useState(false);
  const handleOpenFile = (record: {
    user : IUser,
    userDetails : IUserDetails
  }) => {
    setSelectedRecord(record);
    setIsPopupVisible(true);
  };
  const handleClosePopup = () => {
    setSelectedRecord(null);
    setIsPopupVisible(false);
  };
  const [
    updateDetailsMutation,
    { isLoading: isUpdateLoading, isError, isSuccess },
  ] = useUpdateDetailsMutation();
  const updateUser= (record: {
    user : IUser,
    userDetails : IUserDetails
  } , type : number) => {
    const payload: IUserDetails = {
      fullName: record.userDetails.fullName,
      birthday: record.userDetails.birthday,
      gender: record.userDetails.gender,
      phone: record.userDetails.phone,
      address: record.userDetails.address,
      IDCardNum: record.userDetails.IDCardNum,
      dateOfIssue: record.userDetails.dateOfIssue,
      issuedBy: record.userDetails.issuedBy,
      dueDate: record.userDetails.dueDate,
      bankAccNum: record.userDetails.bankAccNum,
      bankAccName: record.userDetails.bankAccName,
      bankName: record.userDetails.bankName,
      taxCode: record.userDetails.taxCode,
      IDCardImages: record.userDetails.IDCardImages,
      cardImages: record.userDetails.cardImages,
      signImage: record.userDetails.signImage,
      contractSented : record.userDetails.contractSented,
      isVertified: record.userDetails.isVertified
    };
    if(type == 1){
      payload.isVertified =  !isVertified
    }else{
      payload.contractSented = !payload.contractSented
    }
    updateDetailsMutation(payload);
  };
  useEffect(() => {
    if (isError) {
      message.error("Có lỗi xảy ra");
    }
    if (isSuccess) {
      message.success("Cập nhật thành công");
    }
  }, [isError, isSuccess]);
  return (
    <div>
      <Input
        style={{
          margin: "20px 0",
          background: "white",
          borderRadius: 5,
          maxWidth: 300,
        }}
        onChange={(e) => handleSearch(e.target.value)}
        placeholder="Tìm kiếm"
      />
      <Table
        loading={isLoading}
        columns={columns}
        dataSource={data?.docs}
        scroll={{ x: 300 }}
        pagination={{
          pageSizeOptions: [15, 30, 60],
          showSizeChanger: true,
          pageSize: pageSize,
          total: data?.totalDocs || 0,
          onChange(page, pageSize) {
            setPage(page);
            setPageSize(pageSize);
          },
        }}
      />
      {selectedRecord && (
        <UserDetailPopup
          visible={isPopupVisible}
          record={selectedRecord}
          onClose={handleClosePopup}
        />
      )}
    </div>
  );
};

export default UserVertiyList;

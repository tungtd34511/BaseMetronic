import {
  Button,
  Col,
  Divider,
  Form,
  Modal,
  Row,
  Tag,
  Typography,
  Space,
  Popover, Tabs, Descriptions, Avatar, Table, Card, Empty, TableColumnsType
} from 'antd';
import React, { useEffect, useState } from 'react';
import CustomDateRangePicker from 'src/common/CustomDateRangePicker';
import CustomSelect from 'src/common/CustomSelect';
import CustomTable from 'src/common/CustomTable';
import {
  IContractOnline,
  IPNLogsOnline,
  useLazyGetContractOnlineDetailQuery,
  useLazyGetContractOnlineLogsQuery,
  useLazyGetContractOnlineQuery,
} from 'store/APIs/contract';
import useIsMobile from 'src/common/useIsMobile';
import moment from 'moment';
import CustomInput from 'src/common/CustomInput';
import {
  ARR_INSURANCE_FEATURE,
  ARR_INSURANCE_SOURCE,
  ARR_INSURANCE_STAGE, EInsuranceFeature,
  EInsuranceWorkflowStage
} from 'enums/insurance.enum';
import { DEFAULT_PAGE_START, INSURANCE_ONLINE_PARAMS_FILTER } from 'store/APIs/const';
import {
  ConvertNameFeature,
  FORMAT_DATE,
  FORMAT_DATE_WITHOUT_HOUR,
  removeNullValues
} from 'store/APIs/common';
import { FlexBox } from "../../common/FlexBox";
import { MoreOutlined } from "@ant-design/icons";
const { Paragraph, Text, Title } = Typography;

import styled from "styled-components";
import { mapRolesToStrings } from "../../utils/roles";
import {
  useLazyGetTransactionDetailQuery,
} from "../../../store/APIs/transaction";
import { MotorInsuranceCategoryName } from "../../utils/name";
import Column from "antd/es/table/Column";
import CItemContractDetailData from './CItemContractDetailData';
const PolicyList = () => {
  const [paramsFilterDate, setParamsFilterDate] = useState({
    from: INSURANCE_ONLINE_PARAMS_FILTER.from,
    to: INSURANCE_ONLINE_PARAMS_FILTER.to,
  })
  const [currentContract, setSelectedContract] = useState({} as IContractOnline);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [activeTab, setActiveTab] = useState("1");
  const [formFilter] = Form.useForm();
  const [LazyGetContractOnline, { data, isLoading, isFetching, isSuccess, }] = useLazyGetContractOnlineQuery();
  const [LazyGetContractOnlineDetail, { data: contractDetailData }] = useLazyGetContractOnlineDetailQuery();
  const [LazyGetTransactionDetail, { data: transactionDetail }] = useLazyGetTransactionDetailQuery();
  const [LazyGetContractOnlineLogs, { data: contractLogs }] = useLazyGetContractOnlineLogsQuery();
  const isMobile = useIsMobile()
  const insuranceId = Form.useWatch('insuranceId', formFilter) || formFilter.getFieldValue('insuranceId');
  const feature = Form.useWatch('feature', formFilter) || formFilter.getFieldValue('feature');
  const buyerId = Form.useWatch('buyerId', formFilter) || formFilter.getFieldValue('buyerId');
  const buyerName = Form.useWatch('buyerName', formFilter) || formFilter.getFieldValue('buyerName');
  const idCardNumber = Form.useWatch('idCardNumber', formFilter) || formFilter.getFieldValue('idCardNumber');
  const phone = Form.useWatch('phone', formFilter) || formFilter.getFieldValue('phone');
  const stage = Form.useWatch('stage', formFilter) || formFilter.getFieldValue('stage');
  const source = Form.useWatch('source', formFilter) || formFilter.getFieldValue('source');
  const page = Form.useWatch('page', formFilter) || formFilter.getFieldValue('page');

  const limit = Form.useWatch('limit', formFilter) || formFilter.getFieldValue('limit');

  const paramsFilter = {
    insuranceId,
    buyerId,
    buyerName,
    idCardNumber,
    phone,
    stage,
    source,
    feature,
    limit,
    page,
    from: paramsFilterDate.from,
    to: paramsFilterDate.to,
  }

  const columns = [
    {
      title: 'Trạng thái hợp đồng',
      render: (data: IContractOnline) => (
        (data?.stage === EInsuranceWorkflowStage.AWAITING_PAYMENT && <Tag color={'orange'}>{getStageName(data?.stage)}</Tag>)
        || (data?.stage === EInsuranceWorkflowStage.PENDING && <Tag color={'#00a3ff'}>{getStageName(data?.stage)}</Tag>)
        || (data?.stage === EInsuranceWorkflowStage.ERROR && <Tag color={'red'}>{getStageName(data?.stage)}</Tag>)
        || (data?.stage === EInsuranceWorkflowStage.SUCCESSFUL && <Tag color={'#00e300'}>{getStageName(data?.stage)}</Tag>)
      )
    },
    {
      title: 'Ngày giao dịch',
      render: (data: IContractOnline) => <div>{moment(data?.createdAt).format(FORMAT_DATE)}</div>
    },
    {
      title: 'Mã HĐ',
      render: (data: IContractOnline) => <a onClick={() => {
        LazyGetContractOnlineDetail(data.id);
        LazyGetTransactionDetail(data.transactionId);
        LazyGetContractOnlineLogs(data.id);
        setSelectedContract(data);
        setIsModalOpen(true);
      }}>{data?.id}</a>
    },
    {
      title: 'Loại hợp đồng',
      render: (data: IContractOnline) => <div>{ConvertNameFeature(data?.feature)}</div>
    },
    {
      title: 'SUP',
      width: 50,
      render: (data: IContractOnline) => <div>{data?.source}</div>
    },
    {
      title: 'Tên người mua',
      render: (data: IContractOnline) => <strong>{data?.buyer?.name.toLocaleUpperCase()}</strong>
    },
    {
      title: 'Số CMND/CCCD',
      render: (data: IContractOnline) => <div>{data?.buyer?.idCardNumber}</div>
    },
    {
      title: 'Số điện thoại',
      render: (data: IContractOnline) => <div>{data?.buyer?.phone}</div>
    },
    {
      title: 'Địa chỉ',
      render: (data: IContractOnline) => <div>{data?.buyer?.address}</div>
    },
    {
      title: "",
      key: "action",
      render: (data: IContractOnline) => {
        const actions: { lable: string; onClick: () => void }[] = [
          {
            lable: "Chi tiết hợp đồng",
            onClick: () => {
              LazyGetContractOnlineDetail(data.id);
              LazyGetTransactionDetail(data.transactionId);
              LazyGetContractOnlineLogs(data.id);
              setSelectedContract(data);
              setIsModalOpen(true)
            },
          }
        ].filter(Boolean) as any;

        const content = () => (
          <div>
            {actions.map((item) => (
              <FlexBox
                key={item.lable}
                style={{
                  cursor: "pointer",
                  padding: "12px 8px",
                  borderBottom: "1px solid rgba(0,0,0,0.1)",
                }}
                onClick={item.onClick}
              >
                <Typography>{item.lable}</Typography>
              </FlexBox>
            ))}
          </div>
        );
        return (
          <Space size="middle">
            <Popover content={content} trigger="click">
              <Button icon={<MoreOutlined />} />
            </Popover>
          </Space>
        );
      },
    }
  ];

  const columnsInsurancePackage = [
    {
      title: 'LOẠI HỢP ĐỒNG',
      render: (data: any) => <div>{ConvertNameFeature(data?.feature)}</div>
    },
    {
      title: 'NHÀ CUNG CẤP',
      render: (data: any) => <div>{data?.source}</div>
    },
    {
      title: 'PHÍ THANH TOÁN',
      render: (data: any) => <div>{data?.fee?.toLocaleString('vi-VN', {
        style: 'currency',
        currency: 'VND',
      })}</div>
    },
  ];

  const columnsTransaction = [
    {
      title: 'Trạng thái',
      render: (data: any) => {
        if (data?.status === 'PENDING') {
          return <Tag color={'orange'}>CHƯA THANH TOÁN</Tag>
        } else if (data?.status === 'SUCCESS') {
          return <Tag color={'#00e300'}>ĐÃ THANH TOÁN</Tag>
        }
      }
    },
    {
      title: 'Ngày giao dịch',
      render: (data: any) => <div>{moment(data?.createdAt).format(FORMAT_DATE)}</div>
    },
    {
      title: 'Mã giao dịch',
      render: (data: any) => <Paragraph copyable={{ text: data?.id }}>{data?.id}</Paragraph>
    },
    {
      title: 'Ngân hàng',
      render: (data: any) => <div>{data?.bank}</div>
    },
    {
      title: 'Số tài khoản',
      render: (data: any) => <div>{data?.accountNumber}</div>
    },
    {
      title: 'Số tiền',
      render: (data: any) => <div>{data?.amount?.toLocaleString('vi-VN', {
        style: 'currency',
        currency: 'VND',
      })}</div>
    },
    {
      title: 'Mã hóa đơn',
      render: (data: any) => <div>{data?.billId}</div>
    },
  ];

  const columnsPaymentIPN = [
    {
      title: 'Thời gian xử lý',
      render: (data: any) => <div>{moment(data?.createdTime).format(FORMAT_DATE)}</div>
    },
    {
      title: 'Mã đơn hàng',
      render: (data: any) => <div>{data?.tnxId}</div>
    },
    {
      title: 'Cổng thanh toán',
      render: (data: any) => <div>{data?.provider}</div>
    }
  ];

  const expandedRowRenderIPN = (record: IPNLogsOnline) => {
    const columnsPaymentIPNExpand = [
      {
        title: 'IPN Callback',
        key: 'callback',
        render: (data: any) => <Text code style={{ display: "block", width: '50vw', textAlign: 'left' }}>{data?.callback}</Text>
      },
      {
        title: 'IPN Response',
        key: 'response',
        render: (data: any) => <Text code style={{ display: "block", width: '25vw', textAlign: 'left' }}>{data?.response}</Text>
      },
    ];

    return <Table columns={columnsPaymentIPNExpand} dataSource={[{ callback: record?.callback, response: record?.response }]} />
  }

  const getStageName = (stage: EInsuranceWorkflowStage) => {
    switch (stage) {
      case EInsuranceWorkflowStage.AWAITING_PAYMENT:
        return "Chờ thanh toán";
      case EInsuranceWorkflowStage.PENDING:
        return "Chờ xử lý";
      case EInsuranceWorkflowStage.ERROR:
        return "Lỗi";
      case EInsuranceWorkflowStage.SUCCESSFUL:
        return "Đã gửi hợp đồng";
    }
  };

  const getGender = (gender: string) => {
    if (gender === 'MALE') {
      return 'Nam';
    } else if (gender === 'FEMALE') {
      return 'Nữ';
    } else {
      return 'Chưa biết';
    }
  };

  const arrFilter = [
    {
      id: 'stage',
      label: 'Trạng thái',
      options: ARR_INSURANCE_STAGE,
      showItem: true,
      placeholder: 'Chọn trạng thái'
    },
    {
      id: 'source',
      label: 'Nhà cung cấp',
      options: ARR_INSURANCE_SOURCE,
      showItem: true,
      placeholder: 'Chọn Loại bảo hiểm'
    },
    {
      id: 'feature',
      label: 'Loại hợp đồng',
      options: ARR_INSURANCE_FEATURE,
      showItem: true,
      placeholder: 'Chọn loại hợp đồng'
    },
  ].filter((item) => item.showItem)
  useEffect(() => {
    LazyGetContractOnline(removeNullValues(INSURANCE_ONLINE_PARAMS_FILTER))
  }, [])

  return (
    <div>
      <Modal
        width={'90%'}
        cancelText={'Thoát'}
        title={'Chi tiết hợp đồng'}
        centered
        visible={isModalOpen}
        okButtonProps={{ style: { display: 'none' } }}
        onCancel={() => {
          setIsModalOpen(false);
          setActiveTab("1");
        }}>
        <Descriptions title="Thông tin chung" column={isMobile ? 1 : 3} style={{ padding: 10 }}>
          <Descriptions.Item label="Mã hợp đồng">
            <Paragraph copyable={{ text: currentContract?.id }}>{currentContract?.id}</Paragraph>
          </Descriptions.Item>
          <Descriptions.Item label="Mã người tạo hợp đồng">
            <Paragraph copyable={{ text: contractDetailData?.createdUser?.id }}>{contractDetailData?.createdUser?.id}</Paragraph>
          </Descriptions.Item>
          <Descriptions.Item label="Mã người giới thiệu">
            {

              currentContract?.referrer?.id && <Paragraph copyable={{ text: currentContract?.referrer?.id }}>{currentContract?.referrer?.id}</Paragraph>
              || !currentContract?.referrer?.id && <strong>Không có</strong>
            }
          </Descriptions.Item>
          <Descriptions.Item label="Trạng thái hợp đồng">
            {
              (currentContract?.stage === EInsuranceWorkflowStage.AWAITING_PAYMENT && <Tag color={'orange'}>{getStageName(currentContract?.stage)}</Tag>)
              || (currentContract?.stage === EInsuranceWorkflowStage.PENDING && <Tag color={'#00a3ff'}>{getStageName(currentContract?.stage)}</Tag>)
              || (currentContract?.stage === EInsuranceWorkflowStage.ERROR && <Tag color={'red'}>{getStageName(currentContract?.stage)}</Tag>)
              || (currentContract?.stage === EInsuranceWorkflowStage.SUCCESSFUL && <Tag color={'#00e300'}>{getStageName(currentContract?.stage)}</Tag>)
            }
          </Descriptions.Item>
          <Descriptions.Item label="Người tạo hợp đồng"><strong><Avatar src={contractDetailData?.createdUser?.avatar} /> {contractDetailData?.createdUser?.name}</strong></Descriptions.Item>
          <Descriptions.Item label="Người giới thiệu"><strong>{currentContract?.referrer?.name || 'Không có'}</strong></Descriptions.Item>
          <Descriptions.Item label="Ngày tạo">{moment(currentContract?.createdAt).format(FORMAT_DATE)}</Descriptions.Item>
          <Descriptions.Item label="Vai trò">
            {mapRolesToStrings(contractDetailData?.createdUser?.roles)}
          </Descriptions.Item>
          <Descriptions.Item label="File hợp đồng">
            {
              contractDetailData?.policy?.url && <Paragraph copyable={{ text: contractDetailData?.policy?.url }}>
                <a href={contractDetailData?.policy?.url}>{contractDetailData?.policy?.url || 'Không tồn tại'}</a>
              </Paragraph>
              || !contractDetailData?.policy?.url && <strong>Không tồn tại</strong>
            }
          </Descriptions.Item>
        </Descriptions>
        <Divider dashed />
        <StyledTabs activeKey={activeTab} onChange={(callback) => setActiveTab(callback)}>
          <Tabs.TabPane tab="THÔNG TIN NGƯỜI MUA" key="1">
            <Descriptions column={isMobile ? 1 : 3} style={{ padding: 10 }}>
              <Descriptions.Item label="Tên người mua"><strong>{contractDetailData?.personInformation?.name?.toLocaleUpperCase()}</strong></Descriptions.Item>
              <Descriptions.Item label="Số CMND/CCCD">
                {
                  contractDetailData?.personInformation?.idCardNumber
                  && <Paragraph copyable={{ text: contractDetailData?.personInformation?.idCardNumber }}>{contractDetailData?.personInformation?.idCardNumber}</Paragraph>
                  || 'Chưa cung cấp'
                }
              </Descriptions.Item>
              <Descriptions.Item label="Số điện thoại">
                {
                  contractDetailData?.personInformation?.phone && <Paragraph copyable={{ text: contractDetailData?.personInformation?.phone }}>{contractDetailData?.personInformation?.phone}</Paragraph>
                  || 'Chưa cung cấp'
                }
              </Descriptions.Item>
              <Descriptions.Item label="Ngày sinh">
                {contractDetailData?.personInformation?.birthday && moment(contractDetailData?.personInformation?.birthday).format(FORMAT_DATE_WITHOUT_HOUR) || 'Chưa cung cấp'}
              </Descriptions.Item>
              <Descriptions.Item label="Giới tính">
                {contractDetailData?.personInformation?.gender && getGender(contractDetailData?.personInformation?.gender) || 'Chưa cung cấp'}
              </Descriptions.Item>
              <Descriptions.Item label="Email">
                {
                  contractDetailData?.personInformation?.email?.text && <Paragraph copyable={{ text: contractDetailData?.personInformation?.email?.text }}>{contractDetailData?.personInformation?.email?.text}</Paragraph>
                  || contractDetailData?.personInformation?.email && <Paragraph copyable={{ text: contractDetailData?.personInformation?.email }}>{contractDetailData?.personInformation?.email}</Paragraph>
                  || 'Chưa cung cấp'
                }
              </Descriptions.Item>
              <Descriptions.Item label="Địa chỉ thường trú">{contractDetailData?.personInformation?.address}</Descriptions.Item>
            </Descriptions>
          </Tabs.TabPane>
          <Tabs.TabPane tab="THÔNG TIN GÓI BẢO HIỂM" key="2">
            <Table pagination={false}
              columns={columnsInsurancePackage}
              dataSource={[{ ...contractDetailData?.productPackage }]}
              style={{ padding: 10 }}
            />
          </Tabs.TabPane>
          <Tabs.TabPane tab="ĐỐI TƯỢNG BẢO HIỂM" key="3">
            <div style={{ padding: 10 }}>
              <CItemContractDetailData contractDetailData={contractDetailData} />
            </div>
          </Tabs.TabPane>
          <Tabs.TabPane tab="THANH TOÁN" key="4">
            <div style={{ padding: 10 }}>
              <Table pagination={false}
                columns={columnsTransaction}
                dataSource={[{ ...transactionDetail }]}
              />
              <br />
              <h3>QR Gen Logs</h3>
              {transactionDetail?.rawData &&
                <Paragraph copyable={{ text: JSON.stringify(transactionDetail?.rawData, null, 2) }}>
                  <Text code>{JSON.stringify(transactionDetail?.rawData, null, 2)}</Text>
                </Paragraph>}
            </div>
          </Tabs.TabPane>
          <Tabs.TabPane tab="LOGS TÍCH HỢP" key="5">
            <Title level={5}>Logs tích hợp cổng thanh toán</Title>
            <div style={{ display: "block" }}>
              <Table pagination={false}
                expandable={{
                  defaultExpandedRowKeys: ['0'],
                  expandedRowRender: expandedRowRenderIPN
                }}
                columns={columnsPaymentIPN}
                dataSource={contractLogs?.ipnLogs.map((v, k) => {
                  return { ...v, key: k.toString() };
                })}
                size="small"
              />
            </div>
            <Divider dashed={true} />
            <div style={{
              display: "flex"
            }}>
              <div style={{ width: '50%' }}>
                <Title level={5}>Logs tạo hợp đồng</Title>
                {contractLogs?.logs?.request && <Paragraph
                  copyable={{ text: JSON.stringify(contractLogs?.logs?.request, null, 2) }}>
                  <div style={{
                    whiteSpace: "pre-wrap",
                    overflowX: "auto",
                    minHeight: 300,
                    maxHeight: 300,
                    margin: '0 1em',
                    padding: '0.2em 0.4em 0.1em',
                    fontSize: '85%',
                    color: '#00ff00',
                    background: '#1d1d1d',
                    borderRadius: 4,
                  }}>{JSON.stringify(contractLogs?.logs?.request, null, 2)}</div>
                </Paragraph>}
              </div>
              <div style={{ width: '50%' }}>
                <Title level={5}>Logs phản hồi</Title>
                {contractLogs?.logs?.response && <Paragraph
                  copyable={{ text: JSON.stringify(contractLogs?.logs?.response, null, 2) }}>
                  <div style={{
                    whiteSpace: "pre-wrap",
                    overflowX: "auto",
                    minHeight: 300,
                    maxHeight: 300,
                    margin: '0 1em',
                    padding: '0.2em 0.4em 0.1em',
                    fontSize: '85%',
                    color: '#00ff00',
                    background: '#1d1d1d',
                    borderRadius: 4,
                  }}>{JSON.stringify(contractLogs?.logs?.response, null, 2)}</div>
                </Paragraph>}
              </div>
            </div>
          </Tabs.TabPane>
        </StyledTabs>
      </Modal>
      <Form
        initialValues={INSURANCE_ONLINE_PARAMS_FILTER}
        layout={'vertical'}
        form={formFilter}
      >
        <Row gutter={[12, 12]}>
          <Col xs={24} lg={4} xl={4}>
            <Form.Item
              getValueProps={(i) => ({ value: (i?.trimStart()) })}
              name={'insuranceId'}
              label="Mã hợp đồng">
              <CustomInput
                placeholder="Nhập mã hợp đồng" />
            </Form.Item>
          </Col>
          <Col xs={24} lg={4} xl={4}>
            <Form.Item
              getValueProps={(i) => ({ value: (i?.trimStart()) })}
              name={'buyerId'}
              label="Mã người mua">
              <CustomInput
                placeholder="Nhập mã người mua" />
            </Form.Item>
          </Col>
          <Col xs={24} lg={4} xl={4}>
            <Form.Item
              getValueProps={(i) => ({ value: (i?.trimStart()) })}
              name={'buyerName'}
              label="Tên người mua">
              <CustomInput
                placeholder="Nhập tên người mua" />
            </Form.Item>
          </Col>
          <Col xs={24} lg={4} xl={4}>
            <Form.Item
              getValueProps={(i) => ({ value: (i?.trimStart()) })}
              name={'idCardNumber'}
              label="Số CMND/CCCD">
              <CustomInput
                placeholder="Nhập số CMND/CCCD" />
            </Form.Item>
          </Col>
          <Col xs={24} lg={4} xl={4}>
            <Form.Item
              getValueProps={(i) => ({ value: (i?.trimStart()) })}
              name={'phone'}
              label="Số điện thoại nhận">
              <CustomInput
                placeholder="Số điện thoại nhận hợp đồng" />
            </Form.Item>
          </Col>
          {
            arrFilter.map((itemMap, key) => <Col key={itemMap.id + key} xs={24} lg={4} xl={4}>
              <Form.Item
                getValueProps={(i) => ({ value: (i?.trimStart()) })}
                name={itemMap.id}
                label={itemMap.label}>
                <CustomSelect
                  {
                  ...itemMap
                  }
                  formInsert={formFilter}
                  id={itemMap.id}
                  options={itemMap.options}
                />
              </Form.Item>
            </Col>)
          }
          <Col xs={24} lg={4} xl={4}>
            <Form.Item
              label={'Ngày giao dịch'}>
              <CustomDateRangePicker
                startDate={paramsFilterDate.from}
                endDate={paramsFilterDate.to}
                onChange={(from, to) => {
                  setParamsFilterDate({
                    ...paramsFilter,
                    from: moment(from).toISOString(true),
                    to: moment(to).toISOString(true)
                  })
                }}
              />
            </Form.Item>
          </Col>
          <Col xs={24} lg={4} xl={4}>
            <Form.Item label=" ">
              <Button onClick={() => {
                formFilter.setFieldsValue({
                  page: DEFAULT_PAGE_START,
                })
                LazyGetContractOnline(removeNullValues(paramsFilter))
              }} type="primary">Tìm kiếm</Button>
              <Button
                className='ml-12'
                onClick={() => {
                  formFilter.resetFields();
                  setParamsFilterDate({
                    from: INSURANCE_ONLINE_PARAMS_FILTER.from,
                    to: INSURANCE_ONLINE_PARAMS_FILTER.to,
                  })
                  LazyGetContractOnline(removeNullValues(INSURANCE_ONLINE_PARAMS_FILTER))
                }}>Đặt lại</Button>
            </Form.Item>
          </Col>
        </Row>
      </Form>
      <div className='pd-24' style={{ background: 'white', }}>
        <div className={`d-flex  ${isMobile ? 'flex-column' : 'align-item-center flex-row'}`}>
          <h3 className='flex-1'>Danh sách hợp đồng online</h3>
        </div>
        <Divider />
        <CustomTable
          columns={columns}
          totalDocs={data?.totalDocs || 0}
          data={data?.docs?.map((itemMap, key) => {
            return {
              ...itemMap,
              key: key + itemMap.id
            }
          }) || []}
          isLoading={false}
          onChange={(page, limit) => {
            if (paramsFilter.limit === limit) {
              formFilter.setFieldsValue({
                page,
              })
            } else {
              formFilter.setFieldsValue({
                page: DEFAULT_PAGE_START,
              })
            }
            const params = {
              ...paramsFilter,
              limit,
              page
            }
            formFilter.setFieldsValue({
              limit,
            })

            LazyGetContractOnline(removeNullValues(params))
            window.scrollTo(0, 0);
          }}
          pageSize={limit}
          pageCurrent={page}
        />
      </div>
    </div>
  );
};
export default PolicyList;

const StyledTabs = styled(Tabs)`
  width: 100%;

  .ant-tabs-nav::before {
    border: unset;
  }
  .ant-tabs-tab.ant-tabs-tab-active .ant-tabs-tab-btn {
    color: black;
    font-weight: 300;
  }
`;
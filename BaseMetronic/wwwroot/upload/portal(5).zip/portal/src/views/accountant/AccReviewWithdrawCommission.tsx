import {
  Button,
  Form,
  message,
  Modal,
  ModalProps,
  Popover,
  Space,
  Spin,
  Table,
  Typography,
} from "antd";
import { ColumnsType } from "antd/lib/table";
import { EWithdrawTransactionStatus } from "enums/payment.enum";
import { IWithdrawTransaction } from "interfaces/payment.interface";
import React, { useEffect, useState } from "react";
import moment from "moment";
import {
  useGetWithdrawCommissionRequestQuery,
  useAccUpdateWithdrawCommissionRequestMutation,
} from "store/APIs/referrer";
import { DEFAULT_PAGE_SIZE } from "src/constants";
import { FlexBox } from "src/common/FlexBox";
import { MoreOutlined, UploadOutlined } from "@ant-design/icons";
import useFormatter from "src/hooks/useFormatter";
import { WithdrawCommissionStatusNextStepName } from "src/utils/name";
import TextArea from "antd/lib/input/TextArea";
import CustomUpload from "src/common/CustomUpload";
import { get } from "lodash";

const AccReviewWithdrawCommission = ({
  status,
}: {
  status: EWithdrawTransactionStatus;
}) => {
  const [form] = Form.useForm();
  const [modalProps, setmodalProps] = useState<
    ModalProps & { status?: EWithdrawTransactionStatus; transactionId?: string }
  >({
    visible: false,
  });
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(DEFAULT_PAGE_SIZE);
  const { data, isLoading } = useGetWithdrawCommissionRequestQuery({
    page,
    limit: pageSize,
    status,
  });
  const [
    accUpdateWithdrawCommissionRequestMutation,
    {
      isLoading: isAccConfirmLoading,
      isSuccess: isAccConfirmSuccess,
      isError: isAccConfirmError,
    },
  ] = useAccUpdateWithdrawCommissionRequestMutation();

  const { formatter } = useFormatter();

  const columns: ColumnsType<IWithdrawTransaction> = [
    {
      title: "Mã giao dịch",
      dataIndex: "id",
      key: "id",
      render: (text) => <Typography>{text}</Typography>,
    },

    {
      title: "Họ tên",
      dataIndex: "userDetails.fullName",
      key: "userDetails.fullName",
      render: (_text, record: any) => (
        <Typography>{get(record, "userDetails.fullName")}</Typography>
      ),
    },

    {
      title: "Số tiền",
      dataIndex: "totalAmount",
      key: "totalAmount",
      render: (totalAmount) => (
        <Typography>{formatter.format(totalAmount)}</Typography>
      ),
    },

    {
      title: "Trạng thái",
      dataIndex: "status",
      key: "status",
      render: (status: EWithdrawTransactionStatus) => {
        return WithdrawCommissionStatusNextStepName[status];
      },
    },
    {
      title: "Khởi tạo lúc",
      dataIndex: "createdAt",
      key: "createdAt",
      render: (createdAt: string) =>
        moment(createdAt).format("DD/MM/YYYY  HH:mm"),
    },
    {
      title: "Cập nhật lần cuối lúc",
      dataIndex: "updatedAt",
      key: "updatedAt",
      render: (updatedAt: string) =>
        moment(updatedAt).format("DD/MM/YYYY HH:mm"),
    },
    {
      title: "Dữ liệu gửi duyệt (sheet)",
      dataIndex: "submitFileUrl",
      key: "submitFileUrl",
      render: (submitFileUrl) => (
        // eslint-disable-next-line react/jsx-no-target-blank
        <a target="_blank" href={submitFileUrl}>
          Tải xuống
        </a>
      ),
    },

    {
      title: "Dữ liệu đối soát (sheet)",
      dataIndex: "csFileUrl",
      key: "csFileUrl",
      render: (accountantFileUrl) =>
        accountantFileUrl ? (
          // eslint-disable-next-line react/jsx-no-target-blank
          <a target="_blank" href={accountantFileUrl}>
            Tải xuống
          </a>
        ) : null,
    },

    {
      title: "Note (nội bộ)",
      dataIndex: "notes",
      key: "notes",
      render: (notes: string[]) => {
        return (
          <Typography.Paragraph style={{ whiteSpace: "pre-wrap" }}>
            {(notes || []).join("\n")}
          </Typography.Paragraph>
        );
      },
    },
    {
      title: "",
      dataIndex: "action",
      key: "action",
      render: (_: string, record: IWithdrawTransaction) => {
        if (![EWithdrawTransactionStatus.CS_ACCEPTED].includes(record.status))
          return;
        const actions: { lable: string; onClick: () => void }[] = [
          record.status === EWithdrawTransactionStatus.CS_ACCEPTED && {
            lable: "Xác nhận đã thanh toán",
            onClick: () => {
              setmodalProps({
                status: EWithdrawTransactionStatus.ACCOUNTANT_PAID,
                title: "Xác nhận - Đã thanh toán",
                visible: true,
                transactionId: record.id,
              });
            },
          },
        ].filter(Boolean) as any;

        const content = () => (
          <div>
            {actions.map((item) => (
              <FlexBox
                key={item.lable}
                style={{
                  cursor: "pointer",
                  padding: "12px 8px",
                  borderBottom: "1px solid rgba(0,0,0,0.1)",
                }}
                onClick={item.onClick}
              >
                <Typography>{item.lable}</Typography>
              </FlexBox>
            ))}
          </div>
        );

        if (!actions.length) return null;
        return (
          <Space size="middle">
            <Popover
              content={content}
              title=""
              trigger="click"
              placement="left"
            >
              <Button
                icon={<MoreOutlined />}
                loading={isAccConfirmLoading || isLoading}
              ></Button>
            </Popover>
          </Space>
        );
      },
    },
  ];

  useEffect(() => {
    if (isAccConfirmLoading) return;
    if (isAccConfirmSuccess) {
      message.success("Đã cập nhật");
    }
    if (isAccConfirmError) {
      message.error("Có lỗi xảy ra! vui lòng thử lại hoặc liên hệ IT");
    }
    setmodalProps({ visible: false });
  }, [isAccConfirmSuccess, isAccConfirmError, isAccConfirmLoading]);

  if (isLoading) return <Spin />;
  return (
    <>
      <Modal
        onOk={() => {
          if (!modalProps.transactionId || !modalProps.status) return;
          accUpdateWithdrawCommissionRequestMutation({
            status: modalProps.status,
            transactionId: modalProps.transactionId,
            accountantFileUrl:
              form.getFieldValue("accountantFileUrl")?.file.response,
            note: form.getFieldValue("note"),
          });
          form.resetFields();
        }}
        onCancel={() => {
          setmodalProps({ visible: false });
          form.resetFields();
        }}
        cancelText="Đóng"
        okText="Xác nhận"
        okButtonProps={{
          loading: isAccConfirmLoading,
        }}
        cancelButtonProps={{
          loading: isAccConfirmLoading,
        }}
        {...modalProps}
        width={800}
      >
        <>
          <Form
            form={form}
            name="basic"
            labelCol={{ span: 24 }}
            wrapperCol={{ span: 24 }}
            style={{ maxWidth: 1000, width: "100%" }}
            // onFinishFailed={onFinishFailed}

            autoComplete="off"
          >
            <Form.Item label="Note - nội bộ" name="note">
              <TextArea rows={5} />
            </Form.Item>

            <Form.Item
              label="File (thông tin giao dịch)"
              name="accountantFileUrl"
            >
              <CustomUpload>
                <Button icon={<UploadOutlined />}>
                  Tải lên bằng chứng giao dịch
                </Button>
              </CustomUpload>
            </Form.Item>
          </Form>
        </>
      </Modal>
      <Table
        loading={isLoading}
        columns={columns}
        dataSource={data?.docs}
        scroll={{ x: 300 }}
        style={{ width: "100%" }}
        pagination={{
          pageSizeOptions: [15, 30, 60],
          showSizeChanger: true,
          pageSize: pageSize,
          total: data?.totalDocs || 0,
          onChange(page, pageSize) {
            setPage(page);
            setPageSize(pageSize);
          },
        }}
      />
    </>
  );
};

export default AccReviewWithdrawCommission;

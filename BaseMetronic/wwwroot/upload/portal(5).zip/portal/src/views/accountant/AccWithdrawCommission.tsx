import { Tabs } from "antd";
import { EWithdrawTransactionStatus } from "enums/payment.enum";
import React, { useState } from "react";
import { FlexBox } from "src/common/FlexBox";
import { WithdrawCommissionStatusNextStepName } from "src/utils/name";

import CSReviewWithdrawCommission from "./AccReviewWithdrawCommission";

const AccWithdrawCommission = () => {
  const [tab, settab] = useState(EWithdrawTransactionStatus.CS_ACCEPTED);

  return (
    <Tabs
      centered
      style={{ height: "100%" }}
      activeKey={tab}
      onChange={settab as any}
    >
      {[
        EWithdrawTransactionStatus.CS_ACCEPTED,
        EWithdrawTransactionStatus.ACCOUNTANT_PAID,
      ].map((key: EWithdrawTransactionStatus) => (
        <Tabs.TabPane tab={WithdrawCommissionStatusNextStepName[key]} key={key}>
          <FlexBox
            style={{
              alignItems: "center",
              flexDirection: "column",
              marginTop: 50,
            }}
          >
            <CSReviewWithdrawCommission status={key} />
          </FlexBox>
        </Tabs.TabPane>
      ))}
    </Tabs>
  );
};

export default AccWithdrawCommission;

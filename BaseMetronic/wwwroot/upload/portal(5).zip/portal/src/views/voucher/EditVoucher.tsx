import {
  Button,
  Form,
  Input,
  InputNumber,
  message,
  Spin,
  Typography,
} from "antd";
import TextArea from "antd/lib/input/TextArea";
import { IVoucher } from "interfaces/referrer.interface";
import { omit } from "lodash";
import { useRouter } from "next/router";
import React, { useEffect, useState } from "react";
import { Box } from "src/common/Box";
import CustomDateRangePicker from "src/common/CustomDateRangePicker";
import { FlexBox } from "src/common/FlexBox";
import { RoutePath } from "src/layout/Sider";
import {
  useGetVoucherQuery,
  useUpdateAndSubmitVoucherMutation,
  useUpdateVoucherMutation,
} from "store/APIs/referrer";
import styled from "styled-components";

const EditVoucher = () => {
  const router = useRouter();
  const { voucherId } = router.query;

  const [currentVoucher, setcurrentVoucher] = useState<IVoucher | undefined>();

  const { data: voucher, isLoading } = useGetVoucherQuery(
    { id: String(voucherId) },
    { skip: !voucherId }
  );

  const [
    updateVoucherMutation,
    {
      isLoading: isUpdateLoading,
      isSuccess: isUpdateSuccess,
      isError: isUpdateError,
    },
  ] = useUpdateVoucherMutation();
  const [
    updateAndSubmitVoucherMutation,
    {
      isLoading: isSubmitLoading,
      isSuccess: isSubmitSuccess,
      isError: isSubmitError,
    },
  ] = useUpdateAndSubmitVoucherMutation();

  useEffect(() => {
    if (voucher) {
      setcurrentVoucher(omit(voucher, ["_id"]) as IVoucher);
    }
  }, [voucher]);

  useEffect(() => {
    if (isSubmitSuccess) {
      message.success("Đã gửi duyệt");
      router.push(RoutePath.VOUCHER);
    }
  }, [isSubmitSuccess, router]);

  useEffect(() => {
    if (isUpdateSuccess) {
      message.success("Đã cập nhật");
    }
  }, [isUpdateSuccess, router]);

  useEffect(() => {
    if (isUpdateError || isSubmitError) {
      message.error("Mã giảm giá đã tồn tại");
    }
  }, [isUpdateError, isSubmitError]);

  if (!currentVoucher || isLoading) return <Spin size="large" />;
  return (
    <div>
      <FlexBox style={{ justifyContent: "flex-end", marginBottom: 16 }}>
        <Button
          loading={isUpdateLoading}
          onClick={() => updateVoucherMutation(currentVoucher)}
        >
          Lưu nháp
        </Button>
        <Button
          loading={isSubmitLoading}
          type="primary"
          style={{ marginLeft: 20 }}
          onClick={() => updateAndSubmitVoucherMutation(currentVoucher)}
        >
          Lưu và Gửi duyệt
        </Button>
      </FlexBox>
      <Box style={{ background: "white", borderRadius: 8, padding: 12 }}>
        <StyledLabel>Tên kế hoạch:</StyledLabel>
        <StyledInput
          placeholder="Tên"
          value={currentVoucher.planName}
          onChange={(e) =>
            setcurrentVoucher({
              ...currentVoucher,
              planName: e.target.value,
            })
          }
        />
        <StyledLabel>Mô tả chi tiết:</StyledLabel>
        <TextArea
          rows={6}
          placeholder="Mô tả"
          style={{
            borderRadius: 8,
          }}
          value={currentVoucher.description}
          onChange={(e) =>
            setcurrentVoucher({
              ...currentVoucher,
              description: e.target.value,
            })
          }
        />
        <Form.Item label="Mã giảm giá" style={{ marginTop: 16 }}>
          <StyledInput
            placeholder="Mã giảm giá (code)"
            value={currentVoucher.code}
            style={{ color: "red" }}
            onChange={(e) =>
              setcurrentVoucher({
                ...currentVoucher,
                code: e.target.value.toUpperCase(),
              })
            }
          />
        </Form.Item>
        <Form.Item label="Giá trị" style={{ marginTop: 16 }}>
          <InputNumber
            style={{ width: 200 }}
            addonAfter="VND"
            value={currentVoucher.value}
            // formatter={(value) =>
            //   `${numberFormatter.format(
            //     Number(String(value).replace(/[^(0-9.)]/g, ""))
            //   )}`
            // }
            // parser={(value) => {
            //   return Number(String(value).replace(/[^(0-9.)]/g, ""));
            // }}
            onChange={(val) =>
              setcurrentVoucher({
                ...currentVoucher,
                value: Number(val),
              })
            }
          />
        </Form.Item>
        <Form.Item label="Số lượng mã" style={{ marginTop: 16 }}>
          <InputNumber
            value={currentVoucher.qty}
            onChange={(val) =>
              setcurrentVoucher({
                ...currentVoucher,
                qty: val,
                remainingQty: val,
              })
            }
          />
        </Form.Item>

        <StyledLabel>Thời gian hoạt động:</StyledLabel>
        <CustomDateRangePicker
          onChange={(startDate, endDate) =>
            setcurrentVoucher({
              ...currentVoucher,
              startDate: new Date(startDate || currentVoucher.startDate),
              endDate: new Date(endDate || currentVoucher.endDate),
            })
          }
          startDate={currentVoucher.startDate}
          endDate={currentVoucher.endDate}
        />
      </Box>
    </div>
  );
};

const StyledInput = styled(Input)`
  border: unset;
  border-bottom: 1px solid lightgray;
  margin-bottom: 16px;
  display: block;
`;

const StyledLabel = styled(Typography)`
  margin-top: 16px;
`;

export default EditVoucher;

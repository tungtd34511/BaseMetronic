import { Spin } from "antd";
import { ReportResponse } from "interfaces/global.interface";
import { IReferrerAccessLogReport } from "interfaces/referrer.interface";
import React from "react";
import {
  Legend,
  LineChart,
  ResponsiveContainer,
  XAxis,
  YAxis,
  Tooltip,
  Line,
} from "recharts";
import { Box } from "src/common/Box";

type Props = {
  data?: ReportResponse<IReferrerAccessLogReport>;
  isLoading: boolean;
};

const AccessLogReport = ({ data, isLoading }: Props) => {
  if (isLoading) return <Spin size="large" />;
  return (
    <Box
      style={{
        height: 400,
        width: "100%",
        margin: "30px 0",
        background: "white",
        borderRadius: 10,
      }}
    >
      <ResponsiveContainer width="100%" height="100%">
        <LineChart
          data={data?.docs}
          margin={{
            top: 30,
            right: 30,
            left: 30,
            bottom: 10,
          }}
        >
          <XAxis dataKey="date" />
          <YAxis />
          <Tooltip
            formatter={(value: number, field: string, props: any) => {
              const fieldName: { [key: string]: string } = {
                accessCount: "Lượt truy cập đường dẫn chia sẻ",
                createCount: "Lượt tạo bảo hiểm (đã + chưa thanh toán)",
                paidCount: "Lượt giới thanh toán bảo hiểm",
                successCount: "Lượt phát hành bảo hiểm",
              };
              return [value, fieldName[field], props];
            }}
          />
          <Legend
            formatter={(field: string) => {
              const fieldName: { [key: string]: string } = {
                accessCount: "Lượt truy cập đường dẫn chia sẻ",
                createCount: "Lượt tạo bảo hiểm (đã + chưa thanh toán)",
                paidCount: "Lượt giới thanh toán bảo hiểm",
                successCount: "Lượt phát hành bảo hiểm",
              };
              return fieldName[field];
            }}
          />
          <Line type="monotone" dataKey="accessCount" stroke="rgb(0 65 168)" />
          <Line type="monotone" dataKey="createCount" stroke="rgb(0 168 0)" />
          <Line type="monotone" dataKey="paidCount" stroke="#b21616" />
          <Line
            type="monotone"
            dataKey="successCount"
            stroke="rgb(204 178 0)"
          />
        </LineChart>
      </ResponsiveContainer>
    </Box>
  );
};

export default AccessLogReport;

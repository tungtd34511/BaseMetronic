import { Col, Row, Typography } from "antd";
import React from "react";

type Props = {
  items: {
    title: string;
    value: string | number;
    icon: React.ReactNode;
    hiddenItem?:boolean
  }[];
  size?: number;
};

const Metric = ({ items, size = 3 }: Props) => {
  return (
    <Row style={{ width: "100%" }}>
      {items.map((item) => (
        <Col
          span={24}
          sm={24}
          md={24 / size}
          key={item.title}
          style={{ padding: "0 2%" }}
        >
          <div
            style={{
              boxShadow: "0 5px 10px rgba(0,0,0,0.1)",
              padding: 20,
              marginTop: 20,
              borderRadius: 20,
              background: "white",
            }}
          >
            <Typography.Title
              level={5}
              style={{ fontSize: 24, textAlign: "right" }}
            >
              {item.value}
            </Typography.Title>
            <Typography
              style={{
                textAlign: "right",
                color: "rgba(0,0,0,0.5)",
                fontSize: 12,
              }}
            >
              {item.icon} {` `} {item.title}
            </Typography>
          </div>
        </Col>
      ))}
    </Row>
  );
};

export default Metric;

import { Spin } from "antd";
import { ReportResponse } from "interfaces/global.interface";
import { IReferrerCommissionLogReport } from "interfaces/referrer.interface";
import React from "react";
import {
  CartesianGrid,
  Legend,
  ResponsiveContainer,
  XAxis,
  YAxis,
  Tooltip,
  BarChart,
  Bar,
} from "recharts";
import { Box } from "src/common/Box";
import useFormatter from "src/hooks/useFormatter";

type Props = {
  isLoading: boolean;
  data?: ReportResponse<IReferrerCommissionLogReport>;
};

const CommissionLogReport = ({ data, isLoading }: Props) => {
  const { formatter } = useFormatter();
  if (isLoading) return <Spin size="large" />;
  return (
    <Box
      style={{
        height: 670,
        width: "100%",
        margin: "20px 0",
        background: "white",
        borderRadius: 10,
      }}
    >
      <ResponsiveContainer width="100%" height="100%">
        <BarChart
          data={data?.docs}
          margin={{
            top: 30,
            right: 30,
            left: 30,
            bottom: 10,
          }}
        >
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="date" />
          <YAxis />
          <Tooltip
            formatter={(value: number, field: string, props: any) => {
              const fieldName: { [key: string]: string } = {
                tax: "Thuế",
                originalAmount: "Hoa hồng tự giới thiệu",
                preCalcAmount: "Hoa hồng tạm tính",
                revenueCalcCommission: "Doanh thu",
                commissionFromAgent: "Hoa hồng từ đại lý cấp dưới",
                revenueCalcFromAgent: "Doanh thu đại lý cấp dưới",
              };
              return [formatter.format(value), fieldName[field], props];
            }}
          />
          <Legend
            formatter={(field: string) => {
              const fieldName: { [key: string]: string } = {
                tax: "Thuế",
                originalAmount: "Hoa hồng tự giới thiệu",
                preCalcAmount: "Hoa hồng tạm tính",
                revenueCalcCommission: "Doanh thu",
                commissionFromAgent: "Hoa hồng từ đại lý cấp dưới",
                revenueCalcFromAgent: "Doanh thu đại lý cấp dưới",
              };
              return fieldName[field];
            }}
          />
          <Bar
            dataKey="commissionFromAgent"
            stackId="commission"
            fill="#cf1322"
          />
          {/* <Bar
            dataKey="revenueCalcFromAgent"
            stackId="revenue"
            fill="#ff4d4f"
          /> */}
          <Bar dataKey="originalAmount" stackId="commission" fill="#0b7dd4" />
          {/* <Bar
            dataKey="revenueCalcCommission"
            stackId="revenue"
            fill="#0b7dd4"
          /> */}
        </BarChart>
      </ResponsiveContainer>
    </Box>
  );
};

export default CommissionLogReport;

import { Button, Col, Form, Input, message, Row, Spin, Typography } from "antd";
import { useRouter } from "next/router";
import React, { useEffect } from "react";
import { FlexBox } from "src/common/FlexBox";
import {
  useGetInsuranceQuery,
  useUpdateInsuranceMutation,
} from "store/APIs/insurance";

const CSUpdateInsuranceForm = () => {
  const [form] = Form.useForm();
  const router = useRouter();
  const { isLoading, data } = useGetInsuranceQuery(
    { insuranceId: String(router.query.insuranceId) },
    { skip: !router.query.insuranceId }
  );

  const [
    updateInsuranceMutation,
    { isLoading: isUpdateInsurance, isSuccess, error },
  ] = useUpdateInsuranceMutation();

  const onFinish = () => {
    updateInsuranceMutation({
      ...form.getFieldsValue(),
      insuranceId: String(router.query.insuranceId),
    });
  };

  useEffect(() => {
    if (isSuccess && !isLoading) {
      message.success("Cập nhật thành công");
      router.push("/cs/insurance");
    }
    if (error && !isLoading) {
      console.error(error);
      message.error("Có lỗi xảy ra, liên hệ IT để hỗ trợ");
    }
  }, [isSuccess, error]);

  useEffect(() => {
    if (data) {
      form.setFieldsValue(data.data);
    }
  }, [data]);

  if (isLoading || !data) return <Spin />;

  return (
    <div
      style={{
        background: "white",
        borderRadius: 6,
        padding: "10px 15px",
      }}
    >
      <Form
        form={form}
        name="basic"
        labelCol={{ span: 24 }}
        wrapperCol={{ span: 24 }}
        style={{ width: "100%" }}
        initialValues={{ remember: true }}
        onFinish={onFinish}
        // onFinishFailed={onFinishFailed}
        autoComplete="off"
      >
        <Row gutter={24}>
          <Col xl={8} md={24} style={{ padding: "0 12px", width: "100%" }}>
            <Form.Item
              label="Tên chủ xe"
              name="userName"
              rules={[{ required: true, message: "Không được để trống" }]}
            >
              <Input defaultValue={data.data.userName} />
            </Form.Item>
          </Col>
          <Col xl={8} md={24} style={{ padding: "0 12px", width: "100%" }}>
            <Form.Item
              label="Địa chỉ"
              name="userAddress"
              rules={[{ required: true, message: "Không được để trống" }]}
            >
              <Input defaultValue={data.data.userAddress} />
            </Form.Item>
          </Col>

          <Col xl={8} md={24} style={{ padding: "0 12px", width: "100%" }}>
            <Form.Item
              label="Biển số xe"
              name="licensePlates"
              rules={[{ required: true, message: "Không được để trống" }]}
            >
              <Input defaultValue={data.data.licensePlates} />
            </Form.Item>
          </Col>
        </Row>

        <FlexBox
          style={{
            alignItems: "center",
            flexDirection: "column",
          }}
        >
          <Button
            loading={isUpdateInsurance}
            type="primary"
            htmlType="submit"
            style={{ marginLeft: 12 }}
          >
            Lưu và cập nhật
          </Button>

          <Typography
            style={{ paddingTop: 10, color: "rgba(0,0,0,0.5)", fontSize: 12 }}
          >
            Hợp đồng cung cấp của PVI sẽ cập nhật sau khoảng 3 phút
          </Typography>

          <Typography
            style={{ paddingTop: 4, color: "rgba(0,0,0,0.5)", fontSize: 12 }}
          >
            Hợp đồng cung cấp của VBI sẽ cập nhật ngay
          </Typography>
        </FlexBox>
      </Form>
      <Typography style={{ paddingTop: 20 }}>
        Hợp đồng bảo hiểm cũ
        <Typography.Link
          href={data.callbackResponse?.url || data.callbackResponse?.URL}
          target={data.callbackResponse?.url || data.callbackResponse?.URL}
        >
          {` `}Mở trong tab mới
        </Typography.Link>
      </Typography>
      <iframe
        src={`${
          data.callbackResponse?.url || data.callbackResponse?.URL
        }#toolbar=0`}
        width="100%"
        height={500}
      />
    </div>
  );
};

export default CSUpdateInsuranceForm;

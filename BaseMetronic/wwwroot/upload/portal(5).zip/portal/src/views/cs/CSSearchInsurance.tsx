import { MoreOutlined } from "@ant-design/icons";
import { Button, Popover, Space, Table, Typography } from "antd";
import Search from "antd/lib/input/Search";
import { EInsuranceFeature } from "enums/insurance.enum";
import { IInsurance } from "interfaces/insurance.interface";
import React, { useEffect, useState } from "react";
import { FlexBox } from "src/common/FlexBox";
import { useLazySearchInsuranceQuery } from "store/APIs/insurance";

const CSSearchInsurance = () => {
  const [lazySearchInsuranceQuery, { isLoading, data }] =
    useLazySearchInsuranceQuery();

  const [licensePlates, setlicensePlates] = useState("");

  useEffect(() => {
    if (licensePlates)
      lazySearchInsuranceQuery({
        page: 1,
        limit: 100,
        licensePlates,
      });
  }, [licensePlates, lazySearchInsuranceQuery]);

  const columns = [
    {
      title: "Tên chủ xe",
      dataIndex: "data.userName",
      key: "userName",
      render: (_: any, record: IInsurance) => record.data?.userName,
    },
    {
      title: "Địa chỉ",
      dataIndex: "data.userAddress",
      key: "userAddress",
      render: (_: any, record: IInsurance) => record.data?.userAddress,
    },
    {
      title: "CMND/CCCD",
      dataIndex: "data.identityCardNum",
      key: "identityCardNum",
      render: (_: any, record: IInsurance) => record.data?.identityCardNum,
    },
    {
      title: "Bảo hiểm",
      dataIndex: "feature",
      key: "feature",
      render: (feature: EInsuranceFeature) => {
        switch (feature) {
          case EInsuranceFeature.AUTO_01:
            return "Ô tô";
          case EInsuranceFeature.MOTOR_01:
            return "Xe máy";
        }
      },
    },
    {
      title: "Biển số xe",
      dataIndex: "data.licensePlates",
      key: "identityCardNum",
      render: (_: any, record: IInsurance) => record.data?.licensePlates,
    },

    {
      title: "Số lần cập nhật",
      dataIndex: "updatedTime",
      key: "updatedTime",
      render: (updatedTime: number) => updatedTime || 0,
    },
    {
      title: "",
      key: "action",
      render: (_: string, record: IInsurance) => {
        const actions: { lable: string; onClick: () => void }[] = [
          {
            lable: "Chỉnh sửa & Tạo lại",
            onClick: () => {
              window.open(`/cs/insurance/${record.id}`);
            },
          },
          {
            lable: "Xem giấy chứng nhận",
            onClick: () =>
              window.open(
                record.callbackResponse.url || record.callbackResponse.URL
              ),
          },
        ];

        const content = () => (
          <div style={{ minWidth: 200 }}>
            {actions.map((item) => (
              <FlexBox
                key={item.lable}
                style={{
                  cursor: "pointer",
                  padding: "12px 8px",
                  borderBottom: "1px solid rgba(0,0,0,0.1)",
                }}
                onClick={item.onClick}
              >
                <Typography>{item.lable}</Typography>
              </FlexBox>
            ))}
          </div>
        );

        if (!actions.length) return null;
        return (
          <Space size="middle">
            <Popover content={content} title="" trigger="hover">
              <Button icon={<MoreOutlined />} />
            </Popover>
          </Space>
        );
      },
    },
  ];

  return (
    <div>
      <Search
        loading={isLoading}
        placeholder="Nhập biển số xe"
        onSearch={(val) => setlicensePlates(val)}
        style={{ width: 200, background: "white" }}
      />

      <Table dataSource={data?.docs || []} columns={columns} />
    </div>
  );
};

export default CSSearchInsurance;

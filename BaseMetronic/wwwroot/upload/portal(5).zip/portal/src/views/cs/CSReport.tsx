import { Button, Table } from "antd";
import { ColumnsType } from "antd/lib/table";
import { get } from "lodash";
import moment from "moment";
import React, { useState } from "react";
import CustomDateRangePicker from "src/common/CustomDateRangePicker";
import { FlexBox } from "src/common/FlexBox";
import { ACCESS_TOKEN_KEY, DEFAULT_PAGE_SIZE } from "src/constants";
import { useCsGetReportQuery } from "store/APIs/insurance";

const CSReport = () => {
  const [dateRange, setdateRange] = useState({
    from: moment().subtract(7, "days").valueOf(),
    to: moment().valueOf(),
  });

  const [pageSize, setPageSize] = useState(DEFAULT_PAGE_SIZE);
  const [page, setPage] = useState(1);

  const { data, isLoading } = useCsGetReportQuery({
    ...dateRange,
    limit: pageSize,
    page,
  });

  const download = () => {
    const headers = new Headers();
    try {
      const accessToken =
        typeof window !== "undefined"
          ? window.localStorage.getItem(ACCESS_TOKEN_KEY)
          : "";

      if (accessToken) {
        headers.set("authorization", `Bearer ${accessToken}`);
      }
    } catch (error) {
      console.error(error);
    }

    fetch(
      `${
        process.env.API_HOST
      }/api/cs/insurance/report/export?${new URLSearchParams(
        dateRange as any
      ).toString()}`,
      {
        headers,
      }
    )
      .then((response) => response.blob())
      .then((blob) => {
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = `report_${moment(dateRange.from).format(
          "DD/MM/YYYY"
        )}_${moment(dateRange.to).format("DD/MM/YYYY")}.xlsx`;
        document.body.appendChild(a); // we need to append the element to the dom -> otherwise it will not work in firefox
        a.click();
        a.remove(); //afterwards we remove the element again
      });
  };

  const columns: ColumnsType<any> = [
    {
      title: "Ngày",
      dataIndex: "createdAt",
      key: "createdAt",
      width: 200,
    },

    {
      title: "Nhà cung cấp",
      dataIndex: "source",
      key: "source",
    },
    {
      title: "Mã Đ.D người mua",
      dataIndex: "user.id",
      key: "user.id",
      render: (_, record: any) => get(record, "user.id"),
    },

    {
      title: "Tên người mua",
      dataIndex: "user.name",
      key: "user.name",
      render: (_, record: any) => get(record, "user.name"),
    },

    {
      title: "Tên chủ xe",
      dataIndex: "data.userName",
      key: "data.username",
      render: (_, record: any) => get(record, "data.userName"),
    },

    {
      title: "Biển số xe",
      dataIndex: "data.licensePlates",
      key: "data.licensePlates",
      render: (_, record: any) => get(record, "data.licensePlates"),
    },

    {
      title: "Địa chỉ chủ xe",
      dataIndex: "data.userAddress",
      key: "data.userAddress",
      render: (_, record: any) => get(record, "data.userAddress"),
    },

    {
      title: "SĐT chủ xe xe",
      dataIndex: "data.phone",
      key: "data.phone",
      render: (_, record: any) => get(record, "data.phone"),
    },

    {
      title: "Giá trị hợp đồng",
      dataIndex: "fee",
      key: "fee",
    },

    {
      title: "Giảm giá",
      dataIndex: "discount",
      key: "discount",
    },

    {
      title: "Mã Đ.D người giới thiệu trực tiếp",
      dataIndex: "commission.directReferrer.referrerId",
      key: "commission.directReferrer.referrerId",
      render: (_, record: any) =>
        get(record, "commission.directReferrer.referrerId"),
    },

    {
      title: "Sale trực tiếp",
      dataIndex: "commission.directReferrer.referrerName",
      key: "commission.directReferrer.referrerName",

      render: (_, record: any) =>
        get(record, "commission.directReferrer.referrerName"),
    },

    {
      title: "Hoa hồng tự giới thiệu",
      dataIndex: "commission.directReferrer.originalAmount",
      key: "commission.directReferrer.originalAmount",
      render: (_, record: any) =>
        get(record, "commission.directReferrer.originalAmount"),
    },

    {
      title: "Thuế hoa hồng tự giới thiệu",
      dataIndex: "commission.directReferrer.tax",
      key: "commission.directReferrer.tax",
      render: (_, record: any) => get(record, "commission.directReferrer.tax"),
    },

    {
      title: "Hoa hồng tự giới thiệu thực nhận",
      dataIndex: "commission.directReferrer.amount",
      key: "commission.directReferrer.amount",
      render: (_, record: any) =>
        get(record, "commission.directReferrer.amount"),
    },

    {
      title: "Mã Đ.D người giới thiệu gián tiếp",
      dataIndex: "commission.directReferrer.referrerId",
      key: "commission.directReferrer.referrerId",
      render: (_, record: any) =>
        get(record, "commission.directReferrer.referrerId"),
    },

    {
      title: "Sale gián tiếp",
      dataIndex: "commission.indirectReferrer.referrerName",
      key: "commission.indirectReferrer.referrerName",

      render: (_, record: any) =>
        get(record, "commission.indirectReferrer.referrerName"),
    },

    {
      title: "Hoa hồng giới thiệu gián tiếp",
      dataIndex: "commission.indirectReferrer.originalAmount",
      key: "commission.indirectReferrer.originalAmount",
      render: (_, record: any) =>
        get(record, "commission.indirectReferrer.originalAmount"),
    },

    {
      title: "Thuế hoa hồng giới thiệu gián tiếp",
      dataIndex: "commission.indirectReferrer.tax",
      key: "commission.indirectReferrer.tax",
      render: (_, record: any) =>
        get(record, "commission.indirectReferrer.tax"),
    },

    {
      title: "Hoa hồng giới thiệu gián tiếp thực nhận",
      dataIndex: "commission.indirectReferrer.amount",
      key: "commission.indirectReferrer.amount",
      render: (_, record: any) =>
        get(record, "commission.indirectReferrer.amount"),
    },
  ];

  return (
    <div style={{ maxWidth: "100%", overflow: "auto" }}>
      <FlexBox style={{ marginBottom: 12 }}>
        <CustomDateRangePicker
          startDate={dateRange.from}
          endDate={dateRange.to}
          onChange={(from, to) => setdateRange({ from, to })}
        />
        <Button type="primary" onClick={download}>
          Tải xuống
        </Button>
      </FlexBox>
      {data && (
        <Table
          scroll={{ x: "max-content" }}
          columns={columns}
          loading={isLoading}
          dataSource={data?.docs}
          pagination={{
            pageSizeOptions: [15, 30, 60],
            showSizeChanger: true,
            pageSize: pageSize,
            total: data?.totalDocs || 0,
            onChange(page, pageSize) {
              setPage(page);
              setPageSize(pageSize);
            },
            position: ["bottomLeft"],
          }}
        ></Table>
      )}
    </div>
  );
};

export default CSReport;

import {
  Button,
  Form,
  message,
  Popover,
  Space,
  Spin,
  Table,
  Typography,
} from "antd";
import { ColumnsType } from "antd/lib/table";
import { EWithdrawTransactionStatus } from "enums/payment.enum";
import { IWithdrawTransaction } from "interfaces/payment.interface";
import React, { useEffect, useState } from "react";
import moment from "moment";
import {
  useGetWithdrawCommissionRequestQuery,
  useCsReviewWithdrawCommissionRequestMutation,
} from "store/APIs/referrer";
import { DEFAULT_PAGE_SIZE } from "src/constants";
import { FlexBox } from "src/common/FlexBox";
import { MoreOutlined, UploadOutlined } from "@ant-design/icons";
import useFormatter from "src/hooks/useFormatter";
import { WithdrawCommissionStatusNextStepName } from "src/utils/name";
import Modal, { ModalProps } from "antd/lib/modal/Modal";
import TextArea from "antd/lib/input/TextArea";
import CustomUpload from "src/common/CustomUpload";
import { get } from "lodash";

const CSReviewWithdrawCommission = ({
  status,
}: {
  status: EWithdrawTransactionStatus;
}) => {
  const [form] = Form.useForm();
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(DEFAULT_PAGE_SIZE);
  const [modalProps, setmodalProps] = useState<
    ModalProps & { accept?: boolean; transactionId?: string }
  >({
    visible: false,
  });
  const { data, isLoading } = useGetWithdrawCommissionRequestQuery({
    page,
    limit: pageSize,
    status,
  });
  const { formatter } = useFormatter();

  const [
    csReviewWithdrawCommissionRequestMutation,
    {
      isLoading: isCsChangeStatusLoading,
      isSuccess: isCsChangeStatusSuccess,
      isError: isCsChangeStatusError,
    },
  ] = useCsReviewWithdrawCommissionRequestMutation();

  const columns: ColumnsType<IWithdrawTransaction> = [
    {
      title: "Mã giao dịch",
      dataIndex: "id",
      key: "id",
      render: (text) => <Typography>{text}</Typography>,
    },
    {
      title: "Họ tên",
      dataIndex: "userDetails.fullName",
      key: "userDetails.fullName",
      render: (_text, record: any) => (
        <Typography>{get(record, "userDetails.fullName")}</Typography>
      ),
    },

    {
      title: "Số tiền",
      dataIndex: "totalAmount",
      key: "totalAmount",
      render: (totalAmount) => (
        <Typography>{formatter.format(totalAmount)}</Typography>
      ),
    },

    {
      title: "Trạng thái",
      dataIndex: "status",
      key: "status",
      render: (status: EWithdrawTransactionStatus) => {
        return WithdrawCommissionStatusNextStepName[status];
      },
    },
    {
      title: "Khởi tạo lúc",
      dataIndex: "createdAt",
      key: "createdAt",
      render: (createdAt: string) =>
        moment(createdAt).format("DD/MM/YYYY  HH:mm"),
    },
    {
      title: "Cập nhật lần cuối lúc",
      dataIndex: "updatedAt",
      key: "updatedAt",
      render: (updatedAt: string) =>
        moment(updatedAt).format("DD/MM/YYYY HH:mm"),
    },

    {
      title: "Dữ liệu gửi duyệt (sheet)",
      dataIndex: "submitFileUrl",
      key: "submitFileUrl",
      render: (submitFileUrl) => (
        // eslint-disable-next-line react/jsx-no-target-blank
        <a target="_blank" href={submitFileUrl}>
          Tải xuống
        </a>
      ),
    },

    {
      title: "Dữ liệu đối soát (sheet)",
      dataIndex: "csFileUrl",
      key: "csFileUrl",
      render: (csFileUrl) =>
        csFileUrl ? (
          // eslint-disable-next-line react/jsx-no-target-blank
          <a target="_blank" href={csFileUrl}>
            Tải xuống
          </a>
        ) : null,
    },

    {
      title: "Phản hồi cho người dùng",
      dataIndex: "csFeedback",
      key: "csFeedback",
    },

    {
      title: "Note (nội bộ)",
      dataIndex: "notes",
      key: "notes",
      render: (notes: string[]) => {
        return (
          <Typography.Paragraph style={{ whiteSpace: "pre-wrap" }}>
            {(notes || []).join("\n")}
          </Typography.Paragraph>
        );
      },
    },
    {
      title: "",
      dataIndex: "action",
      key: "action",
      render: (_: string, record: IWithdrawTransaction) => {
        if (status !== EWithdrawTransactionStatus.PENDING) return;
        const actions: { lable: string; onClick: () => void }[] = [
          {
            lable: "Chấp nhận - chuyển yêu cầu cho kế toán",

            onClick: () => {
              setmodalProps({
                accept: true,
                title: "Chấp nhận yêu cầu thanh toán",
                visible: true,
                transactionId: record.id,
              });
            },
          },
          {
            lable: "Từ chối",
            onClick: () => {
              setmodalProps({
                accept: false,
                title: "Xác nhận từ chối yêu cầu thanh toán này",
                visible: true,
                transactionId: record.id,
              });
            },
          },
        ];

        const content = () => (
          <div>
            {actions.map((item) => (
              <FlexBox
                key={item.lable}
                style={{
                  cursor: "pointer",
                  padding: "12px 8px",
                  borderBottom: "1px solid rgba(0,0,0,0.1)",
                }}
                onClick={item.onClick}
              >
                <Typography>{item.lable}</Typography>
              </FlexBox>
            ))}
          </div>
        );

        if (!actions.length) return null;
        return (
          <Space size="middle">
            <Popover
              content={content}
              title=""
              trigger="hover"
              placement="left"
            >
              <Button
                icon={<MoreOutlined />}
                loading={isCsChangeStatusLoading || isLoading}
              ></Button>
            </Popover>
          </Space>
        );
      },
    },
  ];

  useEffect(() => {
    if (isCsChangeStatusLoading) return;
    if (isCsChangeStatusSuccess) {
      message.success("Đã cập nhật");
    }
    if (isCsChangeStatusError) {
      message.error("Có lỗi xảy ra! vui lòng thử lại hoặc liên hệ IT");
    }
    setmodalProps({ visible: false });
  }, [isCsChangeStatusSuccess, isCsChangeStatusError, isCsChangeStatusLoading]);

  if (isLoading) return <Spin />;
  return (
    <>
      <Modal
        destroyOnClose
        onOk={() => {
          if (!modalProps.transactionId) return;
          csReviewWithdrawCommissionRequestMutation({
            status: modalProps.accept
              ? EWithdrawTransactionStatus.CS_ACCEPTED
              : EWithdrawTransactionStatus.CS_REJECTED,
            transactionId: modalProps.transactionId,
            csFeedback: form.getFieldValue("csFeedback"),
            csFileUrl: form.getFieldValue("csFileUrl")?.file.response,
            note: form.getFieldValue("note"),
          });
          form.resetFields();
        }}
        onCancel={() => {
          setmodalProps({ visible: false });
          form.resetFields();
        }}
        cancelText="Đóng"
        okText="Xác nhận"
        okButtonProps={{
          loading: isCsChangeStatusLoading,
        }}
        cancelButtonProps={{
          loading: isCsChangeStatusLoading,
        }}
        {...modalProps}
        width={800}
      >
        {modalProps.accept && (
          <>
            <Form
              form={form}
              name="basic"
              labelCol={{ span: 24 }}
              wrapperCol={{ span: 24 }}
              style={{ maxWidth: 1000, width: "100%" }}
              // onFinishFailed={onFinishFailed}

              autoComplete="off"
            >
              <Form.Item label="Note - nội bộ" name="note">
                <TextArea rows={5} />
              </Form.Item>
              <Form.Item label="File dữ liệu đối soát" name="csFileUrl">
                <CustomUpload>
                  <Button icon={<UploadOutlined />}>
                    Tải lên (.xls hoặc .xlsx)
                  </Button>
                </CustomUpload>
              </Form.Item>
            </Form>
          </>
        )}
        {!modalProps.accept && (
          <>
            <Form
              form={form}
              name="basic"
              labelCol={{ span: 24 }}
              wrapperCol={{ span: 24 }}
              style={{ maxWidth: 1000, width: "100%" }}
              // onFinishFailed={onFinishFailed}

              autoComplete="off"
            >
              <Form.Item label="Phản hồi cho người dùng" name="csFeedback">
                <TextArea rows={5} />
              </Form.Item>
              <Form.Item label="Note - nội bộ" name="note">
                <TextArea rows={5} />
              </Form.Item>
            </Form>
          </>
        )}
      </Modal>
      <Table
        loading={isLoading}
        columns={columns}
        dataSource={data?.docs}
        scroll={{ x: 300 }}
        style={{ width: "100%" }}
        pagination={{
          pageSizeOptions: [15, 30, 60],
          showSizeChanger: true,
          pageSize: pageSize,
          total: data?.totalDocs || 0,
          onChange(page, pageSize) {
            setPage(page);
            setPageSize(pageSize);
          },
        }}
      />
    </>
  );
};

export default CSReviewWithdrawCommission;

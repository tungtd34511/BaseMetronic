import { Button, Table } from "antd";
import { ColumnsType } from "antd/lib/table";
import { get } from "lodash";
import moment from "moment";
import React, { useState } from "react";
import CustomDateRangePicker from "src/common/CustomDateRangePicker";
import { FlexBox } from "src/common/FlexBox";
import { ACCESS_TOKEN_KEY, DEFAULT_PAGE_SIZE } from "src/constants";
import { useCsGetCommissionDetailsQuery } from "store/APIs/referrer";

const CSCommissionReport = () => {
  const [dateRange, setdateRange] = useState({
    from: moment().subtract(7, "days").valueOf(),
    to: moment().valueOf(),
  });

  const [pageSize, setPageSize] = useState(DEFAULT_PAGE_SIZE);
  const [page, setPage] = useState(1);

  const { data, isLoading } = useCsGetCommissionDetailsQuery({
    ...dateRange,
    limit: pageSize,
    page,
  });

  const download = () => {
    const headers = new Headers();
    try {
      const accessToken =
        typeof window !== "undefined"
          ? window.localStorage.getItem(ACCESS_TOKEN_KEY)
          : "";

      if (accessToken) {
        headers.set("authorization", `Bearer ${accessToken}`);
      }
    } catch (error) {
      console.error(error);
    }

    fetch(
      `${
        process.env.API_HOST
      }/api/cs/referrer/commission/export?${new URLSearchParams(
        dateRange as any
      ).toString()}`,
      {
        headers,
      }
    )
      .then((response) => response.blob())
      .then((blob) => {
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = `report_${moment(dateRange.from).format(
          "DD/MM/YYYY"
        )}_${moment(dateRange.to).format("DD/MM/YYYY")}.xlsx`;
        document.body.appendChild(a); // we need to append the element to the dom -> otherwise it will not work in firefox
        a.click();
        a.remove(); // afterwards we remove the element again
      });
  };

  const columns: ColumnsType<any> = [
    {
      title: "Ngày",
      dataIndex: "root.createdAt",
      key: "root.createdAt",
      width: 200,
      render: (_, record: any) =>
        moment(get(record, "root.createdAt")).format("DD/MM/YYYY HH:mm"),
    },

    {
      title: "Giới thiệu trực tiếp",
      dataIndex: "directly",
      key: "directly",
      render: (val) => String(val),
    },

    {
      title: "Giá trị hợp đồng",
      dataIndex: "root.insurance.fee",
      key: "root.insurance.fee",
      render: (_, record: any) => get(record, "root.insurance.fee"),
    },

    {
      title: "Giảm giá",
      dataIndex: "root.insurance.discount",
      key: "root.insurance.discount",
      render: (_, record: any) => get(record, "root.insurance.discount"),
    },

    {
      title: "Hoa hồng",
      dataIndex: "referrer.originalAmount",
      key: "referrer.originalAmount",
      render: (_, record: any) => get(record, "referrer.originalAmount"),
    },

    {
      title: "Thuế",
      dataIndex: "referrer.tax",
      key: "referrer.tax",
      render: (_, record: any) => get(record, "referrer.tax"),
    },

    {
      title: "Thực nhận",
      dataIndex: "referrer.amount",
      key: "referrer.amount",
      render: (_, record: any) => get(record, "referrer.amount"),
    },

    {
      title: "Mã giao dịch",
      dataIndex: "root.insurance.transactionId",
      key: "root.insurance.transactionId",
      render: (_, record: any) => get(record, "root.insurance.transactionId"),
    },

    {
      title: "Mã Đ.D người giới thiệu",
      dataIndex: "referrer.referrerId",
      key: "referrer.referrerId",
      render: (_, record: any) => get(record, "referrer.referrerId"),
    },

    {
      title: "Tên người giới thiệu",
      dataIndex: "referrer.referrerName",
      key: "referrer.referrerName",
      render: (_, record: any) => get(record, "referrer.referrerName"),
    },

    {
      title: "Tên người mua",
      dataIndex: "root.user.name",
      key: "root.user.name",
      render: (_, record: any) => get(record, "root.user.name"),
    },

    {
      title: "Tên chủ xe",
      dataIndex: "root.insurance.data.userName",
      key: "root.insurance.data.username",
      render: (_, record: any) => get(record, "root.insurance.data.userName"),
    },

    {
      title: "Biển số xe",
      dataIndex: "root.insurance.data.licensePlates",
      key: "root.insurance.data.licensePlates",
      render: (_, record: any) =>
        get(record, "root.insurance.data.licensePlates"),
    },

    {
      title: "Địa chỉ chủ xe",
      dataIndex: "root.insurance.data.userAddress",
      key: "root.insurance.data.userAddress",
      render: (_, record: any) =>
        get(record, "root.insurance.data.userAddress"),
    },

    {
      title: "SĐT chủ xe",
      dataIndex: "root.insurance.data.phone",
      key: "root.insurance.data.phone",
      render: (_, record: any) => get(record, "root.insurance.data.phone"),
    },
  ];

  return (
    <div style={{ maxWidth: "100%", overflow: "auto" }}>
      <FlexBox style={{ marginBottom: 12 }}>
        <CustomDateRangePicker
          startDate={dateRange.from}
          endDate={dateRange.to}
          onChange={(from, to) => {
            setPage(1);
            setdateRange({ from, to });
          }}
        />
        <Button type="primary" onClick={download}>
          Tải xuống
        </Button>
      </FlexBox>
      {data && (
        <Table
          scroll={{ x: "max-content" }}
          columns={columns}
          loading={isLoading}
          dataSource={data?.docs}
          pagination={{
            pageSizeOptions: [15, 30, 60],
            showSizeChanger: true,
            pageSize: pageSize,
            total: data?.totalDocs || 0,
            onChange(page, pageSize) {
              setPage(page);
              setPageSize(pageSize);
            },
            position: ["bottomLeft"],
          }}
        ></Table>
      )}
    </div>
  );
};

export default CSCommissionReport;

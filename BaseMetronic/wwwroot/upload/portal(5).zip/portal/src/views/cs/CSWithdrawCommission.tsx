import { Tabs } from "antd";
import { EWithdrawTransactionStatus } from "enums/payment.enum";
import React, { useState } from "react";
import { FlexBox } from "src/common/FlexBox";
import { WithdrawCommissionStatusNextStepName } from "src/utils/name";

import CSReviewWithdrawCommission from "./CSReviewWithdrawCommission";

const CSWithdrawCommission = () => {
  const [tab, settab] = useState(EWithdrawTransactionStatus.PENDING);

  return (
    <Tabs
      centered
      style={{ height: "100%" }}
      activeKey={tab}
      onChange={settab as any}
    >
      {Object.values(EWithdrawTransactionStatus).map(
        (key: EWithdrawTransactionStatus) => (
          <Tabs.TabPane
            tab={WithdrawCommissionStatusNextStepName[key]}
            key={key}
          >
            <FlexBox
              style={{
                alignItems: "center",
                flexDirection: "column",
                marginTop: 50,
              }}
            >
              <CSReviewWithdrawCommission status={key} />
            </FlexBox>
          </Tabs.TabPane>
        )
      )}
    </Tabs>
  );
};

export default CSWithdrawCommission;

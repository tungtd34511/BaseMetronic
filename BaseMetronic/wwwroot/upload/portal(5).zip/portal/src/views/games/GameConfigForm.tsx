import React, { useEffect } from "react";
import {
  Modal,
  Descriptions,
  Button,
  Image,
  message,
  Form,
  Select,
  Col,
  InputNumber,
  Card,
  Input,
  Space,
  Typography,
} from "antd";
import moment from "moment";
import { EGameType, IGameconfigs } from "interfaces/game.interface";
import {
  useCreateGameConfigsMutation,
  useUpdateGameConfigsMutation,
} from "store/APIs/game";
import { CloseOutlined } from "@ant-design/icons";

interface GameConfigPopupProps {
  visible: boolean;
  record: IGameconfigs;
  onClose: () => void;
  action: (record: IGameconfigs) => void;
}

const GameConfigPopup: React.FC<GameConfigPopupProps> = ({
  visible,
  record,
  onClose,
  action,
}) => {
  const detail = record;
  const [form] = Form.useForm();
  useEffect(() => {
    if (detail) {
      form.setFieldsValue({
        ...detail,
      });
    }
  }, [detail]);
  const onFinish = () => {
    const formData = form.getFieldsValue();
    const data: IGameconfigs = {
      ...formData,
    };
    if(detail) data.id = detail.id
    action(data);
    onClickClose();
  };
  const onClickClose = () => {
      onClose();
      form.resetFields();
      form.setFieldsValue({
        tryTime: 1,
        gameType:  EGameType.WHEEL,
        config: {},
      });
  };
  const onGameTypeChange = (value: string) => {
    form.setFieldsValue({
      ...form.getFieldsValue(),
      gender: value,
    });
  };
  return (
    <Modal
      visible={visible}
      title={detail ? "Cập nhật cấu hình" : "Tạo mới cấu hình"}
      onCancel={onClickClose}
      closeIcon={false}
      footer={[
        <div>
          {detail ? (
            <Button key="close" onClick={() => onFinish()}>
              Cập nhật
            </Button>
          ) : (
            <Button key="close" onClick={() => onFinish()}>
              Tạo mới
            </Button>
          )}
          <Button key="close" onClick={()=>onClickClose()}>
            Đóng
          </Button>
        </div>,
      ]}
    >
      <Form
        form={form}
        name="basic"
        labelCol={{ span: 24 }}
        wrapperCol={{ span: 24 }}
        style={{ width: "100%" }}
        initialValues={{ remember: true }}
        autoComplete="off"
      >
        <Col span={24} md={8}>
          <Form.Item
            style={{
              width: "100%",
            }}
            label="Thể loại game"
            name="gameType"
            rules={[{ required: true, message: "Không được để trống" }]}
          >
            <Select
              placeholder="Chọn thể loại game"
              onChange={onGameTypeChange}
              allowClear
              defaultValue={
                detail?.gameType ? detail?.gameType : EGameType.WHEEL
              }
            >
              <Select.Option value={EGameType.WHEEL}>
                Vòng quay may mắn
              </Select.Option>
            </Select>
          </Form.Item>
        </Col>
        <Form.Item
          name="tryTime"
          label="Số lần chơi mỗi ngày"
          style={{ marginTop: 16 }}
          rules={[{ required: true, message: "Không được để trống" }]}
        >
          <InputNumber
            style={{ width: 200 }}
            defaultValue={detail?.tryTime ? detail?.tryTime : 1}
          />
        </Form.Item>
        <Form.List name={["config", "prizes"]}>
          {(subFields, subOpt) => (
            <div
              style={{ display: "flex", flexDirection: "column", rowGap: 16 }}
            >
              Các giải thưởng
              {subFields.map((subField) => (
                <Space key={subField.key}>
                  <Form.Item noStyle name={[subField.name, "label"]}>
                    <Input placeholder="Giải thưởng" />
                  </Form.Item>
                  <Form.Item noStyle name={[subField.name, "color"]}>
                    <Input placeholder="Mầu sắc" />
                  </Form.Item>
                  <Form.Item noStyle name={[subField.name, "arc"]}>
                    <InputNumber placeholder="Phần Trăm" />
                  </Form.Item>
                  <CloseOutlined
                    onClick={() => {
                      subOpt.remove(subField.name);
                    }}
                  />
                </Space>
              ))}
              <Button type="dashed" onClick={() => subOpt.add()} block>
                + Thêm giá trị
              </Button>
            </div>
          )}
        </Form.List>
        <div style={{ fontStyle: "italic", fontSize: 12 }}>
          Chú ý:
          <br />- Với trường hợp vòng quay tổng các phần trăm bắt buộc phải bằng
          100
        </div>
      </Form>
    </Modal>
  );
};
export default GameConfigPopup;

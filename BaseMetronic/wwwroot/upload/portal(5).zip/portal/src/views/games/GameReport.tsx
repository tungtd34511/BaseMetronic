import { MoreOutlined } from "@ant-design/icons";
import { Button, Popover, Space, Table, Typography, message } from "antd";
import { ColumnsType } from "antd/lib/table";
import { EGamelogStatus, IGameLog } from "interfaces/game.interface";
import { get } from "lodash";
import moment from "moment";
import React, { useEffect, useState } from "react";
import CustomDateRangePicker from "src/common/CustomDateRangePicker";
import { FlexBox } from "src/common/FlexBox";
import { ACCESS_TOKEN_KEY, DEFAULT_PAGE_SIZE } from "src/constants";
import { useGetGameLogsQuery, useUpdateGameLogsMutation } from "store/APIs/game";
import { useCsGetReportQuery } from "store/APIs/insurance";

const GameReport = () => {
  const [dateRange, setdateRange] = useState({
    from: moment().subtract(7, "days").valueOf(),
    to: moment().valueOf(),
  });

  const [pageSize, setPageSize] = useState(DEFAULT_PAGE_SIZE);
  const [page, setPage] = useState(1);

  const { data, isLoading } = useGetGameLogsQuery({
    ...dateRange,
    limit: pageSize,
    page,
  });
  const [
    updateGamelogMutation,
    { isLoading: isUpdateLoading, isError, isSuccess },
  ] = useUpdateGameLogsMutation();
  const updateGamelog= (record:IGameLog , status : EGamelogStatus ) => {
    const payload: IGameLog = {
      ...record,
      status : status
    };
    updateGamelogMutation(payload);
  };
  useEffect(() => {
    if (isError) {
      message.error("Có lỗi xảy ra");
    }
    if (isSuccess) {
      message.success("Cập nhật thành công");
    }
  }, [isError, isSuccess]);
  const columns: ColumnsType<any> = [
    {
      title: "Ngày",
      dataIndex: "date",
      key: "date",
      width: 200,
    },
    {
        title: "Mã Đ.D người chơi",
        dataIndex: "user.id",
        key: "user.id",
        render: (_, record: any) => get(record, "user.id"),
      },
      
      {
        title: "Tên người chơi",
        dataIndex: "user.name",
        key: "user.name",
        render: (_, record: any) => get(record, "user.name"),
      },
      {
        title: "Số điện thoại người chơi",
        dataIndex: "user.phone",
        key: "user.phone",
        render: (_, record: any) => get(record, "user.phone"),
      },
    {
      title: "Trờ chơi",
      dataIndex: "gameType",
      key: "gameType",
    },
    {
      title: "Phần Thưởng",
      dataIndex: "reward",
      key: "reward",
      render: (_, record: any) => get(record, "reward"),
    },
    {
        title: "Nền tảng",
        dataIndex: "platform",
        key: "platform",
        render: (_, record: any) => get(record, "platform"),
    },
    {
        title: "Trạng thái",
        dataIndex: "status",
        key: "status",
        render: (_, record: any) => get(record, "status"),
    },
    {
      title: "",
      key: "action",
      render: (_, record: any) => {
        const actions: { lable: string; onClick: () => void }[] = [
          {
            lable: "Đổi thành đã xử lý thành công",
            onClick: () => {
              updateGamelog(record,EGamelogStatus.SUCCESS)
            },
          },
          {
            lable:  "Đổi thành chưa xử lý",
            onClick: () => {
              updateGamelog(record,EGamelogStatus.PENDING)
            },
          },
          {
            lable:  "Đổi thành lỗi",
            onClick: () => {
              updateGamelog(record,EGamelogStatus.FAILED)
            },
          },
          {
            lable:"Đổi thành hủy",
            onClick: () => {
              updateGamelog(record,EGamelogStatus.CANCELLED)
            },
          },
        ];

        const content = () => (
          <div>
            {actions.map((item) => (
              <FlexBox
                key={item.lable}
                style={{
                  cursor: "pointer",
                  padding: "12px 8px",
                  borderBottom: "1px solid rgba(0,0,0,0.1)",
                }}
                onClick={item.onClick}
              >
                <Typography>{item.lable}</Typography>
              </FlexBox>
            ))}
          </div>
        );
        return (
          <Space size="middle">
            <Popover content={content} trigger="click">
              <Button icon={<MoreOutlined />} />
            </Popover>
          </Space>
        );
      },
    },
  ];

  return (
    <div style={{ maxWidth: "100%", overflow: "auto" }}>
      <FlexBox style={{ marginBottom: 12 }}>
        <CustomDateRangePicker
          startDate={dateRange.from}
          endDate={dateRange.to}
          onChange={(from, to) => setdateRange({ from, to })}
        />
        {/* <Button type="primary" onClick={download}>
          Tải xuống
        </Button> */}
      </FlexBox>
      {data && (
        <Table
          scroll={{ x: "max-content" }}
          columns={columns}
          loading={isLoading}
          dataSource={data?.docs}
          pagination={{
            pageSizeOptions: [15, 30, 60],
            showSizeChanger: true,
            pageSize: pageSize,
            total: data?.totalDocs || 0,
            onChange(page, pageSize) {
              setPage(page);
              setPageSize(pageSize);
            },
            position: ["bottomLeft"],
          }}
        ></Table>
      )}
    </div>
  );
};

export default GameReport;

import { MoreOutlined } from "@ant-design/icons";
import {
  Button,
  Popover,
  Select,
  Space,
  Table,
  Typography,
  message,
} from "antd";
import { ColumnsType } from "antd/lib/table";
import {
  EGameType,
  EGamelogStatus,
  IGameLog,
  IGameconfigs,
} from "interfaces/game.interface";
import { forEach, get } from "lodash";
import React, { useEffect, useState } from "react";
import { FlexBox } from "src/common/FlexBox";
import { ACCESS_TOKEN_KEY, DEFAULT_PAGE_SIZE } from "src/constants";
import {
  useGetGameConfigsQuery,
  useGetGameLogsQuery,
  useUpdateGameLogsMutation,
} from "store/APIs/game";
import GameConfigPopup from "./GameConfigForm";
import {
  useCreateGameConfigsMutation,
  useUpdateGameConfigsMutation,
} from "store/APIs/game";

const GameConfigList = () => {
  const [pageSize, setPageSize] = useState(DEFAULT_PAGE_SIZE);
  const [page, setPage] = useState(1);
  const [gameType, setGameType] = useState(EGameType.WHEEL);
  const { data, isLoading } = useGetGameConfigsQuery({
    limit: pageSize,
    page,
    gameType,
  });
  const columns: ColumnsType<any> = [
    {
      title: "Trò chơi",
      dataIndex: "gameType",
      key: "gameType",
    },
    {
      title: "Số lần chơi mỗi ngày",
      dataIndex: "tryTime",
      key: "tryTime",
      render: (_, record: any) => get(record, "tryTime"),
    },
    {
      title: "Cấu hình",
      dataIndex: "config",
      key: "config",
      render: (_, record: IGameconfigs) => {
        if (record.gameType == EGameType.WHEEL) {
          let string = "";
          record.config?.prizes.forEach(
            (
              prize: { label: any; color: any; arc: any },
              index: any
            ) => {
              string += `Phần Thưởng ${index + 1} : ${prize?.label}, Mầu : ${
                prize?.color
              }, Phần trăm : ${prize?.arc} \n`;
            }
          );
          return (
            <div>
              {string.split("\n").map((t, key) => {
                return <p key={key}>{t}</p>;
              })}
            </div>
          );
        } else {
          return get(record, "config");
        }
      },
    },
    {
      title: "",
      key: "action",
      render: (_, record: any) => {
        const actions: { lable: string; onClick: () => void }[] = [
          {
            lable: "Cập nhật bản ghi",
            onClick: () => {
              handleOpenFile(record);
            },
          },
        ];

        const content = () => (
          <div>
            {actions.map((item) => (
              <FlexBox
                key={item.lable}
                style={{
                  cursor: "pointer",
                  padding: "12px 8px",
                  borderBottom: "1px solid rgba(0,0,0,0.1)",
                }}
                onClick={item.onClick}
              >
                <Typography>{item.lable}</Typography>
              </FlexBox>
            ))}
          </div>
        );
        return (
          <Space size="middle">
            <Popover content={content} trigger="click">
              <Button icon={<MoreOutlined />} />
            </Popover>
          </Space>
        );
      },
    },
  ];
  const [selectedRecord, setSelectedRecord] = useState<any>(null);
  const [isPopupVisible, setIsPopupVisible] = useState(false);
  const handleOpenFile = (record: IGameconfigs) => {
    setSelectedRecord(record);
    setIsPopupVisible(true);
  };
  const handleClosePopup = () => {
    setSelectedRecord(null);
    setIsPopupVisible(false);
  };
  const [
    createGameconfigMutation,
    {
      isLoading: isCreateLoading,
      isError: isErrorCreate,
      isSuccess: isSuccessCreate,
    },
  ] = useCreateGameConfigsMutation();
  const createGameconfig = (record: IGameconfigs) => {
    const payload: IGameconfigs = {
      ...record,
    };
    createGameconfigMutation(payload);
  };
  useEffect(() => {
    if (isErrorCreate) {
      message.error("Có lỗi xảy ra");
    }
    if (isSuccessCreate) {
      message.success("Tạo thành công");
    }
  }, [isErrorCreate, isSuccessCreate]);
  const [
    updateGameconfigMutation,
    { isLoading: isUpdateLoading, isError, isSuccess },
  ] = useUpdateGameConfigsMutation();
  const updateGameconfig = (record: IGameconfigs) => {
    const payload: IGameconfigs = {
      ...record,
    };
    updateGameconfigMutation(payload);
  };
  useEffect(() => {
    if (isError) {
      message.error("Có lỗi xảy ra");
    }
    if (isSuccess) {
      message.success("Cập nhật thành công");
    }
  }, [isError, isSuccess]);
  return (
    <div style={{ maxWidth: "100%", overflow: "auto" }}>
      <FlexBox style={{ marginBottom: 12 }}>
        <Select
          defaultValue={EGameType.WHEEL}
          style={{ width: 120 }}
          allowClear
          options={[{ value: EGameType.WHEEL, label: "Vòng quay may mắn" }]}
          onChange={(val) => setGameType(val as EGameType.WHEEL)}
        />
        <Button
          type="primary"
          onClick={() => {
            setSelectedRecord(null);
            setIsPopupVisible(true);
          }}
        >
          Tạo cấu hình mới
        </Button>
      </FlexBox>
      {data && (
        <Table
          scroll={{ x: "max-content" }}
          columns={columns}
          loading={isLoading}
          dataSource={data?.docs}
          pagination={{
            pageSizeOptions: [15, 30, 60],
            showSizeChanger: true,
            pageSize: pageSize,
            total: data?.totalDocs || 0,
            onChange(page, pageSize) {
              setPage(page);
              setPageSize(pageSize);
            },
            position: ["bottomLeft"],
          }}
        ></Table>
      )}
      <GameConfigPopup
        visible={isPopupVisible}
        record={selectedRecord}
        onClose={handleClosePopup}
        action={selectedRecord ? updateGameconfig : createGameconfig}
      />
    </div>
  );
};

export default GameConfigList;

import React from "react";

type Props = {
  color?: string;
  size?: number;
  style?: React.CSSProperties;
} & React.HtmlHTMLAttributes<HTMLOrSVGElement>;

const ArrowDownIcon = ({
  size = 24,
  color = "rgba(0,0,0,0.6)",
  ...props
}: Props) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    {...props}
  >
    <path
      d="m8.5 9 3.168 4.752a1 1 0 0 0 1.664 0L16.5 9"
      stroke={color}
      strokeWidth={1.5}
      strokeLinecap="round"
      strokeDasharray="0.2 0.2"
    />
  </svg>
);

export default ArrowDownIcon;

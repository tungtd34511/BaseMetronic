import React from "react";
type Props = {
  color?: string;
  size?: number;
  style?: React.CSSProperties;
} & React.HtmlHTMLAttributes<HTMLOrSVGElement>;

const RuleCardIcon = ({
  size = 24,
  color = "rgba(0,0,0,0.6)",
  ...props
}: Props) => (
  <svg
    width={size}
    height={size}
    fill="none"
    viewBox="0 0 24 24"
    xmlns="http://www.w3.org/2000/svg"
    {...props}
  >
    <path
      d="M16.449 8c-3.156.511-5.816.496-8.88-.005-2.091-.341-3.97 1.489-3.474 3.545l1.767 7.316A2.804 2.804 0 0 0 8.589 21h6.853a2.804 2.804 0 0 0 2.728-2.144l1.764-7.302c.497-2.06-1.39-3.894-3.485-3.555Z"
      stroke={color}
      strokeWidth={1.5}
    />
    <path
      d="M8 10.832V6.5A3.5 3.5 0 0 1 11.5 3h1A3.5 3.5 0 0 1 16 6.5V11"
      stroke={color}
      strokeWidth={1.5}
      strokeLinecap="round"
    />
  </svg>
);
export default RuleCardIcon;

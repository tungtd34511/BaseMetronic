import React from "react";

type Props = {
  color?: string;
  size?: number;
  style?: React.CSSProperties;
} & React.HtmlHTMLAttributes<HTMLOrSVGElement>;

const TextIcon = ({
  size = 24,
  color = "rgba(0,0,0,0.6)",
  ...props
}: Props) => (
  <svg
    width={size}
    height={size}
    fill="none"
    viewBox="0 0 24 24"
    xmlns="http://www.w3.org/2000/svg"
    {...props}
  >
    <rect
      x={4}
      y={4}
      width={16}
      height={16}
      rx={2.8}
      stroke={color}
      strokeWidth={1.5}
    />
    <path
      d="M15 9h-3M9 9h3m0 0v6M9 9v1M15 9v1"
      stroke={color}
      strokeWidth={1.5}
      strokeLinecap="round"
    />
  </svg>
);

export default TextIcon;

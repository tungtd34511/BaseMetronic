import React from "react";

type Props = {
  color?: string;
  size?: number;
  style?: React.CSSProperties;
} & React.HtmlHTMLAttributes<HTMLOrSVGElement>;

const CalendarIcon = ({
  size = 24,
  color = "rgba(0,0,0,0.6)",
  ...props
}: Props) => {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <rect
        x={4}
        y={5.071}
        width={16}
        height={16}
        rx={2.8}
        stroke={color}
        strokeWidth={1.5}
      />
      <path
        d="M8.571 6.214V3.93M15.429 6.214V3.93M19.429 18.214h-9.143A6.286 6.286 0 0 1 4 11.93v0M8 10h.5M12 10h.5M16 10h.5M8 14h.5M12 14h.5M16 14h.5"
        stroke={color}
        strokeWidth={1.5}
        strokeLinecap="round"
      />
    </svg>
  );
};

export default CalendarIcon;

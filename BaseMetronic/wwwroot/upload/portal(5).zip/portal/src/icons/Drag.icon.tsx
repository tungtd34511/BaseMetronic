import React from "react";

type Props = {
  color?: string;
  size?: number;
  style?: React.CSSProperties;
} & React.HtmlHTMLAttributes<HTMLOrSVGElement>;

const DragIcon = ({
  size = 24,
  color = "rgba(0,0,0,0.6)",
  ...props
}: Props) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    {...props}
  >
    <rect y={0.5} width={10} height={19} rx={2} fill="#F6F7F9" />
    <path d="M4 3.5a1 1 0 1 1-2 0 1 1 0 0 1 2 0Z" fill={color} />
    <circle cx={3} cy={7.5} r={1} fill={color} />
    <circle cx={3} cy={11.5} r={1} fill={color} />
    <circle cx={3} cy={15.5} r={1} fill={color} />
    <circle cx={7} cy={3.5} r={1} fill={color} />
    <circle cx={7} cy={7.5} r={1} fill={color} />
    <circle cx={7} cy={11.5} r={1} fill={color} />
    <circle cx={7} cy={15.5} r={1} fill={color} />
  </svg>
);

export default DragIcon;

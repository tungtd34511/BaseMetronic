export enum EInsuranceFeature {
  // trach nhiem dan su bat buoc
  MOTOR_01 = "MOTOR_01",
  AUTO_01 = "AUTO_01",
  PERSONAL_01 = "PERSONAL_01",
  TRAVEL_01 = "TRAVEL_01",
  TRAVEL_02 = "TRAVEL_02",
  HEALTH_01 = "HEALTH_01",
  HEALTH_02 = "HEALTH_02",
  FIRE_01 = "FIRE_01",
  HOME_01 = "HOME_01",
  OTHER_01 = "OTHER_01",
  PERSONAL_02 = "PERSONAL_02",
  STUDENT_01 = "STUDENT_01",
}

export enum EInsuranceGroup {
  INSURANCE = "MOTOR",
  DOCUMENT = "DOCUMENT",
  CLAIM = "CLAIM",
}

export enum EInsuranceSource {
  PVI = "PVI",
  VBI = "VBI",
  MIC = "MIC",
  BIC = "BIC",
  BSH = "BSH",
  OTHER = "OTHER",
}

export enum EInsuranceWorkflowStage {
  AWAITING_PAYMENT = "AWAITING_PAYMENT",
  PENDING = "PENDING",
  ERROR = "ERROR",
  SUCCESSFUL = "SUCCESSFUL",
}

export const ARR_INSURANCE_SOURCE = [
  // {
  //   value:EInsuranceSource.PVI,
  //   label:EInsuranceSource.PVI
  // },

  {
    value: EInsuranceSource.VBI,
    label: EInsuranceSource.VBI,
  },
  {
    value: EInsuranceSource.MIC,
    label: EInsuranceSource.MIC,
  },
  {
    value: EInsuranceSource.BIC,
    label: EInsuranceSource.BIC,
  },
  {
    value: EInsuranceSource.PVI,
    label: EInsuranceSource.PVI,
  },
];

export const ARR_INSURANCE_STAGE = [
  {
    value: EInsuranceWorkflowStage.AWAITING_PAYMENT,
    label: "Chờ thanh toán",
  },
  {
    value: EInsuranceWorkflowStage.PENDING,
    label: "Chờ xử lý",
  },
  {
    value: EInsuranceWorkflowStage.ERROR,
    label: "Lỗi",
  },
  {
    value: EInsuranceWorkflowStage.SUCCESSFUL,
    label: "Đã gửi hợp đồng",
  },
];

export const ARR_INSURANCE_SOURCE_MOTOR_AND_AUTO = [
  // {
  //   value:EInsuranceSource.PVI,
  //   label:EInsuranceSource.PVI
  // },
  {
    value: EInsuranceSource.PVI,
    label: EInsuranceSource.PVI,
  },
  {
    value: EInsuranceSource.MIC,
    label: EInsuranceSource.MIC,
  },
  {
    value: EInsuranceSource.VBI,
    label: EInsuranceSource.VBI,
  },
  {
    value: EInsuranceSource.BSH,
    label: EInsuranceSource.BSH,
  },

  // {
  //   value:EInsuranceSource.BIC,
  //   label:EInsuranceSource.BIC
  // },
];

export const ARR_INSURANCE_SOURCE_HOME = [
  {
    value: EInsuranceSource.PVI,
    label: EInsuranceSource.PVI,
  },
];

export const ARR_INSURANCE_SOURCE_HEALTH = [
  {
    value: EInsuranceSource.VBI,
    label: EInsuranceSource.VBI,
  },
  {
    value: EInsuranceSource.MIC,
    label: EInsuranceSource.MIC,
  },
  {
    value: EInsuranceSource.BIC,
    label: EInsuranceSource.BIC,
  },
];

export enum EAutoUserIntentValue {
  N = "N", // người - không kd
  N_K = "N_K", // người - kinh doanh
  H = "H", // hàng - không kd
  H_K = "H_K", // hàng - kinh doanh
  KD = "KD", // kinh doanh
  KKD = "KKD", // không kinh doanh
}

export const ARR_INSURANCE_SOURCE_USER_INTENT = [
  {
    value: "N",
    label: "Xe chở người - không kinh doanh",
  },
  {
    value: "N_K",
    label: "Xe chở người - kinh doanh",
  },
  {
    value: "H",
    label: "Xe chở hàng - không kinh doanh",
  },
  {
    value: "H_K",
    label: "Xe chở hàng - kinh doanh",
  },
  // {
  //   value:'KD',
  //   label:'Xe kinh doanh'
  // },
  // {
  //   value:'KKD',
  //   label:'Xe không kinh doanh'
  // },
];

export const ARR_INSURANCE_SOURCE_CAPACITY = [
  {
    value: "CC50Down",
    label: "Xe dưới 50cc",
  },
  {
    value: "CC50Up",
    label: "Xe trên 50cc",
  },
  {
    value: "Electric",
    label: "Xe điện",
  },
];

// MOTOR_01 = "MOTOR_01",
// AUTO_01 = "AUTO_01",
// PERSONAL_01 = "PERSONAL_01",
// TRAVEL_01 = "TRAVEL_01",
// HEALTH_01 = "HEALTH_01",
// FIRE_01 = "FIRE_01",
// HOME_01 = "HOME_01",
// OTHER_01 = "OTHER_01",
const ConvertNameFeature = (str = "") => {
  str = str.toUpperCase();
  if (str === EInsuranceFeature.MOTOR_01) str = "Xe máy";
  if (str === EInsuranceFeature.AUTO_01) str = "Ô tô";
  if (str === EInsuranceFeature.PERSONAL_01) str = "Tai nạn cá nhân";
  if (str === EInsuranceFeature.PERSONAL_02) str = "Tai nạn mở rộng";
  if (str === EInsuranceFeature.TRAVEL_01) str = "Du lịch trong nước";
  if (str === EInsuranceFeature.TRAVEL_02) str = "Du lịch nước ngoài";
  if (str === EInsuranceFeature.HEALTH_01) str = "Sức khỏe";
  if (str === EInsuranceFeature.HEALTH_02) str = "Ung thư";
  if (str === EInsuranceFeature.FIRE_01) str = "Cháy nổ";
  if (str === EInsuranceFeature.HOME_01) str = "Nhà tư nhân";
  if (str === EInsuranceFeature.STUDENT_01) str = "Học sinh - sinh viên";

  return str;
};
export const ARR_INSURANCE_FEATURE = [
  {
    value: EInsuranceFeature.MOTOR_01,
    label: ConvertNameFeature(EInsuranceFeature.MOTOR_01),
  },
  {
    value: EInsuranceFeature.AUTO_01,
    label: ConvertNameFeature(EInsuranceFeature.AUTO_01),
  },
  {
    value: EInsuranceFeature.PERSONAL_01,
    label: ConvertNameFeature(EInsuranceFeature.PERSONAL_01),
  },
  {
    value: EInsuranceFeature.PERSONAL_02,
    label: ConvertNameFeature(EInsuranceFeature.PERSONAL_02),
  },
  {
    value: EInsuranceFeature.TRAVEL_01,
    label: ConvertNameFeature(EInsuranceFeature.TRAVEL_01),
  },
  {
    value: EInsuranceFeature.TRAVEL_02,
    label: ConvertNameFeature(EInsuranceFeature.TRAVEL_02),
  },
  {
    value: EInsuranceFeature.STUDENT_01,
    label: ConvertNameFeature(EInsuranceFeature.STUDENT_01),
  },

  {
    value: EInsuranceFeature.HEALTH_01,
    label: ConvertNameFeature(EInsuranceFeature.HEALTH_01),
  },

  {
    value: EInsuranceFeature.HEALTH_02,
    label: ConvertNameFeature(EInsuranceFeature.HEALTH_02),
  },
  {
    value: EInsuranceFeature.FIRE_01,
    label: ConvertNameFeature(EInsuranceFeature.FIRE_01),
  },
  {
    value: EInsuranceFeature.HOME_01,
    label: ConvertNameFeature(EInsuranceFeature.HOME_01),
  },
];

// bảo hiểm ô tô, XE MÁY, sức khoe PVI, MIC, VBI
// Tai nạn cá nhân, nhà tư nhân, tai nạn mở rộng, CHÁY NỔ, học sinh, ung thư thì ko có
// Du lịch trong nước quốc tế có PVI, BIC
//

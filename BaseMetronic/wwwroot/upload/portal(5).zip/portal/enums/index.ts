export enum EWsEvent {
  APP_LOGIN_PORTAL = "APP_LOGIN_PORTAL",
}

export enum EQrCodeType {
  CALL_API = "CALL_API",
  REFER = "REFER",
  LOGIN_PORTAL = "LOGIN_PORTAL",
}

export enum EInstructionGroup {
  APP_01 = "APP_01",
  APP_02 = "APP_02",
  APP_03 = "APP_03",

  AFFILIATE_01 = "AFFILIATE_01",
  AFFILIATE_02 = "AFFILIATE_02",

  OTHER = "OTHER",
}

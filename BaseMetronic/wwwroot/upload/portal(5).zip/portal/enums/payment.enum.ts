export enum ETransactionStatus {
  PENDING = "PENDING",
  SUCCESS = "SUCCESS",
  FAILED = "FAILED",
  CANCELLED = "CANCELLED",
}

export enum EWithdrawTransactionStatus {
  PENDING = "PENDING",
  CS_REJECTED = "CS_REJECTED", // cs
  CS_ACCEPTED = "CS_ACCEPTED", // cs
  ACCOUNTANT_PAID = "ACCOUNTANT_PAID", // accountant
}

export enum EBank {
  BIDV = "BIDV",
}

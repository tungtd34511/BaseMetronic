import { NextRouter } from "next/router";
import { PropsWithChildren, ReactElement } from "react";

export interface ILayoutProps {
  breadcrumbs?: {
    label: string | ((router: NextRouter) => string);
    href: string | ((router: NextRouter) => string);
  }[];
}

// eslint-disable-next-line @typescript-eslint/no-empty-interface
export interface IPageProps {
  layout: (props: PropsWithChildren<ILayoutProps>) => ReactElement;
  layoutProps: ILayoutProps;
  disableAuth?: boolean;
  adminRequired?: boolean;
}

export interface IProcessEnv {
  // app
  PORT: number | string;
  NODE_ENV: string;
}

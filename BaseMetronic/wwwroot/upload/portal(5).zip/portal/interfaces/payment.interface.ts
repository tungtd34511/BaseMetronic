import { EWithdrawTransactionStatus } from "enums/payment.enum";

export interface IWithdrawTransaction {
  id: string;
  status: EWithdrawTransactionStatus;
  userId: string; // agency
  totalAmount: number;
  submitFileUrl: string; // sheet
  csUserId?: string; // cs id
  csFileUrl?: string; // sheet
  csFeedback?: string;
  accountantUserId?: string; // cs id
  accountantFileUrl?: string; // sheet
  notes?: string[];
}

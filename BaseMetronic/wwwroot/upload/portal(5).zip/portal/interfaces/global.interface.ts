export interface ListResponse<T = unknown> {
  pagingCounter: number;
  offset: number;
  hasNextPage: boolean;
  hasPrevPage: boolean;
  totalDocs: number;
  totalPages: number;
  limit: number;
  page: number;
  docs: T[];
}

export interface ReportResponse<T = unknown, Y = T> {
  totalDocs: number;
  accumulate: Y;
  docs: T[];
}

import { EUserRole } from "src/hooks/useRole";
export interface IUser {
  id: string;
  zaloId?: string;
  name: string;
  avatar: string;
  zaloOAId?: string;
  phone?: string;
  roles?: EUserRole[];
  tags?:string[];
}

export interface IUserDetails {
  fullName: string;
  birthday: Date;
  gender: string;
  phone: string;
  address: string; // CMND/CCCD
  IDCardNum: string;
  dateOfIssue: Date;
  issuedBy: string;
  dueDate: Date; // payment
  bankAccNum: string;
  bankAccName: string;
  bankName: string;
  taxCode?: string;
  IDCardImages: string[];
  cardImages: string[];
  signImage: string;
  isVertified : boolean;
  contractSented : boolean;
}

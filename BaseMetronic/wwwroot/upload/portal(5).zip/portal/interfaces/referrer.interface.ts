import { EVoucherStatus } from "store/APIs/referrer";
import { IInsurance } from "./insurance.interface";
import { IUser } from "./user.interfaces";

export interface IReferrerCommissionLevelLog {
  referrerId: string;
  referrerName: string;
  originalAmount: number;

  tax: number;
  amount: number; // = origin amount - tax
  discount: number;
}

export interface IReferrerSetting {
  commissionPercentDirectRefer: number;
  commissionPercentIndirectRefer: number;
  basePriceTax?: number;
  commissionTax?: number;
}

export interface IReferrerCommissionLog {
  // customer
  userId: string;
  userName: string;
  revenue: number;
  revenueCalcCommission: number;
  originalCommission: number;
  insuranceId: string; // insurance
  directReferrer?: IReferrerCommissionLevelLog;
  indirectReferrer?: IReferrerCommissionLevelLog;
  setting: IReferrerSetting;
  createdAt?: Date;
}

export interface IInsuranceReport {
  date: string;
  hasReferrerCount: number;
  createdCount: number;
  paidCount: number;
  finishedCount: number;
  discount: number;
  revenue: number;
}

export interface IReferrerAccessLogReport {
  // customer
  date: string;
  accessCount: number;
  createCount: number;
  paidCount: number;
  successCount: number;
}

export interface IReferrerCommissionLogReport {
  date: string;
  originalAmount: number;
  tax: number;
  amount: number;
  preCalcAmount: number;
  revenueCalcCommission: number;
  commissionFromAgent: number;
  revenueCalcFromAgent: number;
}

export interface ICommissionTotal {
  revenueCalcCommission: number;
  preCalcAmount: number;
  originalAmount: number;
  tax: number;
  amount: number;
  discount: number;
}

export interface ICommissionDetails {
  // customer
  docs: (ICommissionTotal &
    IReferrerCommissionLogReport & { user: IUser; insurance: IInsurance })[];
  totalDocs: number;
  accumulate: ICommissionTotal;
}

export interface ICommission {
  paidCommission: ICommissionDetails;
  pendingCommission: ICommissionDetails;
  unpaidCommission: ICommissionDetails;
  preCalcCommission: ICommissionDetails;
}

export interface IVoucher {
  id?: string;
  agencyId: string;
  agencyName: string;
  planName: string;
  description: string;
  value: number;
  code: string;
  qty: number;
  remainingQty: number;
  startDate: Date;
  endDate: Date;

  status?: EVoucherStatus;
}


export interface IVoucherV2 {
  "_id": string,
  "id": string,
  "batchName": string,
  "feature": string,
  "amount": number,
  "startDate": string,
  "endDate": string,
  "quantity": number,
  "createdAt": string,
  "createdBy": string,
  "updatedAt": string,
  "updatedBy": string,
  "deleted": boolean,
  "__v": 0
}

export interface ICreateVoucherV2 {
  "id"?: string,
  "batchName": string,
  "feature": string,
  "amount": number,
  "startDate": string,
  "endDate": string,
  "quantity": string
}

export interface ICreateInsurancePolicy {
  "commissionPercentDirectRefer": string,
  "commissionPercentIndirectRefer": string,
  "basePriceTax": string,
  "commissionTax": string,
  "feature": string,
  "id":string,
  "createdAt"?:string
}
export interface IVoucherDetailV2 {
  "_id": string,
  "code": string,
  "status": string,
  "userUsedId": string,
  "usedDate": string,
  "batchId": string,
  "createdAt": string,
  "updatedAt": string,
}


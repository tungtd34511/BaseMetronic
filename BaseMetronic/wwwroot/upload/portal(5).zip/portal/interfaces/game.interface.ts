export enum EGameType {
    WHEEL = "WHEEL",
}

export enum EGamelogStatus {
  PENDING = "PENDING",
  SUCCESS = "SUCCESS",
  FAILED = "FAILED",
  CANCELLED = "CANCELLED",
}
export interface IGameLog {
    id: string;
    gameType: EGameType;
    userId: string;
    reward: string;
    platform: string;
    date: Date;
    status: EGamelogStatus;
}
export interface IGameconfigs {
    id: string;
    gameType: EGameType;
    tryTime: number;
    config?: any;
}


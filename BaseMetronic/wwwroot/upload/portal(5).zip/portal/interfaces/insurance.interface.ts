import {
  EInsuranceFeature,
  EInsuranceGroup,
  EInsuranceSource,
} from "enums/insurance.enum";

export interface ICreateMotorRequestBody {
  ma_giaodich: string; // generate
  ten_nguoimua_bh: string;
  diachi_nguoimua_bh: string;
  TenKH: string;
  DiaChiKH: string;
  ngay_dau: string;
  ngay_cuoi: string;
  bien_kiemsoat: string;
  so_may?: string;
  so_khung?: string;
  loai_xe: string;
  nhan_hieu: string;
  nam_sanxuat: string;
  ten_chuxe: string;
  email: string;
  so_dienthoai: string;
  dia_chi: string;
  thamgia_laiphu: boolean;
  muc_trachnhiem_laiphu: number; // 0
  so_nguoi_tgia_laiphu: number; //2
  an_bien_ks: "false";
  ma_user: ""; // TODO: ???????/
  CpId: string;
  Sign: string;
}

export interface ICreateAutoRequestBody {
  ma_giaodich: string;
  DienThoai: string;
  TenKH: string;
  DiaChiKH: string;
  TenChuXe: string;
  DiaChiChuXe: string;
  EmailKH: string;
  LoaiXe: string;
  TenLoaiXe: string;
  TrongTai?: number;
  BienKiemSoat: string;
  SoKhung: string;
  SoMay: string;
  NgayDau: string;
  NgayCuoi: string;
  GioDau: string;
  GioCuoi: string;
  NamSX: string;
  NamSD: string;
  ThamGiaLaiPhu: boolean;
  MTNLaiPhu: string;
  SoNguoiToiDa: string;
  PhiBHLaiPhu: string;
  ChoNgoi: number;
  PhiBHTNDSBB: string;
  HieuXe: string;
  DongXe: string;
  AnBKS: boolean;
  AnPhi: boolean;
  TongPhi: number;
  MaMucDichSD: string;
  MayKeo: boolean;
  XeChuyenDung: boolean;
  XeChoTien: boolean;
  XePickUp: boolean;
  XeTaiVan: boolean;
  XeTapLai: boolean;
  XeBus: boolean;
  XeCuuThuong: boolean;
  Xetaxi: boolean;
  XeDauKeo: boolean;

  CpId: string;
  Sign: string;
}

export interface ICreateMotorInsuranceParams {
  transactionId?: string; //generate
  userName: string;
  userAddress: string;
  licensePlates: string;
  email?: string;
  phone: string;
  label?: string;
  category: string; // loai xe
  mfgDate?: string;
  expiry: number;
  startDate: string | Date;
  identityCardNum: string;
  occupantInsurance?: number;
  referrerId?: string;
  feature?: EInsuranceFeature;
}

export interface ICreateAutoInsuranceParams {
  transactionId?: string; // generate

  userName: string;
  userAddress: string;
  email: string;
  phone: string;
  identityCardNum: string;

  userIntent: string; // code
  automaker?: string; // hieu xe -code
  label?: string; // dong xe - code
  seats: number;
  vehicleLoad: number; // tai trong - kg
  type: string;

  mfgDate?: string;
  licensePlates: string;
  chassisNumber?: string;
  engineNumber?: string;

  startDate: string | number;

  expiry: number;
  occupantInsurance?: number;
  referrerId?: string;
  feature?: EInsuranceFeature;
  // public double mtn_laiphu { get; set; }
  //        public double so_nguoi { get; set; }
  //    public bool thamgia_laiphu { get; set; }
  // public double philpx_nhap { get; set; }
  // public bool thamgia_tndsbb { get; set; }//Set true
  // public string ma_loaixe { get; set; }
}

export interface IInsurance {
  id: string;

  userId: string;
  data: ICreateMotorInsuranceParams | ICreateAutoInsuranceParams | any;

  source: EInsuranceSource;

  feature: EInsuranceFeature;

  transactionId: string;

  fee: number;

  discount?: number;

  createBody?: ICreateMotorRequestBody | ICreateAutoRequestBody | any;

  createResponse?: any;

  callbackResponse?: any;

  createdAt?: Date;

  updatedTime?: number;
}

export interface IInsuranceFeatureResponse {
  group: EInsuranceGroup;
  feature: EInsuranceFeature;
  title: string;
  description: string;
  isCommingSoon?: boolean;
  sources?: EInsuranceSource[];
}

export interface IInsuranceGroupResponse {
  title: string;
  value?: EInsuranceGroup;
}

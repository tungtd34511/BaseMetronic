import { combineReducers, configureStore } from "@reduxjs/toolkit";
import type { PreloadedState } from "@reduxjs/toolkit";
import { userApi } from "./APIs/user";
import globalReducer, { globalSlice } from "./modules/global";
import { storageApi } from "./APIs/storage";
import { referrerApi } from "./APIs/referrer";
import { insuranceApi } from "./APIs/insurance";
import { appApi } from "./APIs/app";
import { gameApi } from "./APIs/game";
import { contractApi } from "./APIs/contract";
import {transactionApi} from "./APIs/transaction";
import { configurationApi } from "./APIs/configuration";

const rootReducer = combineReducers({
  [globalSlice.name]: globalReducer,
  [userApi.reducerPath]: userApi.reducer,
  [storageApi.reducerPath]: storageApi.reducer,
  [referrerApi.reducerPath]: referrerApi.reducer,
  [insuranceApi.reducerPath]: insuranceApi.reducer,
  [gameApi.reducerPath]: gameApi.reducer,
  [appApi.reducerPath]: appApi.reducer,
  [contractApi.reducerPath]: contractApi.reducer,
  [transactionApi.reducerPath]: transactionApi.reducer,
  [configurationApi.reducerPath]: configurationApi.reducer,
});

export const setupStore = (preloadedState?: PreloadedState<RootState>) => {
  return configureStore({
    reducer: rootReducer,
    middleware: (getDefaultMiddleware) =>
      // adding the api middleware enables caching, invalidation, polling and other features of `rtk-query`
      getDefaultMiddleware()
        .concat(userApi.middleware)
        .concat(referrerApi.middleware)
        .concat(insuranceApi.middleware)
        .concat(appApi.middleware)
        .concat(gameApi.middleware)
        .concat(storageApi.middleware)
        .concat(contractApi.middleware)
        .concat(transactionApi.middleware),
    preloadedState,
  });
};

export type RootState = ReturnType<typeof rootReducer>;
export type AppStore = ReturnType<typeof setupStore>;
export type AppDispatch = AppStore["dispatch"];

export const store = setupStore();

import { createApi } from "@reduxjs/toolkit/query/react";
import { getBaseQuery } from "./base";
import { METHOD } from "./const";
export const uploadApi = createApi({
    reducerPath: "upload-lots",
    baseQuery: getBaseQuery(),
    endpoints: (builder) => ({
        // Tham số 1 là response trả về
        // Tham số 2 là giá trị truyền lên
        // uploadLots: builder.mutation<any, never[]>({
        //     query: (body) => ({
        //         url: `/admin/games/createConfig`,
        //         method: METHOD.POST,
        //         body,
        //     }),
        // }),
    }),
});
export const {
    // useUploadLotsMutation,
} = uploadApi;

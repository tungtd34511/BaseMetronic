import { createApi } from "@reduxjs/toolkit/query/react";
import { ListResponse } from "interfaces/global.interface";
import { IUser, IUserDetails } from "interfaces/user.interfaces";
import { isUndefined, omitBy } from "lodash";

import { getBaseQuery } from "./base";

export const userApi = createApi({
  reducerPath: "userApi",
  tagTypes: ["user"],
  baseQuery: getBaseQuery(),

  endpoints: (builder) => ({
    getUserList: builder.query<
      ListResponse<IUser>,
      {
        page: number;
        limit: number;
        isAgency?: boolean;
        search?: string;
      }
    >({
      query: (data) =>
        `/admin/user/list?${new URLSearchParams(
          omitBy(data, isUndefined) as any
        ).toString()}`,
      providesTags: ["user"],
    }),

    getUserFilter: builder.query<
        ListResponse<IUser>, {}
    >({
      query: (data) =>
          `/admin/user/filter?${new URLSearchParams(
              data as any
          ).toString()}`,
      providesTags: ["user"],
    }),

    getAgencyList: builder.query<
      ListResponse<IUser>,
      {
        page: number;
        limit: number;
        search?: string;
        admin?: boolean;
      }
    >({
      query: (data) =>
        `/my/user/agency?${new URLSearchParams(
          omitBy(data, isUndefined) as any
        ).toString()}`,
      providesTags: ["user"],
    }),

    getAgencyListV2: builder.query<
        ListResponse<IUser>, {}
    >({
      query: (data) =>
          `/my/user/agency-v2?${new URLSearchParams(
              data as any
          ).toString()}`,
      providesTags: ["user"],
    }),

    getAgencyAdminList: builder.query<
        ListResponse<IUser>, {}
    >({
      query: (data) =>
          `/admin/user/agency?${new URLSearchParams(
              data as any
          ).toString()}`,
      providesTags: ["user"],
    }),

    getMyUserInfo: builder.query<IUser & { email: string }, void>({
      query: () => `/my/user`,
      providesTags: ["user"],
    }),

    login: builder.mutation<
      {
        user: IUser;
        jwtAccessToken: string;
      },
      { email: string; password: string }
    >({
      query: (data) => ({
        url: `/public/user/login/pwd`,
        method: "POST",
        body: data,
      }),
      invalidatesTags: ["user"],
    }),

    loginBySignedStr: builder.mutation<
      {
        user: IUser;
        jwtAccessToken: string;
      },
      { signedStr: string }
    >({
      query: (data) => ({
        url: `/public/user/login-portal/verify-signed`,
        method: "POST",
        body: data,
      }),
      invalidatesTags: ["user"],
    }),

    changePassword: builder.mutation<
      {
        user: IUser;
        jwtAccessToken: string;
      },
      { email: string; password: string }
    >({
      query: (data) => ({
        url: `/my/user/change-pwd`,
        method: "POST",
        body: data,
      }),
      invalidatesTags: ["user"],
    }),

    updateDetails: builder.mutation<IUserDetails, IUserDetails>({
      query: (data) => ({
        url: `/my/user/details`,
        method: "PUT",
        body: data,
      }),
      invalidatesTags: ["user"],
    }),
    getUserDetails: builder.query<IUserDetails, void>({
      query: () => ({
        url: `/my/user/details`,
      }),
      providesTags: ["user"],
    }),
    getUserDetailsList: builder.query<
      ListResponse<IUser>,
      {
        page: number;
        limit: number;
        isVertified?: boolean;
        search?: string;
      }
    >({
      query: (data) =>
        `/admin/user/list-userdetail?${new URLSearchParams(
          omitBy(data, isUndefined) as any
        ).toString()}`,
      providesTags: ["user"],
    }),
  }),
});

export const {
  useGetMyUserInfoQuery,
  useGetUserListQuery,
  useLazyGetUserFilterQuery,
  useGetAgencyListQuery,
  useLazyGetAgencyListV2Query,
  useLazyGetAgencyAdminListQuery,
  useGetUserDetailsQuery,
  useGetUserDetailsListQuery,
  //mutation
  useLoginMutation,
  useChangePasswordMutation,
  useUpdateDetailsMutation,
  useLoginBySignedStrMutation,
} = userApi;

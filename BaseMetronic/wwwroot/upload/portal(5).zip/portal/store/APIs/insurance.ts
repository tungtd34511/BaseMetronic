import { createApi } from "@reduxjs/toolkit/query/react";
import { ListResponse } from "interfaces/global.interface";
import {
  IInsurance,
  IInsuranceFeatureResponse,
  IInsuranceGroupResponse,
} from "interfaces/insurance.interface";
import { IUser } from "interfaces/user.interfaces";
import { isUndefined, omitBy } from "lodash";

import { getBaseQuery } from "./base";

export const insuranceApi = createApi({
  reducerPath: "insuranceApi",
  tagTypes: ["insurance"],
  baseQuery: getBaseQuery(),

  endpoints: (builder) => ({
    // public
    getInsuranceServices: builder.query<
      {
        features: IInsuranceFeatureResponse[];
        groups: IInsuranceGroupResponse[];
      },
      void
    >({
      query: () => `/public/insurance/config`,
    }),
    // admin
    getTransactionHistory: builder.query<
      ListResponse<IUser>,
      {
        page: number;
        limit: number;
        userId?: string;
      }
    >({
      query: (data) =>
        `/admin/insurance?${new URLSearchParams(
          omitBy(data, isUndefined) as any
        ).toString()}`,
      providesTags: ["insurance"],
    }),

    //
    searchInsurance: builder.query<
      ListResponse<IInsurance>,
      {
        page: number;
        limit: number;
        licensePlates: string;
      }
    >({
      query: (data) =>
        `/cs/insurance/search?${new URLSearchParams(
          omitBy(data, isUndefined) as any
        ).toString()}`,
      providesTags: ["insurance"],
    }),

    getInsurance: builder.query<
      IInsurance,
      {
        insuranceId: string;
      }
    >({
      query: (data) => ({
        url: `/cs/insurance/${data.insuranceId}`,
      }),
      providesTags: ["insurance"],
    }),

    updateInsurance: builder.mutation<
      ListResponse<IInsurance>,
      {
        userName: string;
        userAddress: string;
        licensePlates: string;
        insuranceId: string;
      }
    >({
      query: (data) => ({
        url: `/cs/insurance/${data.insuranceId}`,
        method: "PUT",
        body: data,
      }),
      invalidatesTags: ["insurance"],
    }),

    // cs
    csGetReport: builder.query<
      ListResponse<any>,
      {
        from: number;
        to: number;
        limit: number;
        page: number;
      }
    >({
      query: (data) =>
        `/cs/insurance/report?${new URLSearchParams(data as any).toString()}`,
      providesTags: ["insurance"],
    }),

    offlineImportInsurance: builder.mutation<
      ListResponse<any>,
      {
        ExcelFile: string,
        GcnFiles: string [],
        insuranceType: string,
        companyName: string, 
        isCalcCommission: boolean,        
        startDate: string,
        overwriteReferrer: boolean,
        overwriteReferrerId: string
      }
    >({
      query: (data) => ({
        url: `/admin/insurance/offline-import`,
        method: "POST",
        body: data,
      }),
      invalidatesTags: ["insurance"],
    }),
  }),
});

export const {
  useGetInsuranceServicesQuery,
  useGetTransactionHistoryQuery,
  useSearchInsuranceQuery,
  useGetInsuranceQuery,
  useLazySearchInsuranceQuery,
  useUpdateInsuranceMutation,
  useCsGetReportQuery,
  useOfflineImportInsuranceMutation,
} = insuranceApi;

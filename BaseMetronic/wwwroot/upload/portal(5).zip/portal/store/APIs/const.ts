import {EUserRole} from "../../src/hooks/useRole";

export const METHOD = {
    GET: 'GET',
    POST: 'POST',
    PUT: 'PUT',
    DELETE:'DELETE'
}
import { validateEmail, validateIdCard, validateMaxLength, validatePhoneNumber } from 'src/common/Validate';
import { ARR_INSURANCE_SOURCE, ARR_INSURANCE_SOURCE_CAPACITY, EInsuranceFeature, EInsuranceSource } from './../../enums/insurance.enum';
import moment from "moment";
import { CIdCard, MICHealthTypeValue } from './common';

export const DEFAULT_VALUE_EMPTY = ''
export const DEFAULT_PAGE_START = 1
const lastMonth = moment().subtract(1, 'months').toISOString(true);
const currentMonth = moment().toISOString(true);
export const USER_PARAMS_FILTER = {
    userId: null,
    name: null,
    role: null,
    page: DEFAULT_PAGE_START,
    limit: 15
}

export const AGENCY_PARAMS_FILTER = {
    userId: null,
    name: null,
    page: DEFAULT_PAGE_START,
    limit: 15
}

export const INSURANCE_ONLINE_PARAMS_FILTER = {
    insuranceId: null,
    buyerId: null,
    buyerName: null,
    idCardNumber: null,
    feature: null,
    source: null,
    page: DEFAULT_PAGE_START,
    limit: 15,
    from: lastMonth as any,
    to: currentMonth as any
}

export const DEFAULT_PARAMS_FILTER = {
    insuranceId: null,
    customerName: null,
    companyName: null,
    referrerId: null,
    feature: null,
    source: null,
    page: DEFAULT_PAGE_START,
    limit: 15,
    from: lastMonth as any,
    to: currentMonth as any
}
export const TYPE_ARR_INPUT = {
    INPUT: 'INPUT',
    DATE_PICKER: 'DATE_PICKER',
    SELECT: 'SELECT',
    INPUT_NUMBER: 'INPUT_NUMBER',
    INPUT_PRICE: 'INPUT_PRICE',
    SWITCH: 'SWITCH'

}
export const PRESS = 'Điền'
export const NOT_EMPTY = 'không được để trống'

export const ARR_INPUT_MOTOR_BENIFIT = [
    {
        id: 'beneficiaryName',
        label: 'Tên người thụ hưởng',
        type: TYPE_ARR_INPUT.INPUT,
        placeholder: `${PRESS} tên người thụ hưởng`,
        rules: [
            {
                required: true,
                message: `Tên người thụ hưởng ${NOT_EMPTY}`
            },
            {
                pattern: validateMaxLength(50).regexPattern,
                message: validateMaxLength(50).message
            },
        ]
    },
    {
        id: 'beneficiaryAddress',
        label: 'Địa chỉ',
        type: TYPE_ARR_INPUT.INPUT,
        placeholder: `${PRESS} địa chỉ người thụ hưởng`,
        rules: [
            { required: true, message: `Địa chỉ ${NOT_EMPTY}` },
            {
                pattern: validateMaxLength(100).regexPattern,
                message: validateMaxLength(100).message
            },
        ]
    },
    {
        id: 'beneficiaryPhone',
        label: 'Số điện thoại',
        type: TYPE_ARR_INPUT.INPUT,
        placeholder: `${PRESS} số điện thoại người thụ hưởng `,
        rules: [
            { required: true, message: `Số điện thoại ${NOT_EMPTY}` },
            {
                pattern: validatePhoneNumber().regexPattern,
                message: validatePhoneNumber().message
            },

        ]
    },
    {
        id: 'beneficiaryEmail',
        label: `Email`,
        type: TYPE_ARR_INPUT.INPUT,
        placeholder: `${PRESS} email người thụ hưởng`,
        rules: [
            { required: true, message: `Email ${NOT_EMPTY}` },
            {
                pattern: validateEmail().regexPattern,
                message: validateEmail().message
            },

        ]
    },
    CIdCard('beneficiaryIdCard', true),
]

export const HEALTH_CONDITION_BIC: { label: string }[] = [
    // {
    //   label:
    //     "Bạn hoặc bất kỳ thành viên nào trong gia đình hoặc người được bảo hiểm nào mắc bệnh bẩm sinh, khuyết tật hay thương tật nào không?",
    // },
    // {
    //   label:
    //     "Bạn hoặc bất kỳ thành viên nào trong gia đình hoặc người được bảo hiểm nào mắc bệnh bẩm sinh, khuyết tật hay thương tật nào không?",
    // },
    {
        label:
            "Bạn hoặc bất kỳ thành viên nào trong gia đình hoặc người được bảo hiểm nào mắc bệnh bẩm sinh, khuyết tật hay thương tật nào không?",
    },
    {
        label:
            "Người được bảo hiểm có tham gia hợp đồng bảo hiểm sức khỏe tại BIC hoặc tại Công ty bảo hiểm khác trong vòng 5 năm gần đây không?",
    },
    {
        label:
            "Người được bảo hiểm đã từng yêu cầu bồi thường bảo hiểm y tế, tại nạn con người tại BIC chưa?",
    },
    {
        label:
            "Người được bảo hiểm đã bao giờ bị một công ty bảo hiểm từ chối nhận bảo hiểm hoặc từ chối tái tục hợp đồng bảo hiểm sức khỏe hoặc được chấp nhận nhưng có các điều khoản bổ sung đặc biệt đi kèm chưa?",
    },
];
export const HEALTH_CONDITION_MIC: { label: string }[] = [
    {
        label:
            "Người được bảo hiểm có thuộc các trường hợp dưới đây hay không? \n"
            + "- Những người bị bệnh tâm thần, bệnh phong, hội chứng down, tự kỷ \n"
            + "- Những người bị thương tật vĩnh viễn từ 50% trở lên \n"
            + "- Những người đang trong thời gian điều trị bệnh hoặc thương tật hoặc bị ung thư \n"
            + "Điều này chỉ áp dụng đối với các trường hợp tham gia bảo hiểm năm đầu tiên.\n"
    },
    {
        label:
            "Trong vòng 3 năm qua, Người được bảo hiểm đã từng được chẩn đoán, xuất hiện triệu chứng phải đi khám, điều trị hay đã được chuyên gia y tế khuyên Người được bảo hiểm phải điều trị hay không? \n"
            + "Lưu ý: \n"
            + "Người được bảo hiểm không trả lời ‘CÓ” đối với các bệnh/ tình trạng y tế dưới đây: \n"
            + "- Phụ nữ sinh con (sinh thường, sinh mổ) mà không có biến chứng thai sản \n"
            + "- Cúm và cảm lạnh theo mùa thông thường, viêm dạ dày cấp tính, viêm ruột thừa cấp tính, viêm amidan cấp tính, nhiễm trùng đường tiết niệu, bệnh tả, thương hàn, sốt xuất huyết mà Người được bảo hiểm đã được điều trị và đã hồi phục hoàn toàn hoặc nếu Người được bảo hiểm sử dụng bất kỳ loại thực phẩm bổ sung sức khỏe tổng quát nào. \n"
    },
    {
        label:
            "Viêm hệ thần kinh trung ương (Não) ?",
    },
    {
        label:
            "Parkinson, Alzheimer?",
    },
    {
        label:
            "Thoái hóa khác của hệ thần kinh?",
    },
    {
        label:
            "Mất trí nhớ, hôn mê, bại não, liệt?",
    },
    {
        label:
            "Bỏng dưới độ III?",
    },
    {
        label:
            "Bỏng nặng từ độ III trở lên?",
    },
    {
        label:
            "Hội chứng Apallic?",
    },
    {
        label:
            "Phẫu thuật não?",
    },
    {
        label:
            "Viêm màng não, viêm não do virus?",
    },
    {
        label:
            "Bệnh tế bảo thân kinh vận động?",
    },
    {
        label:
            "Xơ cứng rải rác (đa xơ cứng)?",
    },
    {
        label:
            "Loạn dưỡng cơ?",
    },
    {
        label:
            "Nhược cơ?",
    },
    {
        label:
            "Suy phổi, tràn khí phổi, suy hô hấp mãn tính?",
    },
    {
        label:
            "Phẫu thuật cất bỏ 1 bên phổi?",
    },
    {
        label:
            "Tăng áp động mạch phối?",
    },
    {
        label:
            "Bệnh phổi giai đoạn cuối?",
    },
    {
        label:
            "Tim?",
    },
    {
        label:
            "Tăng áp lực động mạch vành vô căn?",
    },
    {
        label:
            "Mạch máu não/đột quy (xuất huyết não, xơ cứng động mạch)?",
    },
    {
        label:
            "Nhồi máu cơ tim, suy tìm mắt bù, bệnh tim giai đoạn cuối?",
    },
    {
        label:
            "Phẫu thuật động mạch chủ/van tim, ghép tim?",
    },
    {
        label:
            "Phẫu thuật nối tắt động mạch vành?",
    },
    {
        label:
            "Viêm gan A?",
    },
    {
        label:
            "Viêm gan B?",
    },
    {
        label:
            "Viêm gan C?",
    },
    {
        label:
            "Viêm gan siêu vi tối cấp?",
    },
    {
        label:
            "Xơ gan?",
    },
    {
        label:
            "Bệnh Crohn?",
    },
    {
        label:
            "Phẫu thuật gan?",
    },
    {
        label:
            "Suy gan (bệnh gan giai đoạn cuối)?",
    },
    {
        label:
            "Suy thận, teo thận, sỏi thận cả 2 bên?",
    },
    {
        label:
            "Chạy thận nhân tạo?",
    },
    {
        label:
            "Rối loạn tuyến giá?",
    },
    {
        label:
            "Cường giáp?",
    },
    {
        label:
            "Suy giáp?",
    },
    {
        label:
            "Basedow (Bướu cổ)?",
    },
    {
        label:
            "Tiểu đường chỉ số trên 11 mmol/l \n "
            + "Tiểu đường đã gây biến chứng",
    },
    {
        label:
            "Tiểu đường chỉ số từ 8 - 10 mmol/l?",
    },
    {
        label:
            "U xơ tử cung?",
    },
    {
        label:
            "U nang buông trứng?",
    },
    {
        label:
            "U xơ tiền liệt?",
    },
    {
        label:
            "U thượng thận trái (đã cắt hoặc chưa cắt)?",
    },
    {
        label:
            "Ung thư các loại?",
    },
    {
        label:
            "Thiếu máu bất sản, thiếu máu tán huyết, thiếu máu do suy tủy?",
    },
    {
        label:
            "Rối loạn đông máu?",
    },
    {
        label:
            "Ghép tủy?",
    },
    {
        label:
            "Suy tủy?",
    },
    {
        label:
            "Lupus ban đỏ?",
    },
    {
        label:
            "Xơ cứng bì toàn thân?",
    },
    {
        label:
            "Teo cơ?",
    },
    {
        label:
            "Viêm đa khớp dạng thấp nặng?",
    },
    {
        label:
            "Loãng xương?",
    },
    {
        label:
            "Loãng xương mức độ nặng?",
    },
    {
        label:
            "Ghép tủy xương?",
    },
    {
        label:
            "Điếc?",
    },
    {
        label:
            "Bệnh hệ thống tạo keo (Collagen)?",
    },
    {
        label:
            "Lao các loại?",
    },
    {
        label:
            "Phong?",
    },
    {
        label:
            "Bạch cầu?",
    },
    {
        label:
            "Các bệnh lây qua đường tình dục: Giang mai, lậu, hội chứng suy giảm miễn dịch?",
    },
    {
        label:
            "Bệnh bẩm sinh, di truyền, dị dạng về gen?",
    },
    {
        label:
            "Nang ở tủy thận?",
    },
    {
        label:
            "Hội chứng Đao (Down)?",
    },
    {
        label:
            "Đục thủy tinh thể?",
    },
    {
        label:
            "Mù 1 mắt trở lên?",
    },
    {
        label:
            "Gai đôi cột sống?",
    },
    {
        label:
            "Suy đa tạng?",
    },
    {
        label:
            "Bệnh sốt rét?",
    },
    {
        label:
            "Bệnh nghề nghiệp?",
    },
    {
        label:
            "Điều trị lọc máu?",
    },
    {
        label:
            "Rối loạn chức năng sinh dục?",
    },
    {
        label:
            "Hở môi, hở hàm ếch?",
    },
    {
        label:
            "Tích nước trong não?",
    },
    {
        label:
            "Hẹp hậu môn, hẹp bao quy đầu?",
    },
    {
        label:
            "Vẹo vách ngăn bẩm sinh?",
    },
    {
        label:
            "Tâm thần/loạn thần kinh, tự kỉ?",
    },
    {
        label:
            "Chậm phát triển, rối loạn thiếu tập trung?",
    },
];
export const HEALTH_CONDITION_BENIFIT_MIC: { label: string }[] = [
    {
        label: 'Điều trị ngoại trú do ốm đau, bệnh tật',
    },
    {
        label: 'Điều trị ngoại trú'
    },
    {
        label: 'Tử vong, thương tật toàn bộ vĩnh viễn không do nguyên nhân tai nạn'
    },
]

export const HEALTH_CONDITION_VBI: { label: string }[] = [
    {
        label: 'Thai sản',
    },
    {
        label: 'Quyền lợi nha khoa'
    },
    {
        label: 'Chăm sóc và điều trị răng ngoại trú'
    },
    {
        label: 'Trợ cấp nằm viện nội trú do tai nạn'
    },
]
export const ARR_TYPE_MIC = [
    {
        value: MICHealthTypeValue.TYPE_01,
        label: 'MIC Care'
    },
    {
        value: MICHealthTypeValue.TYPE_02,
        label: 'MIC Vững tâm sông khỏe'
    },
]
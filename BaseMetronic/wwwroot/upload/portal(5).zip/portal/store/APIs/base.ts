import { fetchBaseQuery } from "@reduxjs/toolkit/dist/query";
import { ACCESS_TOKEN_KEY } from "src/constants";

export const getBaseQuery = (baseUrl = `${process.env.API_HOST}/api`) => {
  return fetchBaseQuery({
    baseUrl,
    prepareHeaders: (headers) => {
      try {
        const accessToken =
          typeof window !== "undefined"
            ? window.localStorage.getItem(ACCESS_TOKEN_KEY)
            : "";

        if (accessToken) {
          headers.set("authorization", `Bearer ${accessToken}`);
        }
        return headers;
      } catch (error) {
        console.error(error);
      }

      return headers;
    },
  });
};

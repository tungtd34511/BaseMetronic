import { createApi } from "@reduxjs/toolkit/query/react";
import { isUndefined, omitBy } from "lodash";
import { getBaseQuery } from "./base";
import {
  EGameType,
  EGamelogStatus,
  IGameconfigs,
  IGameLog,
} from "interfaces/game.interface";
import { ListResponse } from "interfaces/global.interface";
export const gameApi = createApi({
  reducerPath: "gameApi",
  tagTypes: ["gameConfig", "gameLog"],
  baseQuery: getBaseQuery(),
  endpoints: (builder) => ({
    getGameConfigs: builder.query<
      ListResponse<IGameconfigs>,
      { page: number; limit: number; gameType: EGameType }
    >({
      query: (params) =>
        `/admin/games/configs?${new URLSearchParams(params as any).toString()}`,
      providesTags: ["gameConfig"],
    }),

    getGameLogs: builder.query<
      ListResponse<IGameLog>,
      { page: number; limit: number; from: number; to: number; userId?: string }
    >({
      query: (data) =>
        `/admin/games/logs?${new URLSearchParams({
          ...data,
          groupByDate: true,
        } as any).toString()}`,
      providesTags: ["gameLog"],
    }),
    createGameConfigs: builder.mutation<IGameconfigs, IGameconfigs>({
      query: (data) => ({
        url: `/admin/games/createConfig`,
        method: "POST",
        body: data,
      }),
      invalidatesTags: ["gameConfig"],
    }),
    updateGameConfigs: builder.mutation<IGameconfigs, IGameconfigs>({
      query: (data) => ({
        url: `/admin/games/updateConfig`,
        method: "PUT",
        body: data,
      }),
      invalidatesTags: ["gameConfig"],
    }),
    updateGameLogs: builder.mutation<IGameLog, IGameLog>({
      query: (data) => ({
        url: `/admin/games/updateGamelog`,
        method: "PUT",
        body: data,
      }),
      invalidatesTags: ["gameLog"],
    }),
  }),
});
export const {
  useGetGameConfigsQuery,
  useGetGameLogsQuery,
  useCreateGameConfigsMutation,
  useUpdateGameConfigsMutation,
  useUpdateGameLogsMutation,
} = gameApi;

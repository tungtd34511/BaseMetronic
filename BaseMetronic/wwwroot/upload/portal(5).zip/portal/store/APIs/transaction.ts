import {createApi} from "@reduxjs/toolkit/query/react";

import {getBaseQuery} from "./base";

export enum TransactionStatus {
  PENDING = 'PENDING',
  SUCCESS = 'SUCCESS',
  FAILED = 'FAILED',
  CANCELLED = 'CANCELLED',
}

export enum Bank {
  BIDV = 'BIDV',
}

interface DetailTransactionOutput {
  id: string;
  userId: string;
  status: TransactionStatus;
  billId: string;
  originalAmount: number;
  amount: number;
  expireAt: number;
  customerId: string;
  accountNumber: string;
  bank?: Bank;
  rawData?: any;
  metaData?: any;
  createdAt: Date;
}

interface DetailTransactionIPNOutputDTO {
  tnxId: string;
  callback: any;
  provider: string;
  response: any;
  createdTime: Date;
}

export const transactionApi = createApi({
  reducerPath: "transactionApi", tagTypes: ["transactions"], baseQuery: getBaseQuery(),

  endpoints: (builder) => ({
    getTransactionDetail: builder.query<DetailTransactionOutput, {}>({
      query: (id: string) => ({
        url: `admin/payment/transaction/${id}`,
      }),
    }),

    getTransactionIPNDetail: builder.query<DetailTransactionIPNOutputDTO, {}>({
      query: (id: string) => ({
        url: `admin/payment/transaction/ipn/${id}`,
      }),
    }),
  }),
});

export const {
  useLazyGetTransactionDetailQuery,
  useLazyGetTransactionIPNDetailQuery
} = transactionApi;

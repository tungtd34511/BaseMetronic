import { createApi } from "@reduxjs/toolkit/query/react";

import { getBaseQuery } from "./base";
import { IAppConfig } from "interfaces";

export const appApi = createApi({
  reducerPath: "appApi",
  tagTypes: ["app"],
  baseQuery: getBaseQuery(),

  endpoints: (builder) => ({
    getAppConfig: builder.query<IAppConfig, void>({
      query: () => ({
        url: `/config`,
      }),
      providesTags: ["app"],
    }),
  }),
});

export const { useGetAppConfigQuery } = appApi;

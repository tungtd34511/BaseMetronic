import { createApi } from "@reduxjs/toolkit/query/react";
import { EWithdrawTransactionStatus } from "enums/payment.enum";
import { ListResponse, ReportResponse } from "interfaces/global.interface";
import { IWithdrawTransaction } from "interfaces/payment.interface";
import {
  ICommission,
  ICreateVoucherV2,
  IInsuranceReport,
  IReferrerAccessLogReport,
  IReferrerCommissionLog,
  IReferrerCommissionLogReport,
  IReferrerSetting,
  IVoucher,
  IVoucherDetailV2,
  IVoucherV2,
} from "interfaces/referrer.interface";

import { getBaseQuery } from "./base";

export enum EVoucherStatus {
  DRAFT = "DRAFT",
  SUBMITTED = "SUBMITTED",
  APPROVED = "APPROVED",
  REJECTED = "REJECTED",
  CANCELLED = "CANCELLED",
}

export const referrerApi = createApi({
  reducerPath: "referrerApi",
  tagTypes: ["referrer", "commission", "voucher", "access"],
  baseQuery: getBaseQuery(),

  endpoints: (builder) => ({
    getCommission: builder.query<ICommission, void>({
      query: () => `/agency/referrer/commission`,
      providesTags: ["commission"],
    }),

    createWithdrawCommissionRequest: builder.mutation<
      IWithdrawTransaction,
      void
    >({
      query: () => ({
        url: `/agency/referrer/commission/payment`,
        method: "POST",
      }),

      invalidatesTags: ["commission"],
    }),

    getMyWithdrawCommissionRequest: builder.query<
      ReportResponse<IWithdrawTransaction>,
      { page?: number; limit?: number }
    >({
      query: (data) => ({
        url: `/my/payment/commission?${new URLSearchParams(
          data as any
        ).toString()}`,
      }),

      providesTags: ["commission"],
    }),

    getWithdrawCommissionRequest: builder.query<
      ReportResponse<
        IWithdrawTransaction,
        {
          totalAmount: number;
          firstId: string;
          lastId: string;
        }
      >,
      { page?: number; limit?: number; status: EWithdrawTransactionStatus }
    >({
      query: (data) => ({
        url: `/payment/commission?${new URLSearchParams(
          data as any
        ).toString()}`,
      }),

      providesTags: ["commission"],
    }),

    csReviewWithdrawCommissionRequest: builder.mutation<
      void,
      {
        transactionId: string;
        status: EWithdrawTransactionStatus;
        csFeedback?: string;
        csFileUrl?: string;
        note?: string;
      }
    >({
      query: (data) => ({
        url: `/cs/referrer/commission/${data.transactionId}`,
        method: "PUT",
        body: data,
      }),

      invalidatesTags: ["commission"],
    }),

    csGetCommissionDetails: builder.query<
      ReportResponse<any>,
      {
        page: number;
        limit: number;
        from: number;
        to: number;
      }
    >({
      query: (data) =>
        `/cs/referrer/commission?${new URLSearchParams(
          data as any
        ).toString()}`,

      providesTags: ["commission"],
    }),

    accUpdateWithdrawCommissionRequest: builder.mutation<
      void,
      {
        transactionId: string;
        status: EWithdrawTransactionStatus;
        accountantFileUrl?: string;
        note?: string;
      }
    >({
      query: (data) => ({
        url: `/acc/referrer/commission/${data.transactionId}`,
        method: "PUT",
        body: data,
      }),

      invalidatesTags: ["commission"],
    }),

    getReferrerAccessLogReport: builder.query<
      ReportResponse<IReferrerAccessLogReport>,
      { page: number; limit: number; from: number; to: number }
    >({
      query: (data) =>
        `/my/referrer/access-log/report?${new URLSearchParams({
          ...data,
          groupByDate: true,
        } as any).toString()}`,
      providesTags: ["access"],
    }),

    getMyCommissionLogReport: builder.query<
      ReportResponse<IReferrerCommissionLogReport>,
      {
        page: number;
        limit: number;
        from: number;
        to: number;
      }
    >({
      query: (data) =>
        `/my/referrer/commission-log/report?${new URLSearchParams({
          ...data,
          groupByDate: true,
        } as any).toString()}`,
      providesTags: ["access"],
    }),

    getMyCommissionLogList: builder.query<
      ListResponse<IReferrerCommissionLog>,
      {
        page: number;
        limit: number;
        from: number;
        to: number;
      }
    >({
      query: (data) =>
        `/my/referrer/commission-log/list?${new URLSearchParams({
          ...data,
        } as any).toString()}`,
      providesTags: ["commission"],
    }),

    getReferrerSetting: builder.query<Required<IReferrerSetting>, void>({
      query: () => `/my/referrer/setting`,
      providesTags: ["referrer"],
    }),

    updateReferrerSetting: builder.mutation<
      IReferrerSetting,
      Required<IReferrerSetting>
    >({
      query: (data) => ({
        url: `/admin/referrer/setting`,
        method: "PUT",
        body: data,
      }),
      invalidatesTags: ["referrer"],
    }),

    // agency

    getAgentCommissionLogReportDetails: builder.query<
      ReportResponse<
        IReferrerCommissionLog,
        {
          revenueCalcCommission: number;
          preCalcAmount: number;
          originalAmount: number;
          tax: number;
          amount: number;
        }
      >,
      {
        page: number;
        limit: number;
        from: number;
        to: number;
        agentId?: string;
      }
    >({
      query: (data) =>
        `/agency/referrer/commission-log/report/agent?${new URLSearchParams({
          ...data,
        } as any).toString()}`,
      providesTags: ["commission"],
    }),
    getMyCommissionLogReportDetails: builder.query<
      ReportResponse<
        IReferrerCommissionLog,
        {
          revenueCalcCommission: number;
          preCalcAmount: number;
          originalAmount: number;
          tax: number;
          discount: number;
          amount: number;
          convert2AgentCount: number;
        }
      >,
      {
        page: number;
        limit: number;
        from: number;
        to: number;
      }
    >({
      query: (data) =>
        `/agency/referrer/commission-log/report?${new URLSearchParams({
          ...data,
        } as any).toString()}`,
      providesTags: ["commission"],
    }),

    getAgentCommissionLogList: builder.query<
      ListResponse<IReferrerCommissionLog>,
      {
        page: number;
        limit: number;
        from: number;
        to: number;
        agentId?: string;
      }
    >({
      query: (data) =>
        `/agency/referrer/commission-log/list?${new URLSearchParams({
          ...data,
        } as any).toString()}`,
      providesTags: ["commission"],
    }),

    getListVoucher: builder.query<
      ListResponse<IVoucher>,
      { page: number; limit: number }
    >({
      query: (params) =>
        `/agency/promotion/voucher?${new URLSearchParams(
          params as any
        ).toString()}`,
      providesTags: ["voucher"],
    }),
    getListVoucherV2: builder.query<
      ListResponse<IVoucherV2>,
      { startDate: string; endDate: string; feature: string; batchName: string; }
    >({
      query: (params) =>
        `/admin/promotion/batch-voucher/search?${new URLSearchParams(
          params as any
        ).toString()}`,
      providesTags: ["voucher"],
    }),

    getVoucher: builder.query<IVoucher, { id: string }>({
      query: (params) => `/agency/promotion/voucher/${params.id}`,
      providesTags: ["voucher"],
    }),
    createVoucher: builder.mutation<IVoucher, IVoucher>({
      query: (data) => ({
        url: `/agency/promotion/voucher`,
        method: "POST",
        body: data,
      }),
      invalidatesTags: ["voucher"],
    }),

    createVoucherV2: builder.mutation<ICreateVoucherV2, ICreateVoucherV2>({
      query: (data) => ({
        url: `/admin/promotion/batch-voucher`,
        method: "POST",
        body: data,
      }),
      invalidatesTags: ["voucher"],
    }),

    updateVoucher: builder.mutation<IVoucher, IVoucher>({
      query: (data) => ({
        url: `/agency/promotion/voucher/${data.id}`,
        method: "PUT",
        body: data,
      }),
      invalidatesTags: ["voucher"],
    }),
    getDetailVoucherV2: builder.mutation<IVoucherV2, IVoucherV2>({
      query: (data) => ({
        url: `/admin/promotion/batch-voucher/${data.id}`,
        method: "GET",
        // body: data,
      }),
      // invalidatesTags: ["voucher"],
    }),
    getDetailVoucherByBatchV2: builder.mutation<ListResponse<IVoucherDetailV2>, { page: number; limit: number, id: string }>({
      query: (data) => ({
        url: `admin/promotion/voucher-codes/search?batchId=${data?.id}&page=${data?.page}&limit=${data?.limit}`,
        method: "GET",
        // body: data,
      }),
      // invalidatesTags: ["voucher"],
    }),
    updateVoucherV2: builder.mutation<ICreateVoucherV2, ICreateVoucherV2>({
      query: (data) => ({
        url: `/admin/promotion/batch-voucher/${data.id}`,
        method: "PUT",
        body: data,
      }),
      invalidatesTags: ["voucher"],
    }),

    updateAndSubmitVoucher: builder.mutation<IVoucher, IVoucher>({
      query: (data) => ({
        url: `/agency/promotion/voucher/${data.id}/submit`,
        method: "POST",
        body: data,
      }),
      invalidatesTags: ["voucher"],
    }),

    deleteVoucher: builder.mutation<IVoucher, { id: string }>({
      query: (data) => ({
        url: `/agency/promotion/voucher/${data.id}`,
        method: "DELETE",
      }),
      invalidatesTags: ["voucher"],
    }),
    deleteVoucherV2: builder.mutation<IVoucherV2, { id: string }>({
      query: (data) => ({
        url: `/admin/promotion/batch-voucher/${data.id}`,
        method: "DELETE",
      }),
      invalidatesTags: ["voucher"],
    }),
    getInsuranceReport: builder.query<
      ReportResponse<IInsuranceReport>,
      { page: number; limit: number; from: number; to: number }
    >({
      query: (data) =>
        `/admin/insurance/report?${new URLSearchParams({
          ...data,
          groupByDate: true,
        } as any).toString()}`,
      providesTags: ["access"],
    }),

    adminGetListVoucher: builder.query<
      ListResponse<IVoucher>,
      { page: number; limit: number; status: EVoucherStatus }
    >({
      query: (params) =>
        `/admin/promotion/voucher?${new URLSearchParams(
          params as any
        ).toString()}`,
      providesTags: ["voucher"],
    }),

    adminApproveVoucher: builder.mutation<IVoucher, { id: string }>({
      query: (data) => ({
        url: `/admin/promotion/voucher/${data.id}/approve`,
        method: "PUT",
      }),
      invalidatesTags: ["voucher"],
    }),

    adminRejectVoucher: builder.mutation<IVoucher, { id: string }>({
      query: (data) => ({
        url: `/admin/promotion/voucher/${data.id}/reject`,
        method: "PUT",
      }),
      invalidatesTags: ["voucher"],
    }),

    getAdminAgentCommissionLogReportDetails: builder.query<
      ReportResponse<
        IReferrerCommissionLog,
        {
          revenueCalcCommission: number;
          preCalcAmount: number;
          originalAmount: number;
          tax: number;
          amount: number;
        }
      >,
      {
        page: number;
        limit: number;
        from: number;
        to: number;
        agentId?: string;
      }
    >({
      query: (data) =>
        `/admin/referrer/commission-log/report/agent?${new URLSearchParams({
          ...data,
        } as any).toString()}`,
      providesTags: ["commission"],
    }),
  }),
});

export const {
  useGetDetailVoucherByBatchV2Mutation,
  useGetDetailVoucherV2Mutation,
  useGetListVoucherV2Query,
  useLazyGetListVoucherV2Query,
  useGetAgentCommissionLogListQuery,
  useGetMyCommissionLogListQuery,
  useGetReferrerSettingQuery,
  useGetListVoucherQuery,
  useAdminGetListVoucherQuery,
  useGetVoucherQuery,
  useGetReferrerAccessLogReportQuery,
  useGetMyCommissionLogReportQuery,
  useGetInsuranceReportQuery,
  useGetAgentCommissionLogReportDetailsQuery,
  useGetAdminAgentCommissionLogReportDetailsQuery,
  useGetMyCommissionLogReportDetailsQuery,
  useGetCommissionQuery,
  useGetWithdrawCommissionRequestQuery,
  useGetMyWithdrawCommissionRequestQuery,
  useCsGetCommissionDetailsQuery,
  useCreateVoucherV2Mutation,
  useUpdateVoucherV2Mutation,
  useCreateVoucherMutation,
  useUpdateReferrerSettingMutation,
  useUpdateAndSubmitVoucherMutation,
  useUpdateVoucherMutation,
  useDeleteVoucherMutation,
  useDeleteVoucherV2Mutation,
  useAdminApproveVoucherMutation,
  useAdminRejectVoucherMutation,
  useCreateWithdrawCommissionRequestMutation,
  useCsReviewWithdrawCommissionRequestMutation,
  useAccUpdateWithdrawCommissionRequestMutation,
} = referrerApi;

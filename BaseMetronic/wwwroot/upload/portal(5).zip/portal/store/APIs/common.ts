import { EInsuranceFeature } from "enums/insurance.enum"
import { NOT_EMPTY, PRESS, TYPE_ARR_INPUT } from "./const"
import { validateEmail, validateIdCard, validateMaxLength, validatePhoneNumber } from "src/common/Validate"

export const ADMIN_PATH = {
  IMPORT_CONTRACT_LOTS: '/admin/import-contract-lots'
}
export const BLACK_LIST_USER: string[] = [
  'users_2e81e16a-21cb-4bb3-bce7-240c07047fca',
  'users_2d1e16e2-7f32-4bff-b133-4f1d8b8894d3',
  'users_dab283d8-7186-45e7-ab09-1ae593cae98e',
  'users_6c4eee28-2af8-4bc8-af24-4d634f63f17e',
  'users_717db518-c9e6-4110-8cdb-ae3f8c0a5bee',
  'users_fcc545a5-3a01-46bf-9528-70aad0796546',
  'users_7b03c850-af37-4d73-8a79-384e43a6b432',
  'users_4ba6896b-95c5-4e39-a8a8-67b30e29a07e',
  'users_459a62cc-b2f7-444e-89cb-ea6da7ecf2e7',
]

export const TITLE_NOTIFICATION = 'Thông báo'
export const TIME_CLOSE_NOTIFICATION = 3
export const FORMAT_DATE = 'DD/MM/YYYY HH:mm:SS'
export const FORMAT_DATE_WITHOUT_HOUR = 'DD/MM/YYYY'

// MOTOR_01 = "MOTOR_01",
// AUTO_01 = "AUTO_01",
// PERSONAL_01 = "PERSONAL_01",
// TRAVEL_01 = "TRAVEL_01",
// HEALTH_01 = "HEALTH_01",
// FIRE_01 = "FIRE_01",
// HOME_01 = "HOME_01",
// OTHER_01 = "OTHER_01",

export const ConvertNameFeature = (str = '') => {
  str = str.toUpperCase()
  if (str === EInsuranceFeature.MOTOR_01) str = 'Xe máy'
  if (str === EInsuranceFeature.AUTO_01) str = 'Ô tô'
  if (str === EInsuranceFeature.PERSONAL_01) str = 'Tai nạn cá nhân'
  if (str === EInsuranceFeature.PERSONAL_02) str = 'Tai nạn mở rộng'
  if (str === EInsuranceFeature.TRAVEL_01||str === EInsuranceFeature.TRAVEL_02) str = 'Du lịch'
  if (str === EInsuranceFeature.HEALTH_01) str = 'Sức khỏe'
  if (str === EInsuranceFeature.FIRE_01) str = 'Cháy nổ'
  if (str === EInsuranceFeature.HOME_01) str = 'Nhà tư nhân'
  if (str === EInsuranceFeature.HEALTH_02) str = 'Ung thư'
  if (str === EInsuranceFeature.STUDENT_01) str = 'Học sinh'
  
  return str

}
export const removeNullValues = (obj: any) => {
  const newObj: Record<string, any> = { ...obj };
  for (const key in newObj) {
    if (newObj[key] === null || newObj[key] === '' || newObj[key] === undefined) {
      delete newObj[key as keyof typeof newObj];
    }
  }
  return newObj;
}


export enum ECategory {
  LOAIXEAUTO = "LOAIXEAUTO", // loại xe ô tô
  HIEUXEAUTO = "HIEUXEAUTO", // Danh sách hiệu xe
  DONGXE = "DONGXE", // danh sách dòng xe
  HIEUXEMOTOR = "HIEUXEMOTOR", // Hiệu xe xe máy
  LOAIXEMOTOR = "LOAIXEMOTOR", // Loại xe xe máy
  MDSD_AUTO = "MDSD_AUTO", // Mục đích sử dụng xe oto
  MDSD_VBI_AUTO = "MDSD_VBI_AUTO", // Mục đích sử dụng xe oto
  LOAIHINH_AUTO = "LOAIHINH_AUTO", // Mục đích sử dụng xe oto

  PERSONAL_ACCIDENT_PACKAGE = "PERSONAL_ACCIDENT_PACKAGE",
  DOMESTIC_TRAVEL_PACKAGE = "DOMESTIC_TRAVEL_PACKAGE",
  OVERSEA_TRAVEL_PACKAGE = "OVERSEA_TRAVEL_PACKAGE",
  OVERSEA_TRAVEL_AREA = "OVERSEA_TRAVEL_AREA",
  FIRE_PACKAGES = "FIRE_PACKAGES",
  HOME_PACKAGES = "HOME_PACKAGES",
  CANCER_PACKAGES = "CANCER_PACKAGES",
  STUDENT_PACKAGES = "STUDENT_PACKAGES",
  BHXH_PACKAGES = "BHXH_PACKAGES",
  HEALTH_PACKAGES = "HEALTH_PACKAGES",
  DKBS_VBI_AUTO = "VBI_DKBS", //DKBS VBI
  EXTENDED_ACCIDENT_PACKAGES = "EXTENDED_ACCIDENT_PACKAGES",
  BIZ_TYPES = "BIZ_TYPES",

  // Danh mục danh riêng cho sản phẩm tài sản
  DIADIEM_BH = "DIADIEM_BH",
  MUCDICH_SD = "MUCDICH_SD",
  MAHIEU_RUIRO = "MAHIEU_RUIRO",

  PROVINCE = "PROVINCE",
  AUTO_TYPE = "AUTO_TYPE",
  BHXH = "BHXH",
}
export const ARR_GENDER = [
  {
    value: 'MALE',
    label: 'Nam'
  },
  {
    value: 'FEMALE',
    label: 'Nữ'
  },
]
export const UNIT_MILLION = 1000000


// TODO: rename
export enum EInsuranceSource {
  PVI = "PVI",
  VBI = "VBI",
  MIC = "MIC",
  BIC = "BIC",
  DNP = "DNP",
  OTHER = "OTHER"
}

export enum EMotorCategoryValue {
  CC50Down = "CC50Down",
  CC50Up = "CC50Up",
  Electric = "Electric",
  Other = "Other", // 3 bánh + xe gắn máy khác
}

export enum EInsuranceGroup {
  INSURANCE = "MOTOR",
  DOCUMENT = "DOCUMENT",
  CLAIM = "CLAIM",
}

export enum EInsuranceStatus {
  PURCHASED = "PURCHASED",
  CART = "CART",
  OTHER = "OTHER"
}


export enum EPersonalAccidentPackageValue {
  BRONZE = "0101",
  SILVER = "0102",
  GOLD = "0103",
  PLATINUM = "0104",
  DIAMOND = "0105",
}

export enum EPVIDomesticTravelPackageValue {
  PACKAGE_01 = "PACKAGE_01",
  PACKAGE_02 = "PACKAGE_02",
  PACKAGE_03 = "PACKAGE_03",
  PACKAGE_04 = "PACKAGE_04",
  PACKAGE_05 = "PACKAGE_05",
  PACKAGE_06 = "PACKAGE_06",
}
export enum EBICDomesticTravelPackageValue {
  TRV_01 = "20",
  TRV_02 = "19",
  TRV_03 = "18",
  TRV_04 = "17",
  TRV_05 = "16",
  TRV_06 = "15",
  TRV_07 = "14",
  TRV_08 = "13",
  TRV_09 = "12",
  TRV_10 = "11",
  TRV_11 = "10",
  TRV_12 = "9",
  TRV_13 = "8",
  TRV_14 = "7",
  TRV_15 = "6",
  TRV_16 = "5",
  TRV_17 = "4",
  TRV_18 = "3",
  TRV_19 = "2",
  TRV_20 = "1",
}
export enum EPVIOverseaTravelPackageValue {
  PACKAGE_01 = "PACKAGE_01",
  PACKAGE_02 = "PACKAGE_02",
  PACKAGE_03 = "PACKAGE_03",
  PACKAGE_04 = "PACKAGE_04",
  PACKAGE_05 = "PACKAGE_05",
  PACKAGE_06 = "PACKAGE_06",
}

export enum EBICOverseaTravelPackageValue {
  PLAN_A = "1",
  PLAN_B = "2",
  PLAN_C = "3",
  PLAN_D = "4",
  PLAN_E = "5",
}

export enum EBICCancerPackageValue {
  PLAN_A = "1",
  PLAN_B = "2",
  PLAN_C = "3",
  PLAN_D = "4",
}

export enum EBICExtendedAccidentPackageValue {
  PLAN_A = "1",
  PLAN_B = "2",
  PLAN_C = "3",
  PLAN_D = "4",
}

export enum EAreaValue {
  ATW = "ATW",
  ASI = "ASI",
  ASE = "ASE", // ATW: toàn cầu, ASI: châu á (trừ nhật, úc, new zeland), ASE: đông nam á
}

export enum EHomePackageValue {
  BRONZE = "F01",
  SILVER = "F02",
  GOLD = "F03",
  DIAMOND = "F04",
}

export enum EAutoUserIntentValue {
  N = "N", // người - không kd
  N_K = "N_K", // người - kinh doanh
  H = "H", // hàng - không kd
  H_K = "H_K", // hàng - kinh doanh
  KD = "KD", // kinh doanh
  KKD = "KKD", // không kinh doanh
}

export enum EAutomonthValue {
  T3 = "T3",
  T6 = "T6",
  T9 = "T9",
}

export enum EAutoTypeValue {
  XEN1 = "XEN1", // X	Xe chở người - Xe không kinh doanh
  XEN2 = "XEN2", // X	Xe chở người - Xe chạy trong khu nội bộ
  XEN3 = "XEN3", // X	Xe chở người - Xe khách liên tỉnh
  XEN4 = "XEN4", // X	Xe chở người - Xe bus
  XEN5 = "XEN5", // X	Xe chở người - Xe grab và loại hình tương tự
  XEN6 = "XEN6", // X	Xe chở người - Xe taxi, cho thuê tự lái
  XEN7 = "XEN7", // X	Xe chở người - Xe tập lái
  XEN8 = "XEN8", // X	Xe chở người - Xe cứu thương
  XEN10 = "XEN10", // X	Xe chở người - Xe kinh doanh khác

  XEH1 = "XEH1", // X	Xe chở hàng - Xe rơ mooc
  XEH2 = "XEH2", // X	Xe chở hàng - Xe tải trên 10 tấn
  XEH3 = "XEH3", // X	Xe chở người - Xe đầu kéo, xe đông lạnh trên 3.5 tấn
  XEH4 = "XEH4", // X	Xe chở hàng - Xe kinh doanh vận tải hàng hóa
  XEH5 = "XEH5", // X	Xe chở hàng - Xe trong vùng khoáng sản
  XEH6 = "XEH6", // X	Xe chở hàng -  Xe chở hàng còn lại
  XEH7 = "XEH7", // X	Xe chở hàng - Xe chở tiền
  XEH8 = "XEH8", // X	Xe chở hàng - Xe ô tô chuyên dùng khác

  XET1 = "XET1", // X	Xe chở hàng - Xe bán tải
  XET2 = "XET2", // X	Xe chở hàng - Xe chở hàng còn lại
}

export enum EPVIFirePackageValue {
  PACKAGE_01 = "PACKAGE_01",
  PACKAGE_02 = "PACKAGE_02",
  PACKAGE_03 = "PACKAGE_03",
  PACKAGE_04 = "PACKAGE_04",
  PACKAGE_05 = "PACKAGE_05",
  PACKAGE_06 = "PACKAGE_06",
}

export enum EPVIFireBizTypeValue {
  KARA = "KARA", // 0.2
  RETAIL = "RETAIL", // 0.4
  GAS_PETRO = "GAS_PETRO", // 0.3
}

export enum EBICHealthPackageValue {
  //  12 Cơ bản; 1 Đồng; 2 Bạc; 3 Vàng; 4 Bạch Kim; 5 Kim Cương;
  BASIC = "12",
  BRONZE = "1",
  SILVER = "2",
  GOLD = "3",
  PLATINUM = "4",
  DIAMOND = "5",
}
export enum VBIHealthPackageValue {
  BRONZE = "NEW_BAN_LE_DONG",
  SILVER = "NEW_BAN_LE_BAC",
  TITAN = "NEW_BAN_LE_TITAN",
  GOLD = "NEW_BAN_LE_VANG",
  PLATINUM = "NEW_BAN_LE_BACH_KIM",
  DIAMOND = "NEW_BAN_LE_KIM_CUONG",
}
export enum MICHealthPackageValue {
  BRONZE = "1",
  SILVER = "2",
  GOLD = "3",
  PLATINUM = "4",
  DIAMOND = "5",
}
export enum MICVTSKHealthPackageValue {
  PACKAGE_01 = "TCBL_ANTAM",
  PACKAGE_02 = "TCBL_TINTUONG",
  PACKAGE_03 = "TCBL_MANHKHOE",
  PACKAGE_04 = "TCBL_HANHPHUC",
}
export enum MICHealthTypeValue {
  TYPE_01 = "MIC_CARE",
  TYPE_02 = "MIC_VTSK",
}

export enum ECalculationFeature {
  // trach nhiem dan su bat buoc
  BHXH_TUNGUYEN = "BHXH_TUNGUYEN",
  voluntary = "voluntary-social-insurance",
  FirstStepFillData = "voluntary-social-first",
}
export const CExpiry = (options: string[], unit = 'năm', showItem = true) => {
  return {
    id: 'expiry',
    label: 'Thời hạn bảo hiểm',
    type: TYPE_ARR_INPUT.SELECT,
    placeholder: `${PRESS} Thời hạn bảo hiểm`,
    rules: [
      { required: true, message: `Thời hạn bảo hiểm ${NOT_EMPTY}` },
    ],
    options: options.map((itemMap) => {
      return {
        value: itemMap,
        label: `${itemMap} ${unit}`
      }
    }),
    showItem,
  }
}

export const CIdCard = (id = 'idCard', showItem = true) => {
  return {
    id,
    label: 'Số CCCD',
    type: TYPE_ARR_INPUT.INPUT,
    placeholder: `${PRESS} số CCCD`,
    rules: [
      { required: true, message: `Số CCCD ${NOT_EMPTY}` },
      {
        pattern: validateIdCard().regexPattern,
        message: validateIdCard().message
      },
    ],
    showItem,
    options: []
  }
}

export const CAddress = (id = 'address', showItem = true) => {
  return {
    id,
    label: 'Địa chỉ',
    type: TYPE_ARR_INPUT.INPUT,
    placeholder: `${PRESS} địa chỉ`,
    rules: [
      { required: true, message: `Địa chỉ ${NOT_EMPTY}` },
    ],
    showItem,
    options: []
  }
}

export const CFeeInsurance = (id = 'fee', showItem = true) => {
  return {
    id,
    label: 'Phí BH',
    type: TYPE_ARR_INPUT.INPUT_PRICE,
    placeholder: `${PRESS} phí BH`,
    rules: [
      { required: true, message: `Phí BH ${NOT_EMPTY}` },
      {
        pattern: validateMaxLength(12).regexPattern,
        message: validateMaxLength(12).message
      },
    ],
    showItem,
    options: []
  }
}

export const CDiscountCode = (id = 'discountCode', showItem = true) => {
  return {
    id,
    label: 'Khuyến mãi',
    type: TYPE_ARR_INPUT.INPUT,
    placeholder: `${PRESS} khuyến mãi`,
    showItem,
    options: [],
    rules: []
  }
}

export const CGender = (id = 'gender', showItem = true) => {
  return {
    id,
    label: 'Giới tính',
    type: TYPE_ARR_INPUT.SELECT,
    options: ARR_GENDER || [],
    placeholder: `${PRESS} Giới tính`,
    rules: [
      { required: true, message: `Giới tính ${NOT_EMPTY}` },
    ],
    showItem,
  }
}

export const CStartDate = (id = 'startDate', showItem = true) => {
  return {
    id,
    label: 'Ngày bắt đầu',
    type: TYPE_ARR_INPUT.DATE_PICKER,
    placeholder: `${PRESS} ngày bắt đầu`,
    rules: [{ required: true, message: `Ngày bắt đầu ${NOT_EMPTY}` }],
    showItem,
    options: [],
  }
}

export const CEmail = (id = 'recipientEmail', showItem = true) => {
  return {
    id,
    label: `Email`,
    type: TYPE_ARR_INPUT.INPUT,
    placeholder: `${PRESS} email`,
    rules: [
      { required: true, message: `Email ${NOT_EMPTY}` },
      {
        pattern: validateEmail().regexPattern,
        message: validateEmail().message
      },
    ],
    showItem,
    options: [],

  }
}
export const CPhoneNumber = (id = 'recipientPhone', showItem = true) => {
  return {
    id,
    label: 'Số điện thoại',
    type: TYPE_ARR_INPUT.INPUT,
    placeholder: `${PRESS} số điện thoại`,
    rules: [
      { required: true, message: `Số điện thoại ${NOT_EMPTY}` },
      {
        pattern: validatePhoneNumber().regexPattern,
        message: validatePhoneNumber().message
      },
    ],
    showItem,
    options: [],
  }
}
import { createApi } from "@reduxjs/toolkit/query/react";
import {
  ICreateInsurancePolicy,
} from "interfaces/referrer.interface";
import { getBaseQuery } from "./base";
import { METHOD } from "./const";
export const configurationApi = createApi({
  reducerPath: "configurationApi",
  tagTypes: [],
  baseQuery: getBaseQuery(),
  endpoints: (builder) => ({

    getData: builder.query({
      query: () =>
        `/admin/referrer/settings`,
    }),

    createData: builder.mutation<ICreateInsurancePolicy, ICreateInsurancePolicy>({
      query: (data) => ({
        url: `/admin/referrer/settings`,
        method: "POST",
        body: data,
      }),
    }),

    updateData: builder.mutation<ICreateInsurancePolicy, ICreateInsurancePolicy>({
      query: (data) => ({
        url: `/admin/referrer/settings/${data.id}`,
        method: "PUT",
        body: data,
      }),
    }),

    deleteData: builder.mutation<ICreateInsurancePolicy, { id: string }>({
      query: (data) => ({
        url: `/admin/referrer/settings/${data.id}`,
        method: METHOD.DELETE,
      }),
    }),

  }),
});
export const {
  useLazyGetDataQuery,
  useCreateDataMutation,
  useUpdateDataMutation,
  useDeleteDataMutation,
} = configurationApi;

import { createApi } from "@reduxjs/toolkit/query/react";
import { ListResponse } from "interfaces/global.interface";
import { mapValues } from "lodash";
import { getBaseQuery } from "./base";

export interface IImage {
  origin: string;
}

export const storageApi = createApi({
  reducerPath: "storageApi",
  tagTypes: ["storage", "image"],
  keepUnusedDataFor: 90,
  baseQuery: getBaseQuery(),

  endpoints: (builder) => ({
    getAllImage: builder.query<
      ListResponse<IImage>,
      {
        limit?: number;
        page: number;
      }
    >({
      query: ({ page, limit }) =>
        `/my/storage/images?${new URLSearchParams(
          mapValues(
            {
              page,
              ...(limit && { limit }),
            },
            String
          )
        ).toString()}`,
      providesTags: ["image"],
    }),

    getSingedUploadImageUrl: builder.query<
      { url: string },
      {
        fileName: string;
      }
    >({
      query: ({ fileName }) => `/my/storage/image?fileName=${fileName}`,
      providesTags: ["image"],
    }),
    getSingedUploadFileUrl: builder.query<
      { url: string },
      {
        fileName: string;
      }
    >({
      query: ({ fileName }) => `/my/storage/file?fileName=${fileName}`,
      providesTags: ["storage"],
    }),

    getSingedCustomUploadUrl: builder.query<
      { url: string },
      {
        fileName: string;
      }
    >({
      query: ({ fileName }) => `/my/storage/sheet?fileName=${fileName}`,
      providesTags: ["image"],
    }),
  }),
});

export const {
  // query
  useGetAllImageQuery,
  useLazyGetSingedUploadImageUrlQuery,
  useLazyGetSingedUploadFileUrlQuery,
  useLazyGetSingedCustomUploadUrlQuery,
} = storageApi;

import { createApi } from "@reduxjs/toolkit/query/react";
import { ListResponse } from "interfaces/global.interface";
import { IUser, IUserDetails } from "interfaces/user.interfaces";
import { isUndefined, omitBy } from "lodash";
import { getBaseQuery } from "./base";
import { METHOD } from "./const";
import {EInsuranceWorkflowStage} from "../../enums/insurance.enum";
export interface IContractOffline {
  "id": string,
  "source": string,
  "feature": string,
  "buyer": {
    "name": string,
    "phone": string
  },
  "referrer": {
    "id": string,
    "name": string
  },
  "createdAt": string
}
export interface IContractOnline {
  "id": string,
  "source": string,
  "feature": string,
  "buyer": {
    "name": string,
    "phone": string,
    "idCardNumber": string,
    "address": string,
  },
  "referrer": {
    "id": string,
    "name": string
  },
  transactionId: string,
  "createdAt": string,
  "stage": EInsuranceWorkflowStage,
}

export interface IContractLogsOnline {
  "ipnLogs": IPNLogsOnline[],
  "logs": any,
}

export interface IPNLogsOnline{
  tnxId: string;
  callback: any;
  provider: string;
  response: any;
  createdTime: Date;
}

export interface IContractAdminOnline {
  items?: IContractOnline,
  createdUser: any;
  personInformation: any;
  productPackage: any;
  insuranceObject: any;
  policy: any;
  commission: any;
}

export interface ICategoryResponse {
  Text: string;
  Value: string | number;
  code: string | number;
  name: string;
  Type?:string
}

export const contractApi = createApi({
  reducerPath: "contractApi",
  baseQuery: getBaseQuery(),

  endpoints: (builder) => ({
    getContractOffline: builder.query<
      ListResponse<IContractOffline>, {}
    >({
      query: (data) =>
        `/agency/insurance/offline/search?${new URLSearchParams(
          data as any
        ).toString()}`,
    }),

    getContractOnline: builder.query<
        ListResponse<IContractOnline>, {}
    >({
      query: (data) =>
          `/admin/insurance/online/search?${new URLSearchParams(
              data as any
          ).toString()}`,
    }),

    getContractOnlineDetail: builder.query<
        IContractAdminOnline, {}
    >({
      query: (id) =>
          `/admin/insurance/online/` + id,
    }),

    getContractOnlineLogs: builder.query<
        IContractLogsOnline, {}
    >({
      query: (id) =>
          `/admin/insurance/online/` + id + '/logs',
    }),

    getUserIntentByPartnerId: builder.query<
      ICategoryResponse[], {}
    >({
      query: (data) =>
        `/public/insurance/category?${new URLSearchParams(
          data as any
        ).toString()}`,
    }),
    getAutoInsuranceCategoryCode: builder.query<
      ICategoryResponse[], {}
    >({
      query: (data) =>
        `/public/insurance/auto/category-code?${new URLSearchParams(
          data as any
        ).toString()}`,
    }),
    postDataContractOffline: builder.mutation<any, any>({
      query: (body) => ({
        url: `/agency/insurance/offline/create`,
        method: METHOD.POST,
        body,
      }),
    }),
    postDataContractImportOffline: builder.mutation<any, any>({
      query: (body) => ({
        url: `/agency/insurance/offline/import`,
        method: METHOD.POST,
        body,
      }),
    }),
  }),

});
export const {
  useGetContractOfflineQuery,
  useLazyGetContractOfflineQuery,
  useLazyGetContractOnlineQuery,
  useLazyGetContractOnlineLogsQuery,
  useLazyGetContractOnlineDetailQuery,
  useLazyGetUserIntentByPartnerIdQuery,
  usePostDataContractOfflineMutation,
  useLazyGetAutoInsuranceCategoryCodeQuery,
  usePostDataContractImportOfflineMutation
} = contractApi;
